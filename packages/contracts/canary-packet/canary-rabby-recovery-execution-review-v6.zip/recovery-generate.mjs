// TASK 10D-5 — assemble the fresh RECOVERY packet + policy + canonical recovery authorization from the
// rehearsal packet (original 19-step plan), the verified completed-step-1 anchor, and the fresh live
// recovery snapshot. Read-only (no chain writes). Emits recovery-packet.json, recovery-policy.json and
// operator/recovery-authorization.json with the recoveryAuthorizationDigest anchored in all three.
import { readFileSync, writeFileSync } from "node:fs";
import { keccak256, getAddress, toHex } from "viem";
import { buildRecoveryCanonical } from "./operator/recovery-canonical.mjs";
import { digestOf } from "./operator/canonical.mjs";

const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const rehearsal = rj("canary-unsigned-packet.json");
const policy = rj("review-policy.json");
const anchorFile = rj("recovery-anchor.json");
const snap = rj("recovery-snapshot.json");
const price = rj("recovery-price-snapshot.json");
const A = getAddress, B = (x) => BigInt(x);
const hx = (n) => B(n).toString();
const stable = (v) => Array.isArray(v) ? "[" + v.map(stable).join(",") + "]" : (v && typeof v === "object") ? "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + stable(v[k])).join(",") + "}" : JSON.stringify(v);
const toHexUtf8 = (s) => { let h = "0x"; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h += (c < 16 ? "0" : "") + c.toString(16); } return h; };

const RECOVERY_SCOPE = "BPSC-TEST canary RECOVERY (original step 1 completed on chain); Robinhood Chain mainnet; remaining 18 transactions only (original steps 2-19); maximum all-inclusive exposure $130; individual Rabby approvals; canonical BPS production excluded.";
const c1 = anchorFile.completedStep1;
const CAP_MICRO = B(price.selected.microUsd);
const WINDOW = 21600;

// ---- remaining 18 signable transactions = rehearsal immediate steps 2..19 (rehearsal indices 1..18) ----
const remainingTxs = rehearsal.immediateTransactions.slice(1).map((t, i) => {
  const gasLimit = B(t.gasLimit), maxFee = B(t.maxFeePerGas), maxPrio = B(t.maxPriorityFeePerGas);
  return {
    originalIndex: i + 2, remainingIndex: i,
    seq: t.seq, phase: t.phase, label: t.label, signer: A(t.signer), nonce: t.nonce, txType: t.txType,
    to: t.to ? A(t.to) : null, predictedCreationAddress: t.predictedCreationAddress ? A(t.predictedCreationAddress) : null,
    value: t.value || "0", dataOrInitCode: t.dataOrInitCode, dataKeccak: t.dataKeccak, decodedArgs: t.decodedArgs,
    chainId: 4663, gasLimit: gasLimit.toString(), maxFeePerGas: maxFee.toString(), maxPriorityFeePerGas: maxPrio.toString(),
    gasCeilings: {
      gasLimitCeiling: (gasLimit * 2n).toString(),           // no looser than 2x the reviewed gas limit
      maxFeeCeilingWei: maxFee.toString(),                   // reviewed maximum
      maxPriorityCeilingWei: maxPrio.toString(),             // reviewed maximum
      maxGasCostCeilingWei: (gasLimit * maxFee).toString(),  // this step's original reviewed maxGasCostWei
    },
  };
});
if (remainingTxs.length !== 18) throw new Error("expected 18 remaining txs, got " + remainingTxs.length);
if (!remainingTxs.every((t, i) => t.originalIndex === i + 2)) throw new Error("original index sequencing broken");

// ---- recovery exposure: actual step-1 gas + remaining principal + remaining maximum gas ----
const step1ReviewedMaxGas = B(rehearsal.immediateTransactions[0].gasLimit) * B(rehearsal.immediateTransactions[0].maxFeePerGas);
const actualStep1GasCostWei = B(c1.actualGasCostWei);
const remainingPrincipalWei = B(rehearsal.forkFunding.inbound.deployer.weth) + B(rehearsal.forkFunding.inbound.tester.weth);
const remainingMaxGasWei = B(rehearsal.capArithmetic.allInclusiveGasWei) - step1ReviewedMaxGas; // steps 2-19 + delayed + funding max gas
const aggregateWei = actualStep1GasCostWei + remainingPrincipalWei + remainingMaxGasWei;
const aggregateMicroUsd = (aggregateWei * CAP_MICRO) / 10n ** 18n;
if (aggregateMicroUsd > 130_000_000n) throw new Error(`recovery exposure $${(Number(aggregateMicroUsd) / 1e6).toFixed(6)} exceeds $130`);

// ---- remaining predicted deployment addresses (7) from the recovery snapshot ----
const remainingPredicted = {};
for (const [slot, v] of Object.entries(snap.remainingPredictedDeploymentAddresses)) remainingPredicted[slot] = A(v.address);

const genTs = Math.floor(Date.now() / 1000);
const meta = {
  task: "10D-5-recovery", kind: "EXECUTION-ENABLED BPSC-TEST canary RECOVERY packet (original step 1 completed on chain; remaining 18 txs; localhost Rabby operator; per-tx user approval; NO key handling)",
  mode: "recovery", live: true, executable: true, executionAuthorized: true, fundingAuthorized: true,
  chainId: 4663, authorization: { canary: true, production: false, scope: RECOVERY_SCOPE, maxAllInclusiveExposureUsd: 130, signingChannel: "user Rabby extension via per-transaction eth_sendTransaction only", delayedWithdrawalDisabled: "tester nonce 8 withdraw NOT executable from the recovery operator" },
  deployer: A(policy.wallets.deployer), tester: A(policy.wallets.tester),
  forkBlock: String(snap.pinnedBlock.number), forkBlockHash: snap.pinnedBlock.hash, forkTimestamp: String(snap.pinnedBlock.timestamp), forkBaseFeePerGasWei: String(snap.pinnedBlock.baseFeePerGasWei),
  generatedAtUtc: new Date().toISOString(), expiresAtUtc: new Date((Number(snap.pinnedBlock.timestamp) + WINDOW) * 1000).toISOString(), validityWindowSeconds: WINDOW,
  originalStepCount: 19,
  v5ZipSha256: anchorFile.v5ZipSha256, v5ReviewedAuthorizationDigest: anchorFile.v5ReviewedAuthorizationDigest, v5ExecutionPacketDigest: rehearsal.meta.executionPacketDigest,
  feeBounds: { maxFeePerGasWei: policy.gas.maxFeePerGasWei, maxPriorityFeePerGasWei: policy.gas.maxPriorityFeePerGasWei, pinnedBaseFeePerGasWei: String(snap.pinnedBlock.baseFeePerGasWei) },
};

const recoveryPacket = {
  meta,
  safetyFlags: { broadcastReady: true, liveWritesApproved: true, executionAuthorized: true, fundingAuthorized: true },
  completedStep1: c1,
  remaining: { count: 18, testerSwitchAfterOriginalStep: 13, note: "original steps 2-13 deployer; 14-19 tester; switch Rabby to tester after original step 13" },
  addressGuards: { poolAddress: A(rehearsal.addressGuards.poolAddress), infrastructure: rehearsal.addressGuards.infrastructure.map(A), completedTokenAddress: A(c1.createdAddress), remainingPredicted },
  deployedRuntimeCodeHashes: rehearsal.deployedRuntimeCodeHashes,
  dependencies: snap.externalCodeHashes,
  lpUsage: rehearsal.lpUsage, buyAccounting: rehearsal.buyAccounting, sellAccounting: rehearsal.sellAccounting, lockAndWithdraw: rehearsal.lockAndWithdraw,
  provenance: { repoHead: rehearsal.provenance.repoHead, dirtyTrackedTree: rehearsal.provenance.dirtyTrackedTree, contracts: rehearsal.provenance.contracts },
  capArithmetic: { capPriceMicroUsd: CAP_MICRO.toString(), actualStep1GasCostWei: actualStep1GasCostWei.toString(), remainingPrincipalWei: remainingPrincipalWei.toString(), remainingMaxGasWei: remainingMaxGasWei.toString(), aggregateWei: aggregateWei.toString(), aggregateMicroUsd: aggregateMicroUsd.toString(), aggregateUsd: (Number(aggregateMicroUsd) / 1e6).toFixed(6) },
  immediateTransactions: remainingTxs,
  delayedWithdrawalSubPacket: rehearsal.delayedWithdrawalSubPacket,
};

// remainingExecutionDigest over the 18 signable fields (the delayed withdrawal is disabled/non-executable)
const signable = (t) => ({ originalIndex: t.originalIndex, chainId: 4663, signer: A(t.signer), nonce: t.nonce, type: 2, to: t.to ? A(t.to) : null, value: t.value || "0", data: t.dataOrInitCode, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas });
recoveryPacket.meta.remainingExecutionDigest = keccak256(toHexUtf8(stable(remainingTxs.map(signable))));

// build canonical recovery object + digest
const canon = buildRecoveryCanonical({ packet: recoveryPacket, policy, snapshot: snap, getAddress });
if (canon.errors.length) throw new Error("recovery canonical build failed: " + canon.errors.join("; "));
const recoveryAuthorizationDigest = digestOf(canon.object, keccak256);
recoveryPacket.meta.recoveryAuthorizationDigest = recoveryAuthorizationDigest;

// anchor the digest in the policy + packaged operator
policy.recoveryAuthorizationDigest = recoveryAuthorizationDigest;
policy.recoveryExpectedNonces = { deployer: 4, tester: 2 };
writeFileSync(U("recovery-policy.json"), JSON.stringify(policy, null, 2));
writeFileSync(U("operator/recovery-authorization.json"), JSON.stringify(canon.object, null, 2));
writeFileSync(U("recovery-packet.json"), JSON.stringify(recoveryPacket, null, 2));

console.log("remainingExecutionDigest:", recoveryPacket.meta.remainingExecutionDigest);
console.log("recoveryAuthorizationDigest:", recoveryAuthorizationDigest);
console.log("actualStep1GasCostWei:", actualStep1GasCostWei.toString());
console.log("remainingPrincipalWei:", remainingPrincipalWei.toString(), "remainingMaxGasWei:", remainingMaxGasWei.toString());
console.log("aggregateWei:", aggregateWei.toString(), "= $" + (Number(aggregateMicroUsd) / 1e6).toFixed(6), "(cap $130)");
console.log("remaining txs:", remainingTxs.length, "original steps 2..19; deployer nonces", remainingTxs.filter(t => t.phase !== "C-trade" && t.phase !== "D-lock").map(t => t.nonce).join(","));
