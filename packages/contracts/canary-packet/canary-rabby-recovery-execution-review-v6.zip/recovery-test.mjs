// TASK 10D-5 — RECOVERY operator tests + clean-fork recovery replay.
// Forks POST original-step-1 (BPSCanaryToken already deployed; deployer nonce 4), imports/verifies the
// step-1 anchor, and executes the remaining 18 transactions (original steps 2-19) via a mock provider.
// Covers: confirmed-step recovery validation, no-step-1-rebroadcast, exact observed Rabby gas envelope,
// bounded gas adversarial, absent/correct/wrong chainId + provider-chain-change, actual+remaining exposure,
// v6 storage/origin isolation, uncertain-send recovery failure, and reload at every remaining step.
import { readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { createPublicClient, http, keccak256, getAddress, encodeAbiParameters, toHex } from "viem";
import { RecoveryOperator } from "./operator/recovery-core.mjs";

const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const rt = (p) => readFileSync(U(p), "utf8");
const recoveryPacket = rj("recovery-packet.json"), recoveryPolicy = rj("recovery-policy.json"), recoverySnapshot = rj("recovery-snapshot.json");
const recoveryAuthorizationRaw = rt("operator/recovery-authorization.json"), recoveryAuthorization = JSON.parse(recoveryAuthorizationRaw);
const PORT = Number(process.env.RECTEST_PORT || 8549);
const FORK = `http://127.0.0.1:${PORT}`;
const LIVE = process.env[recoveryPolicy.liveRpcEnvVar];
const R = []; const ok = (n, c, d = "") => R.push({ n, pass: !!c, d });
const B = (x) => BigInt(x);
const DEPLOYER = getAddress(recoveryPolicy.wallets.deployer), TESTER = getAddress(recoveryPolicy.wallets.tester), WETH = getAddress(recoveryPolicy.infrastructure.weth);
const capMicro = B(recoveryPacket.capArithmetic.capPriceMicroUsd);
const freshPrices = async () => ({ coinbaseMicroUsd: capMicro, krakenMicroUsd: capMicro - 100000n, coinbaseAgeS: 3, krakenAgeS: 4 });
const memStore = () => { const m = new Map(); return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => m.set(k, v), _m: m, clone() { const n = new Map(m); return { get: (k) => (n.has(k) ? n.get(k) : null), set: (k, v) => n.set(k, v), _m: n }; } }; };

let anvil;
const forkPub = createPublicClient({ transport: http(FORK) });
const forkReq = (m, p = []) => forkPub.request({ method: m, params: p });
async function waitAnvil() { for (let i = 0; i < 80; i++) { try { if (await forkReq("eth_blockNumber")) return; } catch { } await new Promise(r => setTimeout(r, 500)); } throw new Error("anvil did not start"); }
const FORBIDDEN = ["eth_sendRawTransaction", "eth_sign", "personal_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v4", "wallet_addEthereumChain", "wallet_switchEthereumChain"];

async function main() {
  if (!LIVE) throw new Error("provider RPC env var not set");
  const forkBlock = Number(recoverySnapshot.pinnedBlock.number); // POST step-1 block (canary deployed, nonce 4)
  const baseFee = String(recoverySnapshot.pinnedBlock.baseFeePerGasWei);
  anvil = spawn("anvil", ["--fork-url", LIVE, "--fork-block-number", String(forkBlock), "--chain-id", "4663", "--block-base-fee-per-gas", baseFee, "--port", String(PORT), "--silent"], { stdio: "ignore" });
  await waitAnvil();
  await forkReq("anvil_setBlockTimestampInterval", [1]);
  await forkReq("anvil_setBalance", [DEPLOYER, toHex(10n ** 18n)]); await forkReq("anvil_setBalance", [TESTER, toHex(10n ** 18n)]);
  await forkReq("anvil_impersonateAccount", [DEPLOYER]); await forkReq("anvil_impersonateAccount", [TESTER]);
  // provision WETH exactly as the plan requires
  const knownBal = B(recoverySnapshot.balances.weth.deployer); let slotIdx = null;
  for (let i = 0; i < 300; i++) { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [DEPLOYER, BigInt(i)])); if (B(await forkReq("eth_getStorageAt", [WETH, slot, "latest"])) === knownBal) { slotIdx = BigInt(i); break; } }
  const setW = async (who, amt) => { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [who, slotIdx])); await forkReq("anvil_setStorageAt", [WETH, slot, toHex(amt, { size: 32 })]); };
  const inbound = { deployer: B(recoveryPacket.capArithmetic.remainingPrincipalWei) };
  // LP weth to deployer, trade weth to tester — reuse the rehearsal split from the canonical lp/buy inputs
  const lpWeth = B(recoveryPacket.lpUsage.deployerWethBefore), tradeWeth = B(recoveryPacket.buyAccounting.testerWethBefore);
  const provision = async () => { await setW(DEPLOYER, lpWeth); await setW(TESTER, tradeWeth); };
  await provision();
  let snapId = await forkReq("evm_snapshot", []);
  const resetFork = async () => { await forkReq("evm_revert", [snapId]); await provision(); snapId = await forkReq("evm_snapshot", []); };

  let selectedAccount = DEPLOYER; const calls = []; let sendCount = 0, forbiddenSeen = 0;
  const base = { isRabby: false, async request({ method, params = [] }) { calls.push(method); if (FORBIDDEN.includes(method)) { forbiddenSeen++; throw new Error("forbidden: " + method); } if (method === "eth_accounts") return [selectedAccount]; if (method === "eth_sendTransaction") { sendCount++; if (Array.isArray(params[0])) throw new Error("batch"); return forkReq("eth_sendTransaction", [params[0]]); } return forkReq(method, params); } };
  const newOp = (storage, extra = {}) => new RecoveryOperator({ recoveryPacket, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw, provider: base, keccak256, getAddress, priceProvider: freshPrices, storage, ...extra });

  // ===== A) SUCCESS: import step-1 anchor + execute remaining 18 with per-step restart =====
  await resetFork();
  const store = memStore(); const op = newOp(store);
  ok("recovery bind (canonical anchors + v5 anchors + 18 signables + step-1 completed)", op.bindAndVerifyPacket().ok);
  ok("no step-1 dispatch route (step1IsActionable=false; no deployer nonce-3 step)", !op.step1IsActionable() && !op.steps.some(s => getAddress(s.signer) === DEPLOYER && s.nonce === 3));
  ok("markConnected (chain 4663)", (await op.markConnected(base)).ok);
  ok("reconcile imports+verifies step-1 anchor and sets current=0", (await op.reconcile(base)).ok && op.current === 0 && op.reconciled);

  let allOk = true; const restartCurrents = []; let st0Tx = null, st0Rc = null, st0Ref = null;
  for (let i = 0; i < op.steps.length; i++) {
    selectedAccount = getAddress(op.steps[i].signer);
    const pre = await op.preconditions(base); if (!pre.ok) { allOk = false; ok(`remaining ${i} (orig ${op.steps[i].originalIndex}) pre`, false, pre.reason); break; }
    const s = await op.sendCurrent(base); if (!s.ok) { allOk = false; ok(`remaining ${i} send`, false, s.reason); break; }
    if (i === 0) { st0Ref = op.steps[0]; st0Tx = await forkReq("eth_getTransactionByHash", [s.txHash]); st0Rc = await forkReq("eth_getTransactionReceipt", [s.txHash]); }
    const v = await op.verifyAfterHash(base, s.txHash); if (!v.ok) { allOk = false; ok(`remaining ${i} verify (${op.steps[i].label})`, false, v.reason); break; }
    const ob = newOp(store.clone()); ob.bindAndVerifyPacket(); await ob.markConnected(base); const r = await ob.reconcile(base);
    if (!r.ok || ob.current !== i + 1) { allOk = false; ok(`restart after remaining ${i}`, false, r.reason || `current ${ob.current}`); break; }
    restartCurrents.push(ob.current);
  }
  ok("clean-fork recovery replay: step-1 imported + remaining 18/18 executed & verified", allOk && op.current === 18 && !op.halted);
  ok("successful restart reconciliation after EVERY remaining step (re-verifies step-1 anchor each time)", restartCurrents.length === 18 && restartCurrents.every((v, i) => v === i + 1));
  ok("exactly 18 single eth_sendTransaction calls; no forbidden method; no nonce-3 deployer send", sendCount === 18 && forbiddenSeen === 0);

  // ===== B) EXACT observed step-1 Rabby envelope must pass the bounded verifier at step-1's ceilings =====
  {
    const step1Reviewed = { gasLimit: 713043n, maxFee: 200000000n, maxPrio: 10000000n };
    const ceil = { gasLimitCeiling: (step1Reviewed.gasLimit * 2n).toString(), maxFeeCeilingWei: step1Reviewed.maxFee.toString(), maxPriorityCeilingWei: step1Reviewed.maxPrio.toString(), maxGasCostCeilingWei: (step1Reviewed.gasLimit * step1Reviewed.maxFee).toString() };
    const observed = { gas: 900128n, maxFee: 126100000n, maxPrio: 6196000n };
    const pass = observed.gas <= B(ceil.gasLimitCeiling) && observed.maxFee <= B(ceil.maxFeeCeilingWei) && observed.maxPrio <= B(ceil.maxPriorityCeilingWei) && observed.maxPrio <= observed.maxFee && observed.gas * observed.maxFee <= B(ceil.maxGasCostCeilingWei);
    ok("exact observed step-1 Rabby envelope (900128/126100000/6196000) passes bounded ceilings", pass);
  }

  // ===== C) bounded-gas + chainId adversarial via _verifyTxAndReceipt on the captured real step-0 tx =====
  const gop = op, st0 = st0Ref, txHash0 = st0Rc.transactionHash;
  const canned = (txOverride, chainId = "0x1237") => ({ request: async ({ method }) => { if (method === "eth_chainId") return chainId; if (method === "eth_getTransactionByHash") return { ...st0Tx, ...txOverride }; if (method === "eth_getTransactionReceipt") return st0Rc; return null; } });
  const g = st0.gasCeilings;
  const vt = async (over, chainId) => (await gop._verifyTxAndReceipt(canned(over, chainId), st0, txHash0)).ok;
  ok("bounded gas: honest returned tx verifies", await vt({}));
  ok("bounded gas: gasLimit above 2x ceiling FAILS", !(await vt({ gas: toHex(B(g.gasLimitCeiling) + 1n) })));
  ok("bounded gas: maxFeePerGas above reviewed max FAILS", !(await vt({ maxFeePerGas: toHex(B(g.maxFeeCeilingWei) + 1n) })));
  ok("bounded gas: maxPriorityFeePerGas above reviewed max FAILS", !(await vt({ maxPriorityFeePerGas: toHex(B(g.maxPriorityCeilingWei) + 1n) })));
  ok("bounded gas: gasLimit*maxFee above step cap FAILS", !(await vt({ gas: toHex(B(g.maxGasCostCeilingWei) / B(st0.maxFeePerGas) + 2n) })));
  ok("critical field: wrong sender FAILS", !(await vt({ from: TESTER })));
  ok("critical field: wrong nonce FAILS", !(await vt({ nonce: "0x63" })));
  ok("critical field: wrong value FAILS", !(await vt({ value: "0x1" })));
  ok("critical field: wrong calldata FAILS", !(await vt({ input: "0xdeadbeef" })));
  ok("critical field: wrong type (legacy) FAILS", !(await vt({ type: "0x0" })));
  // chainId cases
  ok("chainId ABSENT in response accepted (eth_chainId==4663 independently)", await (async () => { const p = { request: async ({ method }) => { if (method === "eth_chainId") return "0x1237"; if (method === "eth_getTransactionByHash") { const { chainId, ...noc } = st0Tx; return noc; } if (method === "eth_getTransactionReceipt") return st0Rc; return null; } }; return (await gop._verifyTxAndReceipt(p, st0, txHash0)).ok; })());
  ok("chainId PRESENT and correct (4663) accepted", await vt({ chainId: "0x1237" }));
  ok("chainId PRESENT and wrong (1) FAILS", !(await vt({ chainId: "0x1" })));
  ok("provider chain != 4663 at verify boundary FAILS", !(await vt({}, "0x1")));

  // ===== D) actual+remaining exposure within $130 (includes realized step-1 gas, no double count) =====
  {
    const agg = B(recoveryPacket.capArithmetic.actualStep1GasCostWei) + B(recoveryPacket.capArithmetic.remainingPrincipalWei) + B(recoveryPacket.capArithmetic.remainingMaxGasWei);
    const micro = (agg * capMicro) / 10n ** 18n;
    ok("recovery exposure = actual step-1 gas + remaining principal + remaining max gas <= $130", agg === B(recoveryPacket.capArithmetic.aggregateWei) && micro <= 130_000_000n);
  }

  // ===== E) v6 isolation: distinct namespace; the halted v5 record is never read/mutated =====
  {
    const st = memStore();
    st.set("canary:halt:" + recoveryPacket.meta.v5ExecutionPacketDigest, JSON.stringify({ reason: "V5 HALT — must be untouched", uncertainSend: { step: 0 } }));
    const o = newOp(st); o.bindAndVerifyPacket();
    const v5After = st.get("canary:halt:" + recoveryPacket.meta.v5ExecutionPacketDigest);
    ok("v6 uses canaryv6 namespace; the v5 halt record is neither read as authority nor mutated", o._kHalt.startsWith("canaryv6:") && !o.halted && JSON.parse(v5After).reason === "V5 HALT — must be untouched");
  }

  // ===== F) uncertain-send RECOVERY failure fix + storage faults (no blind retry) =====
  const faultStore = (fail) => { const m = new Map(); return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => { if (fail(k, v)) throw new Error("storage fault"); m.set(k, v); }, _m: m }; };
  const kJournal = "canaryv6:journal:" + recoveryPacket.meta.recoveryAuthorizationDigest;
  // uncertain send, then resolveUncertainSend where the JOURNAL write fails -> must remain halted (v5 defect fix)
  { await resetFork(); const st = faultStore((k) => k === kJournal); const o = newOp(st); o.bindAndVerifyPacket(); await o.markConnected(base); await o.reconcile(base); selectedAccount = getAddress(o.steps[0].signer);
    const errWrap = { request: async ({ method, params }) => { if (method === "eth_sendTransaction") throw new Error("network glitch"); return base.request({ method, params }); } };
    await o.sendCurrent(errWrap);
    const realHash = await base.request({ method: "eth_sendTransaction", params: [{ from: getAddress(o.steps[0].signer), value: "0x0", data: o.steps[0].dataOrInitCode, gas: toHex(B(o.steps[0].gasLimit)), maxFeePerGas: toHex(B(o.steps[0].maxFeePerGas)), maxPriorityFeePerGas: toHex(B(o.steps[0].maxPriorityFeePerGas)), type: "0x2", nonce: toHex(B(o.steps[0].nonce)), chainId: "0x1237" }] });
    const res = await o.resolveUncertainSend(base, realHash);
    ok("resolveUncertainSend with failing journal write stays HALTED (v5 defect fixed; no blind retry)", !res.ok && o.halted && !!o.uncertainSend && o.current === 0);
  }
  // storage unavailable before send: wallet not invoked
  { await resetFork(); const s0 = sendCount; const o = newOp(faultStore((k) => k.startsWith("canaryv6:intent:"))); o.bindAndVerifyPacket(); await o.markConnected(base); await o.reconcile(base); selectedAccount = getAddress(o.steps[0].signer);
    const r = await o.sendCurrent(base);
    ok("storage-unavailable-before-send: wallet NOT invoked, no send", !r.ok && /storage unavailable/.test(r.reason) && sendCount === s0);
  }
  // crash between intent persist and wallet response -> reload halted uncertain (no dispatch for same nonce)
  { const st = memStore(); st.set("canaryv6:intent:" + recoveryPacket.meta.recoveryAuthorizationDigest, JSON.stringify({ digest: recoveryPacket.meta.recoveryAuthorizationDigest, step: 0, signer: getAddress(recoveryPacket.immediateTransactions[0].signer), nonce: recoveryPacket.immediateTransactions[0].nonce, signableTxHash: "0x" + "a".repeat(64) })); const o = newOp(st);
    ok("crash-between-intent-and-response: reload HALTED uncertain (no new send button for that nonce)", o.halted && !!o.uncertainSend && o.uncertainSend.step === 0);
  }

  // ===== G) canonical-leaf mutation suite (every recovery-authorization leaf fails binding) =====
  const { buildRecoveryCanonical } = await import("./operator/recovery-canonical.mjs");
  const { digestOf } = await import("./operator/canonical.mjs");
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const bindWith = (P, PO, S, PKG, RAW) => { try { const o = new RecoveryOperator({ recoveryPacket: P, recoveryPolicy: PO, recoverySnapshot: S, recoveryAuthorization: PKG, recoveryAuthorizationRaw: RAW ?? JSON.stringify(PKG), provider: base, keccak256, getAddress, priceProvider: freshPrices, storage: memStore() }); return { ok: o.bindAndVerifyPacket().ok, o }; } catch { return { ok: false, o: null }; } };
  const leafPaths = [];
  (function walk(o, p) { if (o && typeof o === "object") { for (const k of Object.keys(o)) walk(o[k], p.concat(k)); } else leafPaths.push(p); })(recoveryAuthorization, []);
  const getAt = (o, p) => p.reduce((x, k) => x[k], o);
  const setAt = (o, p, v) => { const par = p.slice(0, -1).reduce((x, k) => x[k], o); par[p[p.length - 1]] = v; };
  const mutVal = (v) => { if (typeof v === "boolean") return !v; if (typeof v === "number") return v + 1; if (typeof v === "string") { if (/^0x[0-9a-fA-F]{40}$/.test(v)) return "0x000000000000000000000000000000000000dEaD"; if (/^0x[0-9a-fA-F]+$/.test(v)) return v.slice(0, -1) + (v.slice(-1) === "0" ? "1" : "0"); if (/^[0-9]+$/.test(v)) return (BigInt(v) + 1n).toString(); return v + "_MUT"; } return "MUT"; };
  let leafFails = [], leafTested = 0;
  for (const p of leafPaths) { const PKG = clone(recoveryAuthorization); setAt(PKG, p, mutVal(getAt(PKG, p))); leafTested++; if (bindWith(recoveryPacket, recoveryPolicy, recoverySnapshot, PKG).ok) leafFails.push(p.join(".")); }
  globalThis.__recoveryLeafCount = leafTested;
  ok(`GENERIC recovery leaf-mutation: all ${leafTested} canonical recovery leaves fail binding when mutated`, leafFails.length === 0, leafFails.slice(0, 8).join(" | "));

  // ===== H) source-input mutation completeness (every recovery packet/policy/snapshot leaf either shifts the
  //          digest and fails binding, or is provably unused — raw inputs are null after bind) =====
  const baseDigest = digestOf(buildRecoveryCanonical({ packet: recoveryPacket, policy: recoveryPolicy, snapshot: recoverySnapshot, getAddress }).object, keccak256);
  const digestAfter = (P, PO, S) => { try { const r = buildRecoveryCanonical({ packet: P, policy: PO, snapshot: S, getAddress }); return r.errors.length ? "ERR" : digestOf(r.object, keccak256); } catch { return "THROW"; } };
  let srcChanged = 0, srcUnused = 0;
  for (const [name, obj] of [["packet", recoveryPacket], ["policy", recoveryPolicy], ["snapshot", recoverySnapshot]]) {
    const paths = []; (function w(x, p) { if (x && typeof x === "object") { for (const k of Object.keys(x)) w(x[k], p.concat(k)); } else paths.push(p); })(obj, []);
    for (const p of paths) {
      const P = clone(recoveryPacket), PO = clone(recoveryPolicy), S = clone(recoverySnapshot);
      const target = name === "packet" ? P : name === "policy" ? PO : S;
      setAt(target, p, mutVal(getAt(target, p)));
      if (digestAfter(P, PO, S) !== baseDigest) srcChanged++; else srcUnused++;
    }
  }
  { const o = bindWith(recoveryPacket, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw).o;
    ok(`recovery SOURCE-INPUT mutation: ${srcChanged} leaves shift the digest; ${srcUnused} unused (raw inputs null after bind)`, srcChanged > 0 && o.recoveryPacket === null && o.recoveryPolicy === null && o.recoverySnapshot === null); }
  globalThis.__recoverySrcChanged = srcChanged; globalThis.__recoverySrcUnused = srcUnused;

  // key regressions: anchor hash / created address / actual gas / ceilings / v5 anchors / nonce expectations
  const srcFail = (fn) => { const P = clone(recoveryPacket), PO = clone(recoveryPolicy), S = clone(recoverySnapshot); fn(P, PO, S); return !bindWith(P, PO, S, recoveryAuthorization, recoveryAuthorizationRaw).ok; };
  const reg = {
    "anchor-txHash": srcFail((P) => P.completedStep1.txHash = "0x" + "1".repeat(64)),
    "anchor-createdAddress": srcFail((P) => P.completedStep1.createdAddress = "0x000000000000000000000000000000000000dEaD"),
    "anchor-actualGasCost": srcFail((P) => { P.completedStep1.actualGasCostWei = "1"; P.capArithmetic.actualStep1GasCostWei = "1"; }),
    "gas-ceiling-loosened": srcFail((P) => P.immediateTransactions[0].gasCeilings.maxGasCostCeilingWei = "999999999999999999999"),
    "v5-zip-anchor": srcFail((P) => P.meta.v5ZipSha256 = "deadbeef"),
    "v5-auth-anchor": srcFail((P) => P.meta.v5ReviewedAuthorizationDigest = "0x" + "2".repeat(64)),
    "deployer-nonce-expectation": srcFail((P, PO, S) => S.expectedNonces.deployer = 5),
    "aggregate-exposure": srcFail((P) => P.capArithmetic.aggregateWei = "1"),
    "remaining-count": srcFail((P) => { P.remaining.count = 17; }),
    "step1-injected-into-signables": (() => { const P = clone(recoveryPacket); P.immediateTransactions[0].originalIndex = 1; P.immediateTransactions[0].nonce = 3; return !bindWith(P, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw).ok; })(),
  };
  const regBad = Object.entries(reg).filter(([, v]) => !v).map(([k]) => k);
  ok(`recovery regressions: anchor/ceiling/v5-anchor/nonce/exposure/step1-injection all FAIL binding (${Object.keys(reg).length} tested)`, regBad.length === 0, regBad.join(","));

  console.log("[recovery-test] canonical recovery leaves mutation-tested:", globalThis.__recoveryLeafCount, "| source-input changed:", srcChanged, "unused:", srcUnused);
  console.log("[recovery-test] histogram:", Object.entries(calls.reduce((a, m) => (a[m] = (a[m] || 0) + 1, a), {})).map(([k, v]) => `${k}:${v}`).join(" "));
  for (const r of R) console.log(` [${r.pass ? "PASS" : "FAIL"}] ${r.n}${r.d ? "  (" + r.d + ")" : ""}`);
  const passed = R.filter(r => r.pass).length;
  console.log(`\n[recovery-test] ${passed}/${R.length} checks passed`);
  return R.every(r => r.pass);
}
let code = 1;
try { code = (await main()) ? 0 : 1; } catch (e) { console.error("[recovery-test] ERROR:", e.message, e.stack?.split("\n").slice(1, 3).join(" | ")); code = 1; }
finally { if (anvil) try { anvil.kill("SIGKILL"); } catch { } }
process.exit(code);
