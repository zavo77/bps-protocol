// TASK 10D-5 — RECOVERY operator engine. Original step 1 is a VERIFIED completed anchor (non-actionable);
// only the remaining 18 transactions (original steps 2-19) are signable. Reuses the v5 event/receipt
// postconditions, cumulative checkpoints, durable storage state machine and bounded-gas verifier from
// CanaryOperator, and adds: recovery canonical binding (3 anchors), on-chain step-1 anchor reconciliation,
// a DISTINCT storage namespace (never touches the halted v5 records) and no step-1 dispatch route.
import { CanaryOperator } from "./operator-core.mjs";
import { buildRecoveryCanonical, validateRecoveryStrict } from "./recovery-canonical.mjs";
import { digestOf, rawDuplicateKeys } from "./canonical.mjs";

const V5_ZIP_SHA = "5a6246ca51bd3237e6d925153439d9040b1c3674c0e026e9d8f187e7a5e64b3b";
const V5_REVIEWED_AUTH_DIGEST = "0x4fdfd36b99d6090fef67f21bd3b2027e8dc7e339861ae94eb0f292da2b6ee248";
const REMAINING_SLOTS = ["lockingVault", "claimManager", "rialtoAdapter", "coordinator", "stockVault", "uniswapAdapter", "tradeRouter"];

export class RecoveryOperator extends CanaryOperator {
  constructor({ recoveryPacket, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw, provider, keccak256, getAddress, priceProvider, storage, now, receiptPolls, pollMs }) {
    // DISTINCT namespace ("canaryv6") keyed by the recovery digest — never reads/mutates the v5 records.
    super({ packet: null, policy: null, snapshot: null, reviewedAuthorization: null, provider, keccak256, getAddress, priceProvider, storage, now, receiptPolls, pollMs, keyPrefix: "canaryv6", keyDigest: recoveryPacket && recoveryPacket.meta ? recoveryPacket.meta.recoveryAuthorizationDigest : null });
    this.recoveryPacket = recoveryPacket; this.recoveryPolicy = recoveryPolicy; this.recoverySnapshot = recoverySnapshot;
    this.recoveryAuthorization = recoveryAuthorization || null;
    this.recoveryAuthorizationRaw = recoveryAuthorizationRaw || (recoveryAuthorization ? JSON.stringify(recoveryAuthorization) : null);
    this.execDigest = recoveryPacket && recoveryPacket.meta ? recoveryPacket.meta.recoveryAuthorizationDigest : null;
    this.completedStep1 = null; this.isRecovery = true;
  }

  bindAndVerifyPacket() {
    const a = this.recoveryPacket, p = this.recoveryPolicy, s = this.recoverySnapshot, c = {}, A = this.getAddress;
    const recon = buildRecoveryCanonical({ packet: a, policy: p, snapshot: s, getAddress: A });
    c.canonicalReconstructs = recon.errors.length === 0;
    const digestR = recon.object ? digestOf(recon.object, this.keccak256) : null;
    const pkg = this.recoveryAuthorization, raw = this.recoveryAuthorizationRaw || (pkg ? JSON.stringify(pkg) : "");
    const strictErr = pkg ? validateRecoveryStrict(pkg, raw, A) : ["packaged recovery-authorization missing"];
    const dupKeys = pkg ? rawDuplicateKeys(raw) : ["<missing>"];
    c.packagedValid = strictErr.length === 0; c.packagedNoDuplicateKeys = dupKeys.length === 0;
    const digestP = pkg ? digestOf(pkg, this.keccak256) : null;
    const eq = (x, y) => !!x && !!y && String(x).toLowerCase() === String(y).toLowerCase();
    c.anchorsAgree = eq(digestR, digestP) && eq(digestR, a.meta && a.meta.recoveryAuthorizationDigest) && eq(digestR, p.recoveryAuthorizationDigest);
    c.reconMatchesPackaged = !!recon.object && !!pkg && this._stable(recon.object) === this._stable(pkg);
    // remaining execution digest over the 18 signables agrees with the packet + the canonical leaf
    const recomputed = pkg ? this.keccak256(this._utf8ToHex(this._stable(pkg.transactions.immediate.map(t => ({ originalIndex: t.originalIndex, chainId: 4663, signer: A(t.signer), nonce: t.nonce, type: 2, to: t.to ? A(t.to) : null, value: t.value, data: t.data, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas }))))) : null;
    c.remainingExecDigestMatches = !!pkg && eq(recomputed, a.meta.remainingExecutionDigest) && eq(recomputed, pkg.digests.remainingExecutionDigest);
    // v5 anchors bound; original step identity; 18 signables (2..19); step 1 absent; live nonce expectations
    c.v5AnchorsBound = !!pkg && pkg.v5.zipSha256 === V5_ZIP_SHA && eq(pkg.v5.reviewedAuthorizationDigest, V5_REVIEWED_AUTH_DIGEST);
    c.originalPlanBound = !!pkg && pkg.originalPlan.stepCount === 19;
    c.eighteenSignables = !!pkg && pkg.transactions.count === 18 && pkg.transactions.immediate.length === 18 && pkg.transactions.immediate.every((t, i) => t.originalIndex === i + 2) && !pkg.transactions.immediate.some(t => t.originalIndex === 1);
    c.nonceExpectations = !!pkg && pkg.remaining.deployerExpectedNonce === 4 && pkg.remaining.testerExpectedNonce === 2;
    c.step1Completed = !!pkg && pkg.completedStep1 && pkg.completedStep1.nonce === 3 && eq(pkg.completedStep1.createdAddress, pkg.completedTokenAddress);
    c.chainId4663 = !!pkg && pkg.chainId === 4663;
    c.capIs130 = !!pkg && pkg.maxAllInclusiveExposureUsd === 130;
    const ok = Object.values(c).every(Boolean);
    this.bound = ok;
    if (!ok) { this._halt("recovery binding failed: " + Object.entries(c).filter(([, v]) => !v).map(([k]) => k).join(",")); return { ok, recoveryAuthorizationDigest: digestR, checks: c }; }

    // ===== SINGLE BOUND RUNTIME DATA SOURCE (recovery) =====
    const cc = pkg; this.canon = cc; this.completedStep1 = cc.completedStep1;
    this.capMicro = BigInt(cc.maxAllInclusiveExposureUsd) * 1_000_000n;
    this.DEPLOYER = A(cc.wallets.deployer); this.TESTER = A(cc.wallets.tester);
    this.WETH = A(cc.infrastructure.weth); this.FACTORY = A(cc.infrastructure.uniswapV3Factory); this.NPM = A(cc.infrastructure.nonfungiblePositionManager);
    this.SWAP = A(cc.infrastructure.swapRouter02); this.REGISTRY = A(cc.infrastructure.rialtoRegistry); this.NVDA = A(cc.infrastructure.nvdaStockToken);
    this.pool = A(cc.pool);
    this.addr = { canaryToken: A(cc.completedTokenAddress) };
    for (const slot of REMAINING_SLOTS) this.addr[slot] = A(cc.deployments[slot].predictedAddress);
    // build this.steps from the 18 remaining transactions; derive maxGasCostWei; keep gasCeilings + identities
    this.steps = cc.transactions.immediate.map(t => {
      const st = { index: t.remainingIndex, originalIndex: t.originalIndex, remainingIndex: t.remainingIndex, phase: t.phase, label: t.label, postconditionType: t.postconditionType, chainId: 4663, signer: A(t.signer), nonce: t.nonce, to: t.to ? A(t.to) : null, value: t.value, dataOrInitCode: t.data, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas, gasCeilings: t.gasCeilings };
      st.maxGasCostWei = (BigInt(t.gasLimit) * BigInt(t.maxFeePerGas)).toString();
      return st;
    });
    const remDeploys = this.steps.filter(x => x.phase === "A-deploy").sort((x, y) => x.nonce - y.nonce);
    remDeploys.forEach((st, i) => { const slot = REMAINING_SLOTS[i]; st.slot = slot; st.predictedCreationAddress = A(cc.deployments[slot].predictedAddress); st.expectedRuntimeHash = cc.deployments[slot].runtimeCodeHash; });
    this._expiresAtUtc = cc.expiresAtUtc;
    // recovery exposure = remaining principal + (remaining max gas + ACTUAL step-1 gas) — reused by _exposureGate
    this._exposurePrincipalWei = cc.exposure.remainingPrincipalWei;
    this._exposureGasWei = (BigInt(cc.exposure.remainingMaxGasWei) + BigInt(cc.exposure.actualStep1GasCostWei)).toString();
    this._authFlags = cc.flags;
    // discard raw recovery inputs — runtime methods use ONLY this.canon / this.steps
    this.recoveryPacket = null; this.recoveryPolicy = null; this.recoverySnapshot = null;
    return { ok, recoveryAuthorizationDigest: digestR, checks: c };
  }

  // original step 1 has NO dispatch route: it is not in this.steps, so there is no code path that can build
  // or send a nonce-3 transaction. This assertion makes that explicit for callers/tests.
  step1IsActionable() { return this.steps.some(s => (this.getAddress(s.signer) === this.DEPLOYER && s.nonce === 3) || s.originalIndex === 1); }

  // re-verify the on-chain completed step-1 anchor as the reconciliation authority.
  async _verifyStep1Anchor(provider) {
    if (!(await this._assertChain(provider))) return { ok: false, reason: "provider chain != 4663 at anchor verify" };
    const a = this.completedStep1, A = this.getAddress;
    const tx = await this._req(provider, "eth_getTransactionByHash", [a.txHash]);
    const rc = await this._req(provider, "eth_getTransactionReceipt", [a.txHash]);
    if (!tx || !rc) return { ok: false, reason: "step-1 anchor tx/receipt not found on chain" };
    if (tx.chainId !== undefined && tx.chainId !== null && Number(BigInt(tx.chainId)) !== 4663) return { ok: false, reason: "step-1 tx-response chainId present and != 4663" };
    if (BigInt(rc.status) !== 1n) return { ok: false, reason: "step-1 receipt not success" };
    if (rc.transactionHash.toLowerCase() !== a.txHash.toLowerCase()) return { ok: false, reason: "step-1 receipt hash mismatch" };
    if (A(tx.from) !== A(a.from) || Number(BigInt(tx.nonce)) !== 3 || !(tx.to === null || tx.to === undefined) || BigInt(tx.value) !== 0n) return { ok: false, reason: "step-1 tx fields differ from anchor" };
    if (tx.input.toLowerCase() !== undefined && a.inputKeccak && this.keccak256(tx.input).toLowerCase() !== a.inputKeccak.toLowerCase()) return { ok: false, reason: "step-1 input keccak differs from anchor" };
    if (A(rc.contractAddress) !== A(a.createdAddress)) return { ok: false, reason: "step-1 created address differs from anchor" };
    const code = await this._req(provider, "eth_getCode", [a.createdAddress, "latest"]);
    if (this.keccak256(code).toLowerCase() !== a.deployedRuntimeCodeHash.toLowerCase()) return { ok: false, reason: "step-1 deployed runtime hash differs from anchor" };
    return { ok: true };
  }

  async reconcile(provider) {
    if (!this.bound) return { ok: false, reason: "not bound" };
    if (!this.connected) return { ok: false, reason: "not connected" };
    if (this.halted && !this.uncertainSend) return { ok: false, halted: true, reason: this.haltReason };
    // the on-chain step-1 anchor is the recovery authority — verify it before anything else.
    const anc = await this._verifyStep1Anchor(provider); if (!anc.ok) return this._halt("recovery reconciliation: " + anc.reason);
    // then reuse the v5 journal/checkpoint/pending reconciliation for the remaining 18 steps.
    return super.reconcile(provider);
  }
}
