// TASK 10D-5 — canonical RECOVERY authorization. Every security-relevant recovery value is a LEAF here;
// recoveryAuthorizationDigest = keccak256(canonicalStable(object)). Reconstructed identically by the
// generator, the operator (before Connect), the offline verifier and the tests. keccak256/getAddress injected.
import { isDec, isHex, postconditionType, DEP_NAMES, SLOT_CONTRACT, REMAINING_SLOTS } from "./canonical.mjs";

export const RECOVERY_SCHEMA = "canary-recovery-authorization";
export const RECOVERY_VERSION = "10D-5";
export const RECOVERY_SCOPE = "BPSC-TEST canary RECOVERY (original step 1 completed on chain); Robinhood Chain mainnet; remaining 18 transactions only (original steps 2-19); maximum all-inclusive exposure $130; individual Rabby approvals; canonical BPS production excluded.";

export function buildRecoveryCanonical({ packet: a, policy: p, snapshot: s, getAddress }) {
  const err = [];
  const A = (x, w) => { if (!isHex(x, 20)) { err.push("non-address " + w); return "0x0000000000000000000000000000000000000000"; } return getAddress(x); };
  const N = (x, w) => { const v = typeof x === "number" ? String(x) : x; if (!isDec(v)) { err.push("non-canonical-number " + w + "(" + x + ")"); return "0"; } return v; };
  const I = (x, w) => { if (typeof x !== "number" || !Number.isInteger(x) || x < 0) { err.push("non-integer " + w); return 0; } return x; };
  const SI = (x, w) => { if (typeof x !== "number" || !Number.isInteger(x)) { err.push("non-int " + w); return 0; } return x; };
  const HH = (x, w) => { if (!isHex(x, 32)) { err.push("bad-hash " + w); return "0x" + "0".repeat(64); } return x.toLowerCase(); };
  const BT = (x, w) => { if (x !== true) { err.push("expected-true " + w); return false; } return true; };
  const BF = (x, w) => { if (x !== false) { err.push("expected-false " + w); return false; } return false; };
  const STR = (x, w, want) => { if (typeof x !== "string" || (want !== undefined && x !== want)) { err.push("bad-string " + w); return want ?? ""; } return x; };
  const req = (c, w) => { if (!c) err.push("missing " + w); };
  req(a && a.meta && a.meta.authorization, "meta");
  req(a && a.completedStep1, "completedStep1");
  req(a && a.immediateTransactions && a.immediateTransactions.length === 18, "18 immediate");
  req(a && a.capArithmetic, "capArithmetic");
  req(a && a.lpUsage && a.buyAccounting && a.sellAccounting && a.lockAndWithdraw, "expectations");
  req(a && a.provenance && a.provenance.contracts, "provenance");
  req(a && a.deployedRuntimeCodeHashes && a.addressGuards && a.addressGuards.remainingPredicted, "guards");
  req(s && s.pinnedBlock && s.nonces && s.balances && s.externalCodeHashes && s.expectedNonces, "snapshot");
  req(p && p.wallets && p.infrastructure && p.economics && p.gas, "policy");
  if (err.length) return { errors: err, object: null };

  const au = a.meta.authorization, c1 = a.completedStep1, lu = a.lpUsage, bu = a.buyAccounting, se = a.sellAccounting, lk = a.lockAndWithdraw, ca = a.capArithmetic;
  const sigStep = (t) => {
    const g = t.gasCeilings || {};
    const pc = postconditionType(t); if (pc === "unknown") err.push("pc unknown " + t.label);
    return {
      originalIndex: I(t.originalIndex, "tx.orig"), remainingIndex: I(t.remainingIndex, "tx.rem"),
      phase: STR(t.phase, "tx.phase"), label: STR(t.label, "tx.label"), postconditionType: pc,
      chainId: I(t.chainId, "tx.chain"), signer: A(t.signer, "tx.signer"), nonce: I(t.nonce, "tx.nonce"), type: 2,
      to: t.to ? A(t.to, "tx.to") : null, value: N(t.value || "0", "tx.value"),
      data: (isHex(t.dataOrInitCode) ? t.dataOrInitCode.toLowerCase() : (err.push("tx.data"), "0x")),
      gasLimit: N(t.gasLimit, "tx.gas"), maxFeePerGas: N(t.maxFeePerGas, "tx.maxFee"), maxPriorityFeePerGas: N(t.maxPriorityFeePerGas, "tx.maxPrio"),
      gasCeilings: { gasLimitCeiling: N(g.gasLimitCeiling, "gc.gl"), maxFeeCeilingWei: N(g.maxFeeCeilingWei, "gc.mf"), maxPriorityCeilingWei: N(g.maxPriorityCeilingWei, "gc.mp"), maxGasCostCeilingWei: N(g.maxGasCostCeilingWei, "gc.cost") },
    };
  };
  const deployments = {};
  for (const slot of REMAINING_SLOTS) { const cname = SLOT_CONTRACT[slot], pv = a.provenance.contracts[cname], drh = a.deployedRuntimeCodeHashes[slot], rp = a.addressGuards.remainingPredicted[slot]; deployments[slot] = { predictedAddress: A(rp, "dep." + slot), runtimeCodeHash: HH(drh, "dep.hash." + slot), artifactRuntimeKeccak: HH(pv ? pv.runtimeBytecodeKeccak : undefined, "art." + slot) }; }
  const dependencies = {};
  for (const name of DEP_NAMES) { const d = s.externalCodeHashes[name]; if (!d) { err.push("dep " + name); continue; } dependencies[name] = { address: A(d.address, "dep." + name), runtimeCodeHash: HH(d.runtimeCodeHash, "deph." + name), codeBytes: I(d.codeBytes, "depb." + name) }; }

  const remainingPrincipalWei = N(ca.remainingPrincipalWei, "exp.principal"), remainingMaxGasWei = N(ca.remainingMaxGasWei, "exp.maxgas"), actualStep1GasCostWei = N(ca.actualStep1GasCostWei, "exp.step1"), aggregateWei = N(ca.aggregateWei, "exp.agg");
  if (BigInt(actualStep1GasCostWei) + BigInt(remainingPrincipalWei) + BigInt(remainingMaxGasWei) !== BigInt(aggregateWei)) err.push("recovery exposure identity: step1+principal+maxgas != aggregate");

  const object = {
    schema: STR(RECOVERY_SCHEMA, "schema", RECOVERY_SCHEMA), version: STR(RECOVERY_VERSION, "version", RECOVERY_VERSION),
    canary: BT(au.canary, "canary") && BT(p.canary, "pcanary"),
    production: (BF(au.production, "prod") === false && BF(p.production, "pprod") === false) ? false : (err.push("prod"), true),
    chainId: I(a.meta.chainId, "chain") === 4663 && p.chainId === 4663 ? 4663 : (err.push("chain"), 0),
    scope: STR(au.scope, "scope", RECOVERY_SCOPE) === RECOVERY_SCOPE ? RECOVERY_SCOPE : (err.push("scope"), ""),
    flags: { broadcastReady: BT(a.safetyFlags.broadcastReady, "f.b") && BT(p.safetyFlags.broadcastReady, "pf.b"), liveWritesApproved: BT(a.safetyFlags.liveWritesApproved, "f.l") && BT(p.safetyFlags.liveWritesApproved, "pf.l"), executionAuthorized: BT(a.safetyFlags.executionAuthorized, "f.e") && BT(p.safetyFlags.executionAuthorized, "pf.e"), fundingAuthorized: BT(a.safetyFlags.fundingAuthorized, "f.f") && BT(p.safetyFlags.fundingAuthorized, "pf.f") },
    executable: BT(a.meta.executable, "exec"),
    maxAllInclusiveExposureUsd: Number(au.maxAllInclusiveExposureUsd) === 130 ? 130 : (err.push("cap"), 0),
    generatedAtUtc: STR(a.meta.generatedAtUtc, "gen"), expiresAtUtc: STR(a.meta.expiresAtUtc, "exp"),
    validityWindowSeconds: I(a.meta.validityWindowSeconds, "vw"),
    wallets: { deployer: A(a.meta.deployer, "dep") === A(p.wallets.deployer, "pdep") ? A(a.meta.deployer, "dep") : (err.push("deployer"), ""), tester: A(a.meta.tester, "test") === A(p.wallets.tester, "ptest") ? A(a.meta.tester, "test") : (err.push("tester"), "") },
    v5: { zipSha256: STR(a.meta.v5ZipSha256, "v5zip"), reviewedAuthorizationDigest: HH(a.meta.v5ReviewedAuthorizationDigest, "v5rad"), executionPacketDigest: HH(a.meta.v5ExecutionPacketDigest, "v5epd") },
    originalPlan: { stepCount: I(a.meta.originalStepCount, "osc") === 19 ? 19 : (err.push("osc"), 0), deployerStepRange: STR("2-13", "dsr", "2-13"), testerStepRange: STR("14-19", "tsr", "14-19") },
    completedStep1: {
      txHash: HH(c1.txHash, "c1.hash"), from: A(c1.from, "c1.from"), nonce: I(c1.nonce, "c1.nonce") === 3 ? 3 : (err.push("c1.nonce"), 0), type: 2, value: N(c1.value || "0", "c1.value"),
      createdAddress: A(c1.createdAddress, "c1.addr"), blockNumber: N(c1.blockNumber, "c1.bn"), blockHash: HH(c1.blockHash, "c1.bh"),
      gasLimit: N(c1.gasLimit, "c1.gl"), maxFeePerGas: N(c1.maxFeePerGas, "c1.mf"), maxPriorityFeePerGas: N(c1.maxPriorityFeePerGas, "c1.mp"),
      gasUsed: N(c1.gasUsed, "c1.gu"), effectiveGasPriceWei: N(c1.effectiveGasPriceWei, "c1.egp"), actualGasCostWei: N(c1.actualGasCostWei, "c1.cost"),
      deployedRuntimeCodeHash: HH(c1.deployedRuntimeCodeHash, "c1.rh"), deployedCodeSize: I(c1.deployedCodeSize, "c1.sz"), inputKeccak: HH(c1.inputKeccak, "c1.ik"),
      token: { name: STR(c1.token.name, "c1.name"), symbol: STR(c1.token.symbol, "c1.sym", "BPSC-TEST"), decimals: I(c1.token.decimals, "c1.dec") === 18 ? 18 : (err.push("dec"), 0), totalSupply: N(c1.token.totalSupply, "c1.ts"), deployerAllocation: N(c1.token.deployerAllocation, "c1.alloc"), isCanary: BT(c1.token.isCanary, "c1.canary"), maxSupply: N(c1.token.maxSupply, "c1.max") },
    },
    remaining: { count: I(a.remaining.count, "rc") === 18 ? 18 : (err.push("rc"), 0), deployerExpectedNonce: I(s.expectedNonces.deployer, "rdn") === 4 ? 4 : (err.push("rdn"), 0), testerExpectedNonce: I(s.expectedNonces.tester, "rtn") === 2 ? 2 : (err.push("rtn"), 0), testerSwitchAfterOriginalStep: I(a.remaining.testerSwitchAfterOriginalStep, "tsw") === 13 ? 13 : (err.push("tsw"), 0) },
    block: { number: N(String(s.pinnedBlock.number), "b.n") === a.meta.forkBlock ? String(s.pinnedBlock.number) : (err.push("b.n"), "0"), hash: (isHex(s.pinnedBlock.hash, 32) && s.pinnedBlock.hash.toLowerCase() === a.meta.forkBlockHash.toLowerCase()) ? s.pinnedBlock.hash.toLowerCase() : (err.push("b.h"), "0x"), timestamp: N(String(s.pinnedBlock.timestamp), "b.t") === a.meta.forkTimestamp ? String(s.pinnedBlock.timestamp) : (err.push("b.t"), "0"), baseFeePerGasWei: N(String(s.pinnedBlock.baseFeePerGasWei), "b.bf") === a.meta.forkBaseFeePerGasWei ? String(s.pinnedBlock.baseFeePerGasWei) : (err.push("b.bf"), "0"), chainId: I(a.meta.chainId, "b.c") },
    snapshotBalances: { deployerEth: N(String(s.balances.eth.deployer), "sb.de"), deployerWeth: N(String(s.balances.weth.deployer), "sb.dw"), testerEth: N(String(s.balances.eth.tester), "sb.te"), testerWeth: N(String(s.balances.weth.tester), "sb.tw") },
    completedTokenAddress: A(s.completedTokenAddress, "cta") === A(c1.createdAddress, "cta2") ? A(s.completedTokenAddress, "cta") : (err.push("completedTokenAddress"), ""),
    completedTokenCodeHash: HH(s.completedTokenCodeHash, "ctch"),
    infrastructure: { weth: A(p.infrastructure.weth, "weth"), uniswapV3Factory: A(p.infrastructure.uniswapV3Factory, "fac"), nonfungiblePositionManager: A(p.infrastructure.nonfungiblePositionManager, "npm"), swapRouter02: A(p.infrastructure.swapRouter02, "swap"), rialtoRegistry: A(p.infrastructure.rialtoRegistry, "reg"), nvdaStockToken: A(p.infrastructure.nvdaStockToken, "nvda") },
    dependencies, deployments,
    pool: A(a.addressGuards.poolAddress, "pool"), canaryTokenSymbol: STR("BPSC-TEST", "sym", "BPSC-TEST"),
    lp: { feeTier: I(Number(p.economics.feeTier), "lp.fee"), tickSpacing: I(Number(p.economics.tickSpacing), "lp.ts"), sqrtPriceX96: N(lu.sqrtPriceX96, "lp.sq"), tick: SI(lu.poolTickAfter, "lp.tick"), tickLower: SI(lu.tickLower, "lp.tl"), tickUpper: SI(lu.tickUpper, "lp.tu"), amount0Used: N(lu.amount0Used, "lp.a0"), amount1Used: N(lu.amount1Used, "lp.a1"), amount0Min: N(lu.amount0Min, "lp.a0m"), amount1Min: N(lu.amount1Min, "lp.a1m"), poolLiquidityAfter: N(lu.poolLiquidityAfter, "lp.liq"), token0: A(lu.token0, "lp.t0"), token1: A(lu.token1, "lp.t1"), positionOwner: A(lu.positionOwner, "lp.owner"), positionFee: I(lu.positionFee, "lp.pf") },
    buy: { tradeId: N(bu.tradeId, "b.id"), trader: A(bu.trader, "b.tr"), recipient: A(bu.recipient, "b.rc"), adapter: A(bu.adapter, "b.ad"), stockBudgetRecipient: A(bu.stockBudgetRecipient, "b.sbr"), grossWethInput: N(bu.grossWethInput, "b.g"), stockBudget: N(bu.stockBudget2pct, "b.s"), burnBudget: N(bu.burnBudget1pct, "b.bn"), userWethBudget: N(bu.userWethBudget97pct, "b.u"), userBpsOutput: N(bu.userBpsOutput, "b.ub"), bpsBurned: N(bu.bpsBurned, "b.bb"), minimumUserBpsOutput: N(bu.minimumUserBpsOutput, "b.min") },
    sell: { tradeId: N(se.tradeId, "s.id"), trader: A(se.trader, "s.tr"), recipient: A(se.recipient, "s.rc"), adapter: A(se.adapter, "s.ad"), stockBudgetRecipient: A(se.stockBudgetRecipient, "s.sbr"), grossBpsInput: N(se.grossBpsInput, "s.g"), grossWethOutput: N(se.grossWethOutput, "s.gwo"), stockBudget: N(se.stockAcquisition2pct, "s.s"), burnBudget: N(se.retirementBurn2pct, "s.bn"), userWethOutput: N(se.userWethOutput96pct, "s.u"), bpsBurned: N(se.bpsBurned, "s.bb"), minimumGrossWethOutput: N(se.minimumGrossWethOutput, "s.mg"), minimumUserWethOutput: N(se.minimumUserWethOutput, "s.mu") },
    lock: { account: A(lk.account, "l.ac"), lockId: N(lk.lockId, "l.id"), principal: N(lk.principal, "l.p"), startTime: N(lk.startTime, "l.st"), duration: I(lk.duration, "l.d"), unlockTime: N(lk.unlockTime, "l.ut"), multiplierBps: I(lk.multiplierBps, "l.m"), policyVersion: I(lk.policyVersion, "l.pv") },
    transactions: { count: I(a.immediateTransactions.length, "txc") === 18 ? 18 : (err.push("txc"), 0), immediate: a.immediateTransactions.map(sigStep), delayed: { disabled: BT(true, "del") } },
    exposure: { actualStep1GasCostWei, remainingPrincipalWei, remainingMaxGasWei, aggregateWei, aggregateMicroUsd: N(ca.aggregateMicroUsd, "exp.micro") },
    provenance: { repoHead: STR(a.provenance.repoHead, "ph"), dirtyTrackedTree: a.provenance.dirtyTrackedTree === false ? false : (err.push("dirty"), true) },
    digests: { remainingExecutionDigest: HH(a.meta.remainingExecutionDigest, "red") },
    delayedWithdrawalDisabled: BT(true, "dwd"),
  };
  return { errors: err, object };
}

const RECOVERY_TOP_KEYS = ["schema", "version", "canary", "production", "chainId", "scope", "flags", "executable", "maxAllInclusiveExposureUsd", "generatedAtUtc", "expiresAtUtc", "validityWindowSeconds", "wallets", "v5", "originalPlan", "completedStep1", "remaining", "block", "snapshotBalances", "completedTokenAddress", "completedTokenCodeHash", "infrastructure", "dependencies", "deployments", "pool", "canaryTokenSymbol", "lp", "buy", "sell", "lock", "transactions", "exposure", "provenance", "digests", "delayedWithdrawalDisabled"];
export function validateRecoveryStrict(loaded, rawText, getAddress) {
  const err = [];
  if (!loaded || typeof loaded !== "object") return ["not an object"];
  for (const k of Object.keys(loaded)) if (!RECOVERY_TOP_KEYS.includes(k)) err.push("unknown key " + k);
  for (const k of RECOVERY_TOP_KEYS) if (!(k in loaded)) err.push("missing key " + k);
  if (loaded.schema !== RECOVERY_SCHEMA) err.push("schema");
  if (loaded.version !== RECOVERY_VERSION) err.push("version");
  if (loaded.chainId !== 4663) err.push("chainId");
  if (loaded.maxAllInclusiveExposureUsd !== 130) err.push("cap");
  const chkAddr = (x, w) => { if (typeof x !== "string" || !/^0x[0-9a-fA-F]{40}$/.test(x) || getAddress(x) !== x) err.push("non-canonical-address " + w); };
  const chkDec = (x, w) => { if (!isDec(x)) err.push("non-canonical-number " + w); };
  const chkHash = (x, w) => { if (typeof x !== "string" || !/^0x[0-9a-f]{64}$/.test(x)) err.push("non-canonical-hash " + w); };
  ["deployer", "tester"].forEach(k => chkAddr(loaded.wallets && loaded.wallets[k], "wallets." + k));
  if (loaded.infrastructure) for (const [k, v] of Object.entries(loaded.infrastructure)) chkAddr(v, "infra." + k);
  chkAddr(loaded.pool, "pool"); chkAddr(loaded.completedTokenAddress, "completedTokenAddress");
  if (loaded.completedStep1) { chkHash(loaded.completedStep1.txHash, "c1.txHash"); chkAddr(loaded.completedStep1.createdAddress, "c1.created"); chkDec(loaded.completedStep1.actualGasCostWei, "c1.cost"); }
  if (loaded.deployments) for (const [k, d] of Object.entries(loaded.deployments)) { chkAddr(d.predictedAddress, "deploy." + k); chkHash(d.runtimeCodeHash, "deploy.hash." + k); }
  if (loaded.exposure) ["actualStep1GasCostWei", "remainingPrincipalWei", "remainingMaxGasWei", "aggregateWei", "aggregateMicroUsd"].forEach(k => chkDec(loaded.exposure[k], "exposure." + k));
  if (loaded.transactions) {
    const im = loaded.transactions.immediate || [];
    if (loaded.transactions.count !== 18 || im.length !== 18) err.push("tx count");
    if (!im.map(t => t.originalIndex).every((v, i) => v === i + 2)) err.push("original indices not 2..19");
    if (im.some(t => t.originalIndex === 1)) err.push("step 1 present in signables");
    for (const t of im) { chkAddr(t.signer, "tx.signer"); if (t.to !== null) chkAddr(t.to, "tx.to"); ["value", "gasLimit", "maxFeePerGas", "maxPriorityFeePerGas"].forEach(k => chkDec(t[k], "tx." + k)); if (t.type !== 2) err.push("tx.type"); if (t.chainId !== 4663) err.push("tx.chainId"); ["gasLimitCeiling", "maxFeeCeilingWei", "maxPriorityCeilingWei", "maxGasCostCeilingWei"].forEach(k => chkDec(t.gasCeilings[k], "gc." + k)); }
  }
  return err;
}
