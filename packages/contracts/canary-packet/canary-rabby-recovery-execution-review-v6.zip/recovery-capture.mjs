// TASK 10D-5 — independently verify the completed original step-1 transaction + capture the fresh live
// recovery state from the configured provider RPC (env only; URL never printed/written). Read-only.
// Writes recovery-anchor.json (the verified completed-step-1 anchor) and recovery-snapshot.json (live state
// for the remaining 18 transactions). Fails closed (non-zero exit) if any required condition is false.
import { readFileSync, writeFileSync } from "node:fs";
import { createPublicClient, http, keccak256, getContractAddress, getAddress, toHex } from "viem";

const U = (p) => new URL(p, import.meta.url);
const policy = JSON.parse(readFileSync(U("review-policy.json"), "utf8"));
const packet = JSON.parse(readFileSync(U("canary-unsigned-packet.json"), "utf8"));
const ENV = policy.liveRpcEnvVar || "ROBINHOOD_CHAIN_RPC_URL";
const RPC = process.env[ENV];
if (!RPC) { console.error(`FAIL: ${ENV} not set`); process.exit(1); }
const c = createPublicClient({ transport: http(RPC) });
const rpc = (m, p = []) => c.request({ method: m, params: p });
const B = (x) => BigInt(x);
const A = (x) => getAddress(x);

const DEPLOYER = A(policy.wallets.deployer), TESTER = A(policy.wallets.tester);
const IN = policy.infrastructure;
const ANCHOR_HASH = "0x36acf3e3752e0cfc2688c280680c4a9a100e3fcb2520bf41ae723f1a05612e2c"; // approved completed step-1 tx
const V5_ZIP_SHA = "5a6246ca51bd3237e6d925153439d9040b1c3674c0e026e9d8f187e7a5e64b3b";
const V5_REVIEWED_AUTH_DIGEST = "0x4fdfd36b99d6090fef67f21bd3b2027e8dc7e339861ae94eb0f292da2b6ee248";

// the ORIGINAL 8 predicted deployment addresses (deployer start nonce 3), from the rehearsal packet
const step1 = packet.immediateTransactions[0];                        // BPSCanaryToken deploy (nonce 3)
const canaryPredicted = A(getContractAddress({ from: DEPLOYER, nonce: 3n }));
const remainingDeployPredicted = {};                                   // slots at nonces 4..10
const slots = ["lockingVault", "claimManager", "rialtoAdapter", "coordinator", "stockVault", "uniswapAdapter", "tradeRouter"];
slots.forEach((s, i) => remainingDeployPredicted[s] = A(getContractAddress({ from: DEPLOYER, nonce: BigInt(4 + i) })));

const fails = [];
const need = (cond, msg) => { if (!cond) fails.push(msg); return !!cond; };

const erc20View = async (to, sig, decode) => { const r = await rpc("eth_call", [{ to, data: keccak256(hexUtf8(sig)).slice(0, 10) }, "latest"]); return decode(r); };
function hexUtf8(s) { let h = "0x"; for (let i = 0; i < s.length; i++) { const cc = s.charCodeAt(i); h += (cc < 16 ? "0" : "") + cc.toString(16); } return h; }
const decUint = (r) => B(r);
const decBool = (r) => B(r) === 1n;
const decStr = (r) => { const len = Number(B("0x" + r.slice(66, 130))); const hex = r.slice(130, 130 + len * 2); const bytes = new Uint8Array(len); for (let i = 0; i < len; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16); return new TextDecoder("utf-8").decode(bytes); };

async function main() {
  const chainId = Number(B(await rpc("eth_chainId")));
  need(chainId === 4663, `provider chainId ${chainId} != 4663`);

  // ---- (1) verify the completed step-1 transaction + receipt ----
  const tx = await rpc("eth_getTransactionByHash", [ANCHOR_HASH]);
  const rc = await rpc("eth_getTransactionReceipt", [ANCHOR_HASH]);
  need(!!tx, "anchor tx not found on chain");
  need(!!rc, "anchor receipt not found on chain");
  if (tx && rc) {
    need(rc.transactionHash.toLowerCase() === ANCHOR_HASH.toLowerCase(), "receipt hash != anchor");
    need(B(rc.status) === 1n, "receipt status not success");
    // tx-response chainId: absent is acceptable ONLY because eth_chainId==4663 is independently required
    if (tx.chainId !== undefined && tx.chainId !== null) need(Number(B(tx.chainId)) === 4663, "tx-response chainId present and != 4663");
    need(A(tx.from) === DEPLOYER, "sender != deployer");
    need(Number(B(tx.nonce)) === 3, "nonce != 3");
    need(tx.to === null || tx.to === undefined, "not a contract creation");
    need(B(tx.value) === 0n, "value != 0");
    need(Number(B(tx.type)) === 2, "not EIP-1559 type-2");
    need(tx.input.toLowerCase() === step1.dataOrInitCode.toLowerCase(), "input != canonical step-1 calldata");
    need(keccak256(tx.input).toLowerCase() === step1.dataKeccak.toLowerCase(), "input keccak != canonical");
    need(A(rc.contractAddress) === canaryPredicted, "created address != predicted BPSCanaryToken");
    // deployed runtime code hash + size vs accepted artifact
    const code = await rpc("eth_getCode", [rc.contractAddress, "latest"]);
    const runtimeHash = keccak256(code), codeSize = (code.length - 2) / 2;
    need(runtimeHash.toLowerCase() === packet.deployedRuntimeCodeHashes.canaryToken.toLowerCase(), "deployed runtime hash != artifact");
    need(runtimeHash.toLowerCase() === packet.provenance.contracts.BPSCanaryToken.runtimeBytecodeKeccak.toLowerCase(), "deployed runtime hash != provenance");
    // constructor effects: name/symbol/decimals/totalSupply/deployer allocation/canary marker
    const MAX_SUPPLY = 1000000000n * 10n ** 18n;
    const [name, symbol, decimals, supply, bal, isCanary] = await Promise.all([
      erc20View(rc.contractAddress, "name()", decStr), erc20View(rc.contractAddress, "symbol()", decStr),
      erc20View(rc.contractAddress, "decimals()", decUint), erc20View(rc.contractAddress, "totalSupply()", decUint),
      rpc("eth_call", [{ to: rc.contractAddress, data: keccak256(hexUtf8("balanceOf(address)")).slice(0, 10) + DEPLOYER.slice(2).toLowerCase().padStart(64, "0") }, "latest"]).then(decUint),
      erc20View(rc.contractAddress, "IS_CANARY()", decBool),
    ]);
    need(name === "BPS Canary — TEST ONLY", "token name mismatch: " + name);
    need(symbol === "BPSC-TEST", "token symbol mismatch: " + symbol);
    need(decimals === 18n, "decimals != 18");
    need(supply === MAX_SUPPLY, "totalSupply != MAX_SUPPLY");
    need(bal === MAX_SUPPLY, "deployer allocation != MAX_SUPPLY");
    need(isCanary === true, "IS_CANARY != true");
    // exact expected construction logs: exactly one ERC20 Transfer(0x0 -> deployer, MAX_SUPPLY) from the token
    const t0 = keccak256(hexUtf8("Transfer(address,address,uint256)")).toLowerCase();
    const mint = rc.logs.filter(l => A(l.address) === A(rc.contractAddress) && l.topics[0].toLowerCase() === t0);
    need(rc.logs.length === 1 && mint.length === 1, "expected exactly one construction log");
    if (mint[0]) { const from0 = "0x" + mint[0].topics[1].slice(26), to = A("0x" + mint[0].topics[2].slice(26)), amt = B(mint[0].data); need(B(from0) === 0n && to === DEPLOYER && amt === MAX_SUPPLY, "mint log (from/to/amount) mismatch"); }
    // receipt gas accounting internal consistency
    const gasUsed = B(rc.gasUsed), effPrice = B(rc.effectiveGasPrice);
    need(gasUsed > 0n && effPrice > 0n && gasUsed <= B(tx.gas), "receipt gas accounting inconsistent");
    const actualGasCostWei = gasUsed * effPrice;
    // no conflicting/replacement tx at deployer nonce 3: the deployer nonce has advanced past 3 and THIS tx
    // (from=deployer, nonce=3) is mined & successful, so it is the canonical nonce-3 transaction.
    const dNonceLatest = Number(B(await rpc("eth_getTransactionCount", [DEPLOYER, "latest"])));
    need(dNonceLatest >= 4, "deployer nonce has not advanced past 3");

    var anchor = {
      note: "VERIFIED completed original step 1 (BPSCanaryToken deploy). Non-actionable in v6.",
      txHash: ANCHOR_HASH, from: DEPLOYER, nonce: 3, type: 2, to: null, value: "0",
      inputKeccak: step1.dataKeccak, createdAddress: A(rc.contractAddress),
      blockNumber: B(rc.blockNumber).toString(), blockHash: rc.blockHash,
      gasLimit: B(tx.gas).toString(), maxFeePerGas: B(tx.maxFeePerGas).toString(), maxPriorityFeePerGas: B(tx.maxPriorityFeePerGas).toString(),
      gasUsed: gasUsed.toString(), effectiveGasPriceWei: effPrice.toString(), actualGasCostWei: actualGasCostWei.toString(),
      deployedRuntimeCodeHash: runtimeHash, deployedCodeSize: codeSize,
      token: { name, symbol, decimals: Number(decimals), totalSupply: supply.toString(), deployerAllocation: bal.toString(), isCanary: true, maxSupply: MAX_SUPPLY.toString() },
      chainIdInResponse: (tx.chainId === undefined || tx.chainId === null) ? "absent" : Number(B(tx.chainId)),
    };
  }

  // ---- (2 preconditions) fresh live recovery snapshot ----
  const dLatest = Number(B(await rpc("eth_getTransactionCount", [DEPLOYER, "latest"])));
  const dPending = Number(B(await rpc("eth_getTransactionCount", [DEPLOYER, "pending"])));
  const tLatest = Number(B(await rpc("eth_getTransactionCount", [TESTER, "latest"])));
  const tPending = Number(B(await rpc("eth_getTransactionCount", [TESTER, "pending"])));
  need(dLatest === 4 && dPending === 4, `deployer nonce ${dLatest}/${dPending} != 4/4`);
  need(tLatest === 2 && tPending === 2, `tester nonce ${tLatest}/${tPending} != 2/2`);

  const head = B(await rpc("eth_blockNumber"));
  const pinned = head - 3n;
  const blk = await rpc("eth_getBlockByNumber", [toHex(pinned), false]);

  // completed token has exactly the expected code; the OTHER seven predicted deployment addresses are empty
  const canaryCode = await rpc("eth_getCode", [canaryPredicted, "latest"]);
  need(keccak256(canaryCode).toLowerCase() === packet.deployedRuntimeCodeHashes.canaryToken.toLowerCase(), "completed token code changed");
  const remainingEmpty = {};
  for (const [s, addr] of Object.entries(remainingDeployPredicted)) { const cc = await rpc("eth_getCode", [addr, "latest"]); remainingEmpty[s] = { address: addr, empty: cc === "0x" || cc === "0x0" }; need(remainingEmpty[s].empty, `remaining predicted ${s} is not empty`); }

  // six external dependency code hashes + sizes remain exact vs the rehearsal snapshot
  const deps = {};
  for (const [k, addr] of Object.entries({ weth: IN.weth, uniswapV3Factory: IN.uniswapV3Factory, nonfungiblePositionManager: IN.nonfungiblePositionManager, swapRouter02: IN.swapRouter02, rialtoRegistry: IN.rialtoRegistry, nvdaStockToken: IN.nvdaStockToken })) {
    const code = await rpc("eth_getCode", [addr, "latest"]); deps[k] = { address: A(addr), runtimeCodeHash: keccak256(code), codeBytes: (code.length - 2) / 2 };
  }

  const ethBal = { deployer: (await rpc("eth_getBalance", [DEPLOYER, "latest"]).then(B)).toString(), tester: (await rpc("eth_getBalance", [TESTER, "latest"]).then(B)).toString() };
  const wethBal = {
    deployer: (await rpc("eth_call", [{ to: IN.weth, data: keccak256(hexUtf8("balanceOf(address)")).slice(0, 10) + DEPLOYER.slice(2).toLowerCase().padStart(64, "0") }, "latest"]).then(B)).toString(),
    tester: (await rpc("eth_call", [{ to: IN.weth, data: keccak256(hexUtf8("balanceOf(address)")).slice(0, 10) + TESTER.slice(2).toLowerCase().padStart(64, "0") }, "latest"]).then(B)).toString(),
  };

  if (fails.length) { console.error("RECOVERY CAPTURE FAILED:\n - " + fails.join("\n - ")); process.exit(1); }

  writeFileSync(U("recovery-anchor.json"), JSON.stringify({ v5ZipSha256: V5_ZIP_SHA, v5ReviewedAuthorizationDigest: V5_REVIEWED_AUTH_DIGEST, completedStep1: anchor }, null, 2));
  writeFileSync(U("recovery-snapshot.json"), JSON.stringify({
    kind: "fresh live recovery snapshot (post original step 1); URL read from env, never recorded",
    capturedAtUtc: new Date().toISOString(), chainId: Number(chainId), head: head.toString(),
    pinnedBlock: { number: pinned.toString(), hash: blk.hash, parentHash: blk.parentHash, timestamp: B(blk.timestamp).toString(), baseFeePerGasWei: B(blk.baseFeePerGas).toString(), gasLimit: B(blk.gasLimit).toString() },
    wallets: { deployer: DEPLOYER, tester: TESTER },
    nonces: { deployer: dLatest, tester: tLatest }, pendingNonces: { deployer: dPending, tester: tPending },
    expectedNonces: { deployer: 4, tester: 2 },
    completedTokenAddress: canaryPredicted, completedTokenCodeHash: keccak256(canaryCode),
    remainingPredictedDeploymentAddresses: remainingEmpty, allRemainingPredictedEmpty: Object.values(remainingEmpty).every(x => x.empty),
    externalCodeHashes: deps, balances: { eth: ethBal, weth: wethBal },
  }, null, 2));
  console.log("recovery capture OK");
  console.log("  step-1 anchor:", ANCHOR_HASH, "block", anchor.blockNumber, "created", anchor.createdAddress);
  console.log("  actual step-1 gas cost wei:", anchor.actualGasCostWei);
  console.log("  live nonces deployer", dLatest + "/" + dPending, "tester", tLatest + "/" + tPending, "| pinned", pinned.toString(), "baseFee", B(blk.baseFeePerGas).toString());
  console.log("  remaining predicted all empty:", Object.values(remainingEmpty).every(x => x.empty));
}
main().catch(e => { console.error("RECOVERY CAPTURE ERROR:", e.message); process.exit(1); });
