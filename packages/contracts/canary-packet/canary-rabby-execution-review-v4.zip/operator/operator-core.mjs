// TASK 10D-2 — provider-agnostic canary EXECUTION operator engine (fail-closed + restart-safe).
// SAFETY: never handles a key/seed/keystore/raw signature; never eth_sendRawTransaction; no local signer,
// session keys, AA, batching, auto-send, or auto-retry. One eth_sendTransaction per step, explicit only.
//
// States: bound -> connected -> reconciled. preconditions()/sendCurrent() fail closed unless ALL THREE.
// Durable state (keyed by executionPacketDigest): journal, pending, halt/uncertain-send. current step is
// NEVER trusted from raw localStorage length — it is set only by reconcile() after exact validation of
// every journal tx + receipt + a cumulative current-state checkpoint (no in-memory _before dependence).

import { buildCanonical, digestOf, validateStrict, rawDuplicateKeys } from "./canonical.mjs";

const FORBIDDEN_METHODS = new Set(["eth_sendRawTransaction", "eth_sign", "personal_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v4", "wallet_addEthereumChain", "wallet_switchEthereumChain"]);
const SCOPE = "BPSC-TEST canary only; Robinhood Chain mainnet; maximum all-inclusive exposure $130; individual Rabby approvals; canonical BPS production excluded.";
const EVSIG = {
  erc20Approval: "Approval(address,address,uint256)",
  erc20Transfer: "Transfer(address,address,uint256)",
  erc721Transfer: "Transfer(address,address,uint256)",
  poolCreated: "PoolCreated(address,address,uint24,int24,address)",
  poolInitialize: "Initialize(uint160,int24)",
  increaseLiquidity: "IncreaseLiquidity(uint256,uint128,uint256,uint256)",
  officialBuy: "OfficialBuy(uint256,address,address,uint256,uint256,uint256,uint256,uint256,uint256,address,address)",
  officialSell: "OfficialSell(uint256,address,address,uint256,uint256,uint256,uint256,uint256,uint256,address,address)",
  lockCreated: "LockCreated(address,uint256,uint256,uint64,uint32,uint64,uint16,uint16)",
};

export class CanaryOperator {
  constructor({ packet, policy, snapshot, reviewedAuthorization, reviewedAuthorizationRaw, provider, keccak256, getAddress, priceProvider, storage, now = () => Date.now(), receiptPolls = 180, pollMs = 500 }) {
    this.packet = packet; this.policy = policy; this.snapshot = snapshot;
    // (10D-3) the packaged canonical reviewed-authorization object is the SINGLE bound runtime data source.
    this.reviewedAuthorization = reviewedAuthorization || null;
    this.reviewedAuthorizationRaw = reviewedAuthorizationRaw || (reviewedAuthorization ? JSON.stringify(reviewedAuthorization) : null);
    this.canon = null;
    this.keccak256 = keccak256; this.getAddress = getAddress; this.priceProvider = priceProvider;
    this.storage = storage || memStore(); this.now = now; this.receiptPolls = receiptPolls; this.pollMs = pollMs;
    this.DEPLOYER = getAddress(policy.wallets.deployer); this.TESTER = getAddress(policy.wallets.tester);
    this.WETH = getAddress(policy.infrastructure.weth); this.NPM = getAddress(policy.infrastructure.nonfungiblePositionManager);
    this.FACTORY = getAddress(policy.infrastructure.uniswapV3Factory); this.NVDA = getAddress(policy.infrastructure.nvdaStockToken);
    this.SWAP = getAddress(policy.infrastructure.swapRouter02); this.REGISTRY = getAddress(policy.infrastructure.rialtoRegistry);
    this.execDigest = packet.meta.executionPacketDigest;
    this.steps = packet.immediateTransactions.map((t, i) => ({ index: i, ...t }));
    this.delayedDisabled = true;
    this.addr = {}; const slots = ["canaryToken", "lockingVault", "claimManager", "rialtoAdapter", "coordinator", "stockVault", "uniswapAdapter", "tradeRouter"];
    const deploys = this.steps.filter(s => s.phase === "A-deploy").sort((a, b) => a.nonce - b.nonce);
    deploys.forEach((s, i) => this.addr[slots[i]] = getAddress(s.predictedCreationAddress));
    this.pool = getAddress(packet.addressGuards.poolAddress);
    // explicit states — start fully closed
    this.bound = false; this.connected = false; this.reconciled = false;
    this.halted = false; this.haltReason = null; this.uncertainSend = null;
    // durable state (keyed by digest)
    this._kHalt = "canary:halt:" + this.execDigest; this._kJournal = "canary:journal:" + this.execDigest; this._kPending = "canary:pending:" + this.execDigest;
    const h = JSON.parse(this.storage.get(this._kHalt) || "null");
    if (h) { this.halted = true; this.haltReason = h.reason; this.uncertainSend = h.uncertainSend || null; }
    this.journal = JSON.parse(this.storage.get(this._kJournal) || "[]");   // UNTRUSTED until reconcile()
    this.pending = JSON.parse(this.storage.get(this._kPending) || "null");
    this.current = 0; // authoritative only after reconcile()
  }

  _persistHalt(reason, uncertainSend = null) { this.halted = true; this.haltReason = reason; this.uncertainSend = uncertainSend; this.storage.set(this._kHalt, JSON.stringify({ reason, uncertainSend })); }
  _halt(reason) { this._persistHalt(reason, this.uncertainSend); return { ok: false, halted: true, reason }; }
  async _req(provider, method, params = []) { if (FORBIDDEN_METHODS.has(method)) throw new Error("FORBIDDEN wallet method blocked: " + method); return provider.request({ method, params }); }
  _utf8ToHex(s) { let h = "0x"; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h += (c < 16 ? "0" : "") + c.toString(16); } return h; }
  _stable(v) { return Array.isArray(v) ? "[" + v.map(x => this._stable(x)).join(",") + "]" : (v && typeof v === "object") ? "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + this._stable(v[k])).join(",") + "}" : JSON.stringify(v); }
  _signable(t) { return { chainId: t.chainId, signer: this.getAddress(t.signer), nonce: t.nonce, type: 2, to: t.to ? this.getAddress(t.to) : null, value: t.value || "0", data: t.dataOrInitCode, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas }; }
  _signableHash(t) { return this.keccak256(this._utf8ToHex(this._stable(this._signable(t)))); }

  // ---- (1)(5)(10D-3) bind: canonical reviewed-authorization anchoring + full packet/policy/snapshot binding ----
  bindAndVerifyPacket() {
    const a = this.packet, p = this.policy, s = this.snapshot, c = {}, A = this.getAddress;

    // ===== (10D-3) CANONICAL REVIEWED-AUTHORIZATION BINDING (authoritative) =====
    // Reconstruct the canonical object over EVERY security-relevant leaf from the runtime inputs, and require
    // three INDEPENDENT digest anchors (packet, policy, packaged operator) to agree with it. A single leaf
    // mutation changes the reconstruction digest; recomputing one adjacent anchor cannot make the others agree.
    const recon = buildCanonical({ packet: a, policy: p, snapshot: s, getAddress: A });
    c.canonicalReconstructs = recon.errors.length === 0;
    const digestR = recon.object ? digestOf(recon.object, this.keccak256) : null;
    const pkg = this.reviewedAuthorization, raw = this.reviewedAuthorizationRaw || (pkg ? JSON.stringify(pkg) : "");
    const strictErr = pkg ? validateStrict(pkg, raw, A) : ["packaged reviewed-authorization missing"];
    const dupKeys = pkg ? rawDuplicateKeys(raw) : ["<missing>"];
    c.packagedReviewedAuthorizationValid = strictErr.length === 0;
    c.packagedNoDuplicateKeys = dupKeys.length === 0;
    const digestP = pkg ? digestOf(pkg, this.keccak256) : null;
    const anchorPacket = a.meta && a.meta.reviewedAuthorizationDigest, anchorPolicy = p.reviewedAuthorizationDigest;
    const eq = (x, y) => !!x && !!y && String(x).toLowerCase() === String(y).toLowerCase();
    // ALL FOUR must be identical: reconstruction, packaged, packet anchor, policy anchor.
    c.reviewedDigestAnchorsAgree = eq(digestR, digestP) && eq(digestR, anchorPacket) && eq(digestR, anchorPolicy);
    // reconstruction must structurally equal the packaged bound object (defense in depth beyond the digest)
    c.reconMatchesPackaged = !!recon.object && !!pkg && this._stable(recon.object) === this._stable(pkg);

    // per-index coverage: recompute digest over EXACTLY the ordered per-index signables; also require the
    // step array to line up 1:1 with immediate txs (index i, expected sequential nonce), delayed appended.
    const perIndex = a.immediateTransactions.map((t, i) => ({ i, ...this._signable(t) }));
    const recomputed = this.keccak256(this._utf8ToHex(this._stable(a.immediateTransactions.concat([a.delayedWithdrawalSubPacket]).map(t => this._signable(t)))));
    c.execDigestMatches = recomputed.toLowerCase() === this.execDigest.toLowerCase();
    const dstart = a.meta.startNonces.deployer, tstart = a.meta.startNonces.tester; let di = 0, tii = 0, cov = true;
    a.immediateTransactions.forEach((t, i) => { if (this.steps[i].index !== i) cov = false; const exp = A(t.signer) === this.DEPLOYER ? dstart + (di++) : tstart + (tii++); if (t.nonce !== exp) cov = false; });
    c.perIndexCoverage = cov && this.steps.length === a.immediateTransactions.length && perIndex.length === a.immediateTransactions.length;
    // chain / canary / production / scope / wallets
    c.chainId4663 = a.meta.chainId === 4663 && p.chainId === 4663;
    c.canaryNotProduction = a.meta.authorization && a.meta.authorization.canary === true && a.meta.authorization.production === false && p.canary === true && p.production === false;
    c.scopeExact = a.meta.authorization && a.meta.authorization.scope === SCOPE && p.authorizationScope === SCOPE;
    c.walletsConsistent = A(p.wallets.deployer) === A(a.meta.deployer) && A(p.wallets.tester) === A(a.meta.tester);
    c.noncesConsistent = a.meta.startNonces.deployer === s.nonces.deployer && a.meta.startNonces.tester === s.nonces.tester && p.expectedNonces.deployer === s.nonces.deployer && p.expectedNonces.tester === s.nonces.tester;
    // snapshot (block/hash/ts/baseFee) across policy, packet meta, block-snapshot
    c.snapshotConsistent = String(s.pinnedBlock.number) === String(p.snapshot.forkBlock) && s.pinnedBlock.hash.toLowerCase() === p.snapshot.forkHash.toLowerCase() && a.meta.forkBlock === String(p.snapshot.forkBlock) && a.meta.forkBlockHash.toLowerCase() === p.snapshot.forkHash.toLowerCase() && a.meta.forkTimestamp === String(p.snapshot.forkTimestamp) && a.meta.forkBaseFeePerGasWei === p.snapshot.baseFeePerGasWei && String(s.pinnedBlock.baseFeePerGasWei) === p.snapshot.baseFeePerGasWei;
    // infrastructure addresses: policy == packet.addressGuards.infrastructure (WETH/factory/NPM/swap/registry/pool)
    const infra = new Set(a.addressGuards.infrastructure.map(x => A(x)));
    c.infraConsistent = [p.infrastructure.weth, p.infrastructure.uniswapV3Factory, p.infrastructure.nonfungiblePositionManager, p.infrastructure.swapRouter02, p.infrastructure.rialtoRegistry, a.addressGuards.poolAddress].every(x => infra.has(A(x)));
    // gas limits + fee bounds: policy.gas == packet.reviewPolicySnapshot.gas; feeBounds match policy
    c.gasConsistent = a.reviewPolicySnapshot && this._stable(a.reviewPolicySnapshot.gas) === this._stable(p.gas) && a.meta.feeBounds.maxFeePerGasWei === p.gas.maxFeePerGasWei && a.meta.feeBounds.maxPriorityFeePerGasWei === p.gas.maxPriorityFeePerGasWei && a.meta.feeBounds.pinnedBaseFeePerGasWei === p.snapshot.baseFeePerGasWei;
    // caps: policy.caps == packet.reviewPolicySnapshot.caps
    c.capsConsistent = a.reviewPolicySnapshot && this._stable(a.reviewPolicySnapshot.caps) === this._stable(p.caps);
    // validity
    c.validityConsistent = a.meta.validityWindowSeconds === p.validity.windowSeconds && !!a.meta.expiresAtUtc && !!a.meta.generatedAtUtc;
    // authorization flags true in packet AND policy
    c.flagsAuthorized = ["broadcastReady", "liveWritesApproved", "executionAuthorized", "fundingAuthorized"].every(k => a.safetyFlags[k] === true && p.safetyFlags[k] === true);
    // runtime cap must equal exactly $130 in the reconstruction (the canonical object binds it)
    c.capIs130 = !!recon.object && recon.object.maxAllInclusiveExposureUsd === 130;
    // dependency hashes recorded (per-tx live check happens in preconditions/reconcile)
    c.dependencyHashesRecorded = a.addressGuards && s.externalCodeHashes && Object.keys(s.externalCodeHashes).length === 6;
    const ok = Object.values(c).every(Boolean);
    this.bound = ok;
    if (!ok) { this._halt("packet binding failed: " + Object.entries(c).filter(([, v]) => !v).map(([k]) => k).join(",")); return { ok, digest: recomputed, reviewedAuthorizationDigest: digestR, checks: c }; }

    // ===== (10D-3) SINGLE BOUND RUNTIME DATA SOURCE =====
    // After binding, ALL security-relevant runtime values come ONLY from the validated, digest-anchored
    // canonical object — never re-read from a second mutable policy/snapshot path.
    const cc = pkg; this.canon = cc;
    this.capMicro = BigInt(cc.maxAllInclusiveExposureUsd) * 1_000_000n;
    this.DEPLOYER = A(cc.wallets.deployer); this.TESTER = A(cc.wallets.tester);
    this.WETH = A(cc.infrastructure.weth); this.FACTORY = A(cc.infrastructure.uniswapV3Factory); this.NPM = A(cc.infrastructure.nonfungiblePositionManager);
    this.SWAP = A(cc.infrastructure.swapRouter02); this.REGISTRY = A(cc.infrastructure.rialtoRegistry); this.NVDA = A(cc.infrastructure.nvdaStockToken);
    this.pool = A(cc.pool); this.addr = {}; for (const k of Object.keys(cc.predicted)) this.addr[k] = A(cc.predicted[k]);
    this._expiresAtUtc = cc.expiresAtUtc;
    this._exposurePrincipalWei = cc.exposure.totalPrincipalWei; this._exposureGasWei = cc.exposure.totalMaxGasWei;
    this._authFlags = cc.flags;
    return { ok, digest: recomputed, reviewedAuthorizationDigest: digestR, checks: c };
  }

  // (1) connection state — verify chain + that accounts are exposed (connection approved by user in wallet)
  async markConnected(provider) {
    if (!this.bound) return { ok: false, reason: "not bound" };
    if (this.halted) return { ok: false, halted: true, reason: this.haltReason };
    if (BigInt(await this._req(provider, "eth_chainId")) !== 4663n) return { ok: false, reason: "wrong chain (need 4663/0x1237); switch Rabby manually" };
    const accts = await this._req(provider, "eth_accounts");
    if (!Array.isArray(accts) || accts.length === 0) return { ok: false, reason: "no account exposed" };
    this.connected = true; return { ok: true };
  }

  _statesReady() { return this.bound && this.connected && this.reconciled && !this.halted && !this.uncertainSend; }

  // ---- (5)(6) fresh live-price exposure ----
  async _exposureGate() {
    if (!this.priceProvider) return { ok: false, reason: "no price provider" };
    let pr; try { pr = await this.priceProvider(); } catch (e) { return { ok: false, reason: "price fetch failed: " + (e && e.message) }; }
    if (!pr || typeof pr.coinbaseMicroUsd === "undefined" || typeof pr.krakenMicroUsd === "undefined") return { ok: false, reason: "malformed price data" };
    if (!(pr.coinbaseAgeS <= 300 && pr.krakenAgeS <= 300)) return { ok: false, reason: `stale price (coinbase ${pr.coinbaseAgeS}s / kraken ${pr.krakenAgeS}s)` };
    const higher = BigInt(pr.coinbaseMicroUsd) > BigInt(pr.krakenMicroUsd) ? BigInt(pr.coinbaseMicroUsd) : BigInt(pr.krakenMicroUsd);
    // (10D-3) exposure components (WETH principal + maximum gas) come ONLY from the bound canonical object.
    const wei = BigInt(this._exposurePrincipalWei) + BigInt(this._exposureGasWei);
    const exposureMicro = (wei * higher) / 10n ** 18n;
    return { ok: exposureMicro <= this.capMicro, exposureMicro, higher: higher.toString() };
  }

  // ---- pre-transaction gates (fail closed unless bound+connected+reconciled) ----
  async preconditions(provider) {
    if (this.halted) return { ok: false, halted: true, reason: this.haltReason };
    if (this.uncertainSend) return { ok: false, halted: true, reason: "uncertain send pending — reconciliation required" };
    if (!this.bound) return { ok: false, reason: "not bound" };
    if (!this.connected) return { ok: false, reason: "not connected" };
    if (!this.reconciled) return { ok: false, reason: "not reconciled — run reconcile() after Connect" };
    if (this.pending) return { ok: false, pending: true, reason: "a transaction is pending; reconcile first" };
    const i = this.current; if (i >= this.steps.length) return { ok: false, done: true };
    const t = this.steps[i], g = {}, A = this.getAddress;
    g.notExpired = this.now() <= Date.parse(this._expiresAtUtc); // (10D-3) expiry from bound object
    g.correctChain = BigInt(await this._req(provider, "eth_chainId")) === 4663n;
    const accts = await this._req(provider, "eth_accounts"); g.accountSelected = Array.isArray(accts) && accts[0] && A(accts[0]) === A(t.signer);
    // (6) BOTH latest and pending nonce must equal the expected nonce
    const nLatest = Number(BigInt(await this._req(provider, "eth_getTransactionCount", [t.signer, "latest"])));
    const nPending = Number(BigInt(await this._req(provider, "eth_getTransactionCount", [t.signer, "pending"])));
    g.nonceLatestMatches = nLatest === t.nonce; g.noncePendingMatches = nPending === t.nonce;
    g.priorStepsVerified = this.journal.length === i;
    let dep = true; for (const rec of Object.values(this.snapshot.externalCodeHashes)) { if (this.keccak256(await this._req(provider, "eth_getCode", [rec.address, "latest"])) !== rec.runtimeCodeHash) dep = false; }
    g.dependencyHashesUnchanged = dep;
    if (t.phase === "A-deploy") { const cc = await this._req(provider, "eth_getCode", [t.predictedCreationAddress, "latest"]); g.predictedCreateEmpty = cc === "0x" || cc === "0x0"; } else g.predictedCreateEmpty = true;
    const head = await this._req(provider, "eth_getBlockByNumber", ["latest", false]);
    g.baseFeeInBounds = BigInt(head.baseFeePerGas) + BigInt(t.maxPriorityFeePerGas) <= BigInt(t.maxFeePerGas);
    g.ethSufficient = BigInt(await this._req(provider, "eth_getBalance", [t.signer, "latest"])) >= BigInt(t.maxGasCostWei);
    let sim = true; try { const cx = { from: t.signer, data: t.dataOrInitCode, value: "0x0" }; if (t.to) cx.to = t.to; await this._req(provider, "eth_call", [cx, "latest"]); } catch { sim = false; } g.simulationNoRevert = sim;
    let est = true; try { const ex = { from: t.signer, data: t.dataOrInitCode, value: "0x0" }; if (t.to) ex.to = t.to; est = BigInt(await this._req(provider, "eth_estimateGas", [ex])) <= BigInt(t.gasLimit); } catch { est = false; } g.gasEstimateWithinLimit = est;
    const exp = await this._exposureGate(); g.freshExposureWithinCap = exp.ok;
    g.authorizationEnabled = ["broadcastReady", "liveWritesApproved", "executionAuthorized", "fundingAuthorized"].every(k => this._authFlags[k] === true); // (10D-3) from bound object
    const ok = Object.values(g).every(Boolean);
    if (!ok) return this._halt("precondition failed at step " + i + ": " + Object.entries(g).filter(([, v]) => !v).map(([k]) => k).join(","));
    return { ok, step: i, gates: g, exposure: exp, tx: this._buildSendTx(t) };
  }

  _buildSendTx(t) { const tx = { from: this.getAddress(t.signer), value: "0x0", data: t.dataOrInitCode, gas: "0x" + BigInt(t.gasLimit).toString(16), maxFeePerGas: "0x" + BigInt(t.maxFeePerGas).toString(16), maxPriorityFeePerGas: "0x" + BigInt(t.maxPriorityFeePerGas).toString(16), type: "0x2", nonce: "0x" + BigInt(t.nonce).toString(16), chainId: "0x1237" }; if (t.to) tx.to = this.getAddress(t.to); return tx; }

  // ---- send: guarded; persist pending on hash; DURABLE uncertain-send halt on unknown error ----
  async sendCurrent(provider) {
    if (this.halted || this.uncertainSend) return { ok: false, halted: true, reason: this.haltReason || "uncertain send" };
    if (!this._statesReady()) return { ok: false, reason: "states not ready (bound/connected/reconciled)" };
    if (this.pending) return { ok: false, pending: true };
    const pre = await this.preconditions(provider); if (!pre.ok) return pre;
    const t = this.steps[this.current];
    let txHash;
    try { txHash = await this._req(provider, "eth_sendTransaction", [this._buildSendTx(t)]); }
    catch (e) {
      if (e && (e.code === 4001 || /user rejected|user denied/i.test(e.message || ""))) return { ok: false, userRejected: true, step: this.current }; // safe: stay
      // durable uncertain-send: persist even without a tx hash
      this._persistHalt("unknown provider error after eth_sendTransaction invoked — reconciliation required (no blind retry): " + (e && e.message),
        { digest: this.execDigest, step: this.current, signer: this.getAddress(t.signer), nonce: t.nonce, signableTxHash: this._signableHash(t) });
      return { ok: false, halted: true, uncertainSend: true };
    }
    this.pending = { digest: this.execDigest, step: this.current, txHash };
    this.storage.set(this._kPending, JSON.stringify(this.pending));
    return { ok: true, step: this.current, txHash };
  }

  // ---- (4) ONE shared exact tx verifier (initial + restart) ----
  async _verifyTxAndReceipt(provider, t, txHash) {
    const A = this.getAddress;
    const otx = await this._req(provider, "eth_getTransactionByHash", [txHash]);
    if (!otx) return { ok: false, reason: "transaction lookup returned null" };
    if (otx.chainId === undefined || otx.chainId === null) return { ok: false, reason: "missing chainId (no default permitted)" };
    const fieldOk = Number(BigInt(otx.chainId)) === 4663 && A(otx.from) === A(t.signer) && Number(BigInt(otx.nonce)) === t.nonce && Number(BigInt(otx.type)) === 2 &&
      (t.to ? A(otx.to) === A(t.to) : (otx.to === null || otx.to === undefined)) && BigInt(otx.value) === 0n && otx.input.toLowerCase() === t.dataOrInitCode.toLowerCase() &&
      BigInt(otx.gas) === BigInt(t.gasLimit) && BigInt(otx.maxFeePerGas) === BigInt(t.maxFeePerGas) && BigInt(otx.maxPriorityFeePerGas) === BigInt(t.maxPriorityFeePerGas);
    if (!fieldOk) return { ok: false, reason: "tx fields differ from packet" };
    if ((otx.accessList && otx.accessList.length > 0)) return { ok: false, reason: "unexpected non-empty access list" };
    if (otx.blobVersionedHashes || otx.maxFeePerBlobGas) return { ok: false, reason: "unexpected blob fields" };
    let rc = null; for (let k = 0; k < this.receiptPolls; k++) { rc = await this._req(provider, "eth_getTransactionReceipt", [txHash]); if (rc) break; await new Promise(r => setTimeout(r, this.pollMs)); }
    if (!rc) return { ok: false, reason: "receipt timeout" };
    if (rc.transactionHash.toLowerCase() !== txHash.toLowerCase()) return { ok: false, reason: "receipt hash mismatch" };
    if (BigInt(rc.status) !== 1n) return { ok: false, reason: "receipt reverted" };
    if (t.phase === "A-deploy" && A(rc.contractAddress) !== A(t.predictedCreationAddress)) return { ok: false, reason: "deployed address != predicted" };
    return { ok: true, otx, rc };
  }

  // ---- initial post-broadcast verify (shared verifier + receipt-event postcondition) ----
  async verifyAfterHash(provider, txHash) {
    if (this.halted) return { ok: false, halted: true, reason: this.haltReason };
    if (!this.pending || this.pending.txHash.toLowerCase() !== txHash.toLowerCase()) return this._halt("verifyAfterHash for a non-pending hash");
    const i = this.current, t = this.steps[i];
    const v = await this._verifyTxAndReceipt(provider, t, txHash); if (!v.ok) return this._halt("verify at step " + i + ": " + v.reason);
    const post = this._receiptPostcondition(i, v.otx, v.rc); if (!post.ok) return this._halt("postcondition at step " + i + " (" + t.label + "): " + post.reason);
    // cumulative current-state checkpoint appropriate to the just-completed step
    const chk = await this._cumulativeCheckpoint(provider, i, v.rc); if (!chk.ok) return this._halt("checkpoint at step " + i + ": " + chk.reason);
    this.journal.push({ digest: this.execDigest, step: i, txHash, receiptStatus: "success", verified: true });
    this.storage.set(this._kJournal, JSON.stringify(this.journal));
    this.pending = null; this.storage.set(this._kPending, "null");
    this.current += 1;
    return { ok: true, step: i, txHash, postcondition: post, checkpoint: chk, done: this.current >= this.steps.length };
  }

  // ---- (3) receipt-event postcondition: uses ONLY the tx receipt logs + deterministic packet values.
  //      No in-memory _before, no transient current-state (allowance/slot0) reads. Restart-safe. ----
  _receiptPostcondition(i, otx, rc) {
    const t = this.steps[i], A = this.getAddress, a = this.packet, c = this.addr;
    if (t.phase === "A-deploy") return A(rc.contractAddress) === A(t.predictedCreationAddress) ? { ok: true, deployed: A(rc.contractAddress) } : { ok: false, reason: "deploy address" };
    if (t.label.includes("approve")) { const d = t.decodedArgs; const ev = this._decodeEvent(rc.logs, t.to, EVSIG.erc20Approval, [true, true, false]); if (!ev) return { ok: false, reason: "no Approval event" }; const spender = A("0x" + ev.topics[2].slice(26)); return ev.d[0] === BigInt(d.amount) && spender === A(d.spender) ? { ok: true, allowance: ev.d[0].toString() } : { ok: false, reason: "approval value/spender" }; }
    if (t.label === "factory.createPool") { const ev = this._decodeEvent(rc.logs, this.FACTORY, EVSIG.poolCreated, [true, true, true, false, false]); if (!ev) return { ok: false, reason: "no PoolCreated" }; const pool = A("0x" + ev.d[1].toString(16).padStart(40, "0")); return pool === this.pool ? { ok: true, pool } : { ok: false, reason: "pool " + pool }; }
    if (t.label === "pool.initialize") { const ev = this._decodeEvent(rc.logs, this.pool, EVSIG.poolInitialize, [false, false]); if (!ev) return { ok: false, reason: "no Initialize" }; return ev.d[0] === BigInt(a.lpUsage.sqrtPriceX96) ? { ok: true, sqrtPriceX96: ev.d[0].toString() } : { ok: false, reason: "sqrtPriceX96 " + ev.d[0] }; }
    if (t.label === "NPM.mint") { const inc = this._decodeEvent(rc.logs, this.NPM, EVSIG.increaseLiquidity, [true, false, false, false]); const t0 = this.keccak256(this._utf8ToHex(EVSIG.erc721Transfer)).toLowerCase(); let tokenId = null; for (const lg of rc.logs) if (A(lg.address) === this.NPM && lg.topics.length === 4 && lg.topics[0].toLowerCase() === t0) tokenId = BigInt(lg.topics[3]); if (!inc || tokenId === null) return { ok: false, reason: "no IncreaseLiquidity/tokenId" }; const okAll = inc.d[0] === BigInt(a.lpUsage.poolLiquidityAfter) && inc.d[1] === BigInt(a.lpUsage.amount0Used) && inc.d[2] === BigInt(a.lpUsage.amount1Used) && inc.d[1] >= BigInt(a.lpUsage.amount0Min) && inc.d[2] >= BigInt(a.lpUsage.amount1Min); return okAll ? { ok: true, tokenId: tokenId.toString(), liquidity: inc.d[0].toString() } : { ok: false, reason: "mint liquidity/amounts" }; }
    if (t.label === "buyExactWethForBps") { const ev = this._decodeEvent(rc.logs, c.tradeRouter, EVSIG.officialBuy, [true, true, true, false, false, false, false, false, false, false, false]); if (!ev) return { ok: false, reason: "no OfficialBuy" }; const bu = a.buyAccounting; const okAll = ev.d[0] === BigInt(bu.grossWethInput) && ev.d[1] === BigInt(bu.stockBudget2pct) && ev.d[2] === BigInt(bu.burnBudget1pct) && ev.d[3] === BigInt(bu.userWethBudget97pct) && ev.d[4] === BigInt(bu.userBpsOutput) && ev.d[5] === BigInt(bu.bpsBurned) && ev.d[4] >= BigInt(bu.minimumUserBpsOutput); return okAll ? { ok: true, userBpsOutput: ev.d[4].toString() } : { ok: false, reason: "buy event/minimum" }; }
    if (t.label === "sellExactBpsForWeth") { const ev = this._decodeEvent(rc.logs, c.tradeRouter, EVSIG.officialSell, [true, true, true, false, false, false, false, false, false, false, false]); if (!ev) return { ok: false, reason: "no OfficialSell" }; const se = a.sellAccounting; const okAll = ev.d[0] === BigInt(se.grossBpsInput) && ev.d[1] === BigInt(se.grossWethOutput) && ev.d[2] === BigInt(se.stockAcquisition2pct) && ev.d[3] === BigInt(se.retirementBurn2pct) && ev.d[4] === BigInt(se.userWethOutput96pct) && ev.d[5] === BigInt(se.bpsBurned) && ev.d[1] >= BigInt(se.minimumGrossWethOutput) && ev.d[4] >= BigInt(se.minimumUserWethOutput); return okAll ? { ok: true, userWethOutput: ev.d[4].toString() } : { ok: false, reason: "sell event/minimum" }; }
    if (t.label.startsWith("createLock")) { const ev = this._decodeEvent(rc.logs, c.lockingVault, EVSIG.lockCreated, [true, true, false, false, false, false, false, false]); if (!ev) return { ok: false, reason: "no LockCreated" }; const lw = a.lockAndWithdraw; const account = A("0x" + ev.topics[1].slice(26)); return account === this.TESTER && ev.d[0] === BigInt(lw.principal) && ev.d[3] === BigInt(lw.unlockTime) ? { ok: true, principal: ev.d[0].toString(), unlockTime: ev.d[3].toString() } : { ok: false, reason: "lock event" }; }
    return { ok: false, reason: "no postcondition for " + t.label };
  }

  // ---- (3) cumulative current-state checkpoint: only PERSISTENT invariants that hold after later steps.
  //      Reads current chain state (or the receipt) — never in-memory _before, never transient values. ----
  async _cumulativeCheckpoint(provider, uptoStep, mintRcForToken) {
    const A = this.getAddress, c = this.addr, a = this.packet;
    const done = (label) => this.steps.slice(0, uptoStep + 1).some(s => s.label === label);
    const doneDeploy = (name) => this.steps.slice(0, uptoStep + 1).some(s => s.label === name);
    // all deployed-so-far contracts must have code + immutable wiring (immutables persist)
    const W = async (to, sig, exp, args = []) => A(await this._callAddr(provider, to, sig, args)) === A(exp);
    for (let j = 0; j <= uptoStep; j++) { const s = this.steps[j]; if (s.phase !== "A-deploy") continue; const code = await this._req(provider, "eth_getCode", [s.predictedCreationAddress, "latest"]); if (!code || code === "0x") return { ok: false, reason: "missing code " + s.label }; }
    if (doneDeploy("BPSCanaryToken")) { const sym = await this._callString(provider, c.canaryToken, "symbol()"); if (sym !== "BPSC-TEST") return { ok: false, reason: "symbol" }; }
    if (doneDeploy("BPSLockingVault")) { if (!(await W(c.lockingVault, "owner()", this.DEPLOYER) && await W(c.lockingVault, "bpsToken()", c.canaryToken))) return { ok: false, reason: "vault wiring" }; }
    if (doneDeploy("StockAcquisitionVault")) { const nvda = await this._callBool(provider, c.stockVault, "isApprovedStockToken(address)", [this._encAddr(this.NVDA)]); if (!(await W(c.stockVault, "acquisitionExecutor()", c.coordinator) && await W(c.stockVault, "reserveRecipient()", this.DEPLOYER) && nvda)) return { ok: false, reason: "vault immutables/NVDA" }; }
    if (doneDeploy("BPSTradeRouter")) { if (!(await W(c.tradeRouter, "owner()", this.DEPLOYER) && await W(c.tradeRouter, "bpsToken()", c.canaryToken) && await W(c.tradeRouter, "swapAdapter()", c.uniswapAdapter) && await W(c.tradeRouter, "stockBudgetRecipient()", c.stockVault))) return { ok: false, reason: "router wiring" }; }
    // pool exists once created (persists)
    if (done("factory.createPool")) { const p = A(await this._callAddr(provider, this.FACTORY, "getPool(address,address,uint24)", [this._encAddr(this.steps.find(s => s.label === "factory.createPool").decodedArgs.tokenA), this._encAddr(this.steps.find(s => s.label === "factory.createPool").decodedArgs.tokenB), this._encUint(BigInt(this.policy.economics.feeTier))])); if (p !== this.pool) return { ok: false, reason: "pool getPool" }; }
    // LP NFT: ownerOf + liquidity persist (no decrease in the immediate sequence)
    if (done("NPM.mint")) {
      const mintStep = this.steps.find(s => s.label === "NPM.mint");
      const t0 = this.keccak256(this._utf8ToHex(EVSIG.erc721Transfer)).toLowerCase();
      const fromRc = (rc) => { if (!rc) return null; for (const lg of rc.logs) if (A(lg.address) === this.NPM && lg.topics.length === 4 && lg.topics[0].toLowerCase() === t0) return BigInt(lg.topics[3]); return null; };
      // just-executed mint (not yet journalled) -> use the current receipt; else -> journalled receipt
      const tid = (mintStep.index === uptoStep && mintRcForToken) ? fromRc(mintRcForToken) : await this._mintTokenId(provider);
      if (tid === null) return { ok: false, reason: "mint tokenId (checkpoint)" };
      const owner = A(await this._callAddr(provider, this.NPM, "ownerOf(uint256)", [this._encUint(tid)]));
      const pos = await this._call(provider, this.NPM, "positions(uint256)", [this._encUint(tid)]); const liq = BigInt("0x" + pos.slice(2 + 7 * 64, 2 + 8 * 64));
      if (owner !== this.DEPLOYER || liq !== BigInt(a.lpUsage.poolLiquidityAfter)) return { ok: false, reason: "LP NFT owner/liquidity" };
    }
    // lock principal persists (no immediate withdrawal)
    if (done("createLock(amount,7d)")) { const lp = BigInt(await this._callUint(provider, c.lockingVault, "lockedPrincipal(address)", [this._encAddr(this.TESTER)])); if (lp !== BigInt(a.lockAndWithdraw.principal)) return { ok: false, reason: "lockedPrincipal" }; }
    return { ok: true };
  }
  async _mintTokenId(provider) { // recover tokenId from the journalled mint receipt (historical), else null
    const mintStep = this.steps.find(s => s.label === "NPM.mint"); const j = this.journal.find(x => x.step === mintStep.index); if (!j) return null;
    const rc = await this._req(provider, "eth_getTransactionReceipt", [j.txHash]); if (!rc) return null;
    const t0 = this.keccak256(this._utf8ToHex(EVSIG.erc721Transfer)).toLowerCase();
    for (const lg of rc.logs) if (this.getAddress(lg.address) === this.NPM && lg.topics.length === 4 && lg.topics[0].toLowerCase() === t0) return BigInt(lg.topics[3]);
    return null;
  }

  // ---- (1)(3) restart reconciliation: validate EVERY journal tx + receipt exactly (shared verifier +
  //      receipt-event postcondition), then a single cumulative checkpoint for the latest step. Sets
  //      current only from the VALIDATED journal. Handles pending + durable uncertain-send. ----
  async reconcile(provider) {
    if (!this.bound) return { ok: false, reason: "not bound" };
    if (!this.connected) return { ok: false, reason: "not connected" };
    if (this.halted && !this.uncertainSend) return { ok: false, halted: true, reason: this.haltReason };
    // a durable uncertain-send stays halted until resolved with a real tx hash (see resolveUncertainSend)
    if (this.uncertainSend) return { ok: false, halted: true, uncertainSend: this.uncertainSend, reason: "uncertain send — supply a tx hash to resolve, or regenerate under review proving no broadcast" };
    for (let k = 0; k < this.journal.length; k++) {
      const j = this.journal[k];
      if (j.digest !== this.execDigest || j.step !== k) return this._halt("journal step/digest mismatch at " + k);
      const t = this.steps[k];
      const v = await this._verifyTxAndReceipt(provider, t, j.txHash); if (!v.ok) return this._halt("journal verify at step " + k + ": " + v.reason);
      const post = this._receiptPostcondition(k, v.otx, v.rc); if (!post.ok) return this._halt("journal postcondition at step " + k + ": " + post.reason);
    }
    // cumulative checkpoint appropriate to the latest completed step (restart-safe; no _before)
    if (this.journal.length > 0) { const chk = await this._cumulativeCheckpoint(provider, this.journal.length - 1); if (!chk.ok) return this._halt("restart checkpoint: " + chk.reason); }
    this.current = this.journal.length; // authoritative, from validated journal
    this.reconciled = true;
    if (this.pending) {
      const otx = await this._req(provider, "eth_getTransactionByHash", [this.pending.txHash]);
      if (!otx) { this.reconciled = false; return { ok: true, current: this.current, pendingUnresolved: true, note: "pending tx not on chain; sends disabled until it verifies" }; }
      const v = await this.verifyAfterHash(provider, this.pending.txHash); if (!v.ok) return v;
      this.reconciled = true; return { ok: true, current: this.current, pendingResolved: true };
    }
    return { ok: true, current: this.current };
  }

  // resolve a durable uncertain-send ONLY with a supplied/discovered tx hash that reconciles exactly
  async resolveUncertainSend(provider, txHash) {
    if (!this.uncertainSend) return { ok: false, reason: "no uncertain send" };
    const t = this.steps[this.uncertainSend.step];
    const v = await this._verifyTxAndReceipt(provider, t, txHash); if (!v.ok) return { ok: false, reason: "supplied tx does not reconcile: " + v.reason };
    const post = this._receiptPostcondition(this.uncertainSend.step, v.otx, v.rc); if (!post.ok) return { ok: false, reason: "postcondition: " + post.reason };
    // clear durable halt + uncertain, journal the step
    this.journal[this.uncertainSend.step] = { digest: this.execDigest, step: this.uncertainSend.step, txHash, receiptStatus: "success", verified: true };
    this.storage.set(this._kJournal, JSON.stringify(this.journal));
    this.uncertainSend = null; this.halted = false; this.haltReason = null; this.storage.set(this._kHalt, "null");
    this.current = this.journal.length; return { ok: true, resolvedStep: this.journal.length - 1 };
  }

  // ---- ABI helpers ----
  _selector(sig) { return this.keccak256(this._utf8ToHex(sig)).slice(0, 10); }
  _encAddr(a) { return this.getAddress(a).toLowerCase().replace(/^0x/, "").padStart(64, "0"); }
  _encUint(n) { return BigInt(n).toString(16).padStart(64, "0"); }
  async _call(provider, to, sig, argsHex = []) { return this._req(provider, "eth_call", [{ to, data: this._selector(sig) + argsHex.join("") }, "latest"]); }
  async _callAddr(provider, to, sig, argsHex = []) { return "0x" + (await this._call(provider, to, sig, argsHex)).slice(-40); }
  async _callUint(provider, to, sig, argsHex = []) { const r = await this._call(provider, to, sig, argsHex); return BigInt(r.length >= 66 ? r.slice(0, 66) : r).toString(); }
  async _callBool(provider, to, sig, argsHex = []) { return BigInt(await this._call(provider, to, sig, argsHex)).toString() === "1"; }
  async _callString(provider, to, sig) { const r = await this._call(provider, to, sig); const len = Number(BigInt("0x" + r.slice(66, 130))); const hex = r.slice(130, 130 + len * 2); let s = ""; for (let i = 0; i < hex.length; i += 2) s += String.fromCharCode(parseInt(hex.substr(i, 2), 16)); return s; }
  _decodeEvent(logs, emitter, sig, indexed) {
    const t0 = this.keccak256(this._utf8ToHex(sig)).toLowerCase(), em = this.getAddress(emitter);
    for (const lg of logs) { if (this.getAddress(lg.address) !== em || lg.topics[0].toLowerCase() !== t0) continue; const d = []; let di = 0; const data = lg.data.slice(2); for (const isIdx of indexed) { if (!isIdx) { d.push(BigInt("0x" + data.slice(di * 64, (di + 1) * 64))); di++; } } return { topics: lg.topics, d }; }
    return null;
  }
}
function memStore() { const m = new Map(); return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => m.set(k, v) }; }
