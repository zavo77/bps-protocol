// TASK 10D-1 — browser wiring for the canary EXECUTION operator (hardened).
// Signing happens ONLY inside Rabby via per-transaction eth_sendTransaction after an explicit click.
// This file never touches a key/seed/keystore/raw signature and never calls eth_sendRawTransaction.
import { CanaryOperator } from "./operator-core.mjs";
import { keccak256, getAddress } from "./vendor/eth.js";

const $ = (id) => document.getElementById(id);
const say = (m, cls) => { const el = $("log"); const d = document.createElement("div"); if (cls) d.className = cls; d.textContent = m; el.prepend(d); };
let op = null, provider = null;

const loadJson = async (p) => { const r = await fetch(p); if (!r.ok) throw new Error("load " + p); return r.json(); };
// browser localStorage wrapper for journal/pending persistence
const storage = { get: (k) => localStorage.getItem(k), set: (k, v) => localStorage.setItem(k, v) };

// decimal string -> micro-USD (string/BigInt only)
const toMicro = (dec) => { const [i, f = ""] = String(dec).split("."); return BigInt(i) * 1_000_000n + BigInt((f + "000000").slice(0, 6)); };
// fresh live price provider (Coinbase + Kraken); CORS-enabled public endpoints
async function priceProvider() {
  const t0 = Date.now();
  const [cb, kr] = await Promise.all([
    fetch("https://api.coinbase.com/v2/prices/ETH-USD/spot").then(r => r.json()),
    fetch("https://api.kraken.com/0/public/Ticker?pair=ETHUSD").then(r => r.json()),
  ]);
  const now = Date.now();
  const coinbaseMicroUsd = toMicro(cb.data.amount);
  const krakenMicroUsd = toMicro(Object.values(kr.result)[0].c[0]);
  const age = (now - t0) / 1000; // observation age (fetch just completed)
  return { coinbaseMicroUsd, krakenMicroUsd, coinbaseAgeS: age, krakenAgeS: age };
}

function detectRabby() {
  const eth = window.ethereum;
  if (!eth) return { ok: false, reason: "No injected EVM provider. Install/enable Rabby." };
  const list = eth.providers && Array.isArray(eth.providers) ? eth.providers : [eth];
  const rabbys = list.filter(p => p && p.isRabby);
  if (rabbys.length === 0) return { ok: false, reason: "Rabby not detected; this operator requires Rabby." };
  if (rabbys.length > 1) return { ok: false, reason: "Ambiguous: multiple Rabby providers. Aborting (fail closed)." };
  return { ok: true, provider: rabbys[0] };
}

async function init() {
  const [packet, policy, snapshot] = await Promise.all([loadJson("./canary-unsigned-packet.json"), loadJson("./review-policy.json"), loadJson("./block-snapshot.json")]);
  op = new CanaryOperator({ packet, policy, snapshot, provider: null, keccak256, getAddress, priceProvider, storage });
  // (2) bind to the reviewed packet BEFORE enabling connect/send — recompute + verify digest and consistency
  const bind = op.bindAndVerifyPacket();
  $("scope").textContent = packet.meta.authorization.scope;
  $("digest").textContent = packet.meta.executionPacketDigest;
  $("expiry").textContent = packet.meta.expiresAtUtc;
  if (!bind.ok) { say("REFUSED: packet binding failed — " + op.haltReason, "fail"); $("connect").disabled = true; return; }
  say("Packet bound: executionPacketDigest recomputed and verified; chainId/canary/production/scope/wallets/flags/nonces consistent.", "ok");
  const det = detectRabby();
  if (!det.ok) { say("BLOCKED: " + det.reason, "fail"); $("connect").disabled = true; return; }
  provider = det.provider; op.provider = provider;
  say("Rabby detected. " + op.steps.length + " immediate steps (delayed nonce-8 withdrawal DISABLED).");
  render();
}

async function connect() {
  try {
    await provider.request({ method: "eth_requestAccounts" }); // connection only; no signing
    if (BigInt(await provider.request({ method: "eth_chainId" })) !== 4663n) { say("WRONG NETWORK. Switch Rabby to Robinhood Chain 4663 / 0x1237 MANUALLY (no auto add/switch).", "fail"); return; }
    // (4) on restart, validate journal + pending fully against chain before enabling anything
    const r = await op.reconcile(provider);
    if (!r.ok) { say("Reconciliation FAILED — " + op.haltReason, "fail"); render(); return; }
    if (r.pendingUnresolved) say("A pending transaction is not yet on chain; sends stay disabled until it confirms and verifies.", "warn");
    say("Reconciled. Resumed at step " + (op.current + 1) + ".");
    render();
  } catch (e) { say("connect error: " + e.message, "fail"); }
}

function render() {
  const i = op.current, done = i >= op.steps.length;
  $("progress").textContent = `Step ${Math.min(i + 1, op.steps.length)} / ${op.steps.length}` + (done ? " — COMPLETE" : "") + (op.pending ? " — PENDING (sends disabled)" : "");
  if (op.halted) { $("panel").innerHTML = `<div class="fail">HALTED PERMANENTLY: ${op.haltReason}. No automatic retry. Regenerate + re-review to proceed.</div>`; return; }
  if (done) { $("panel").innerHTML = `<div class="ok">All ${op.steps.length} immediate steps executed and verified. The delayed tester-nonce-8 withdrawal is NOT executable here.</div>`; return; }
  if (op.pending) { $("panel").innerHTML = `<div class="warn">Transaction pending (${op.pending.txHash}). Waiting for confirmation + verification. Additional sends are disabled.</div><div class="actions"><button id="resume">Verify pending transaction</button></div>`; $("resume").onclick = () => doVerify(op.pending.txHash); return; }
  const t = op.steps[i], hash = keccak256(t.dataOrInitCode);
  $("panel").innerHTML = `
    <table>
      <tr><th>step</th><td>${i + 1} of ${op.steps.length} (${t.phase} — ${t.label})</td></tr>
      <tr><th>signer</th><td>${getAddress(t.signer)}</td></tr>
      <tr><th>nonce</th><td>${t.nonce}</td></tr>
      <tr><th>target</th><td>${t.to ? getAddress(t.to) : "CREATE → " + t.predictedCreationAddress}</td></tr>
      <tr><th>value</th><td>${t.value} wei</td></tr>
      <tr><th>type / chainId</th><td>0x2 / 4663</td></tr>
      <tr><th>gas limit</th><td>${t.gasLimit}</td></tr>
      <tr><th>max fee / priority</th><td>${t.maxFeePerGas} / ${t.maxPriorityFeePerGas} wei</td></tr>
      <tr><th>method</th><td>${t.label}</td></tr>
      <tr><th>calldata/init-code keccak</th><td class="mono">${hash}</td></tr>
      <tr><th>expected result</th><td>${t.reconciliation || t.phase}</td></tr>
    </table>
    <div class="actions">
      <button id="precheck">1) Run pre-transaction checks (incl. fresh live-price exposure)</button>
      <button id="confirm" disabled>2) Confirm this transaction</button>
      <button id="send" disabled>3) Open Rabby approval for THIS transaction</button>
    </div>`;
  $("precheck").onclick = doPrecheck;
}

let precheckPassed = false;
async function doPrecheck() {
  precheckPassed = false; $("confirm").disabled = true; $("send").disabled = true;
  const r = await op.preconditions(provider);
  if (!r.ok) { say("PRE-CHECK FAILED: " + (r.reason || op.haltReason) + " — HALTED.", "fail"); render(); return; }
  const exp = r.exposure ? ` | exposure $${(Number(r.exposure.exposureMicro) / 1e6).toFixed(6)} @ higher live price` : "";
  say("Pre-checks PASSED: " + Object.keys(r.gates).join(", ") + exp, "ok");
  precheckPassed = true; const c = $("confirm"); c.disabled = false;
  c.onclick = () => { if (precheckPassed) { $("send").disabled = false; say("Confirmed. Click (3) to open the Rabby approval for THIS single transaction."); } };
}

async function doSend() {
  if (!precheckPassed) return; $("send").disabled = true;
  const r = await op.sendCurrent(provider); // single eth_sendTransaction; Rabby prompts
  if (r.userRejected) { say("You rejected the transaction in Rabby. You remain on the same step; no state changed.", "warn"); precheckPassed = false; render(); return; }
  if (!r.ok) { say("SEND blocked/halted: " + (r.reason || op.haltReason), "fail"); render(); return; }
  say("Rabby returned tx hash " + r.txHash + " (pending persisted) — verifying on chain…");
  render(); // shows pending state
  await doVerify(r.txHash);
}

async function doVerify(txHash) {
  const v = await op.verifyAfterHash(provider, txHash);
  if (!v.ok) { say("POST-VERIFY failed: " + (v.reason || op.haltReason) + " — HALTED.", "fail"); render(); return; }
  say("Step " + (v.step + 1) + " verified (fields + receipt + postcondition). Journalled.", "ok");
  precheckPassed = false; render();
}

document.addEventListener("click", (e) => { if (e.target && e.target.id === "send") doSend(); });
$("connect").onclick = connect;
init().catch(e => say("init error: " + e.message, "fail"));
