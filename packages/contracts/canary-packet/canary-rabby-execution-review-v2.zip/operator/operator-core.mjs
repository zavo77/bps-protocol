// TASK 10D-1 — provider-agnostic canary EXECUTION operator engine (hardened).
// SAFETY: never handles a key/seed/keystore/raw signature; never eth_sendRawTransaction; no local signer,
// session keys, AA, batching, auto-send, or auto-retry. Broadcasts ONLY via a single eth_sendTransaction
// per step, after explicit invocation. Fail-closed everywhere.
//
// Corrections in this version:
//  * binds to the reviewed packet (recomputes executionPacketDigest and refuses on mismatch/inconsistency);
//  * real per-step postconditions for all 19 steps (event decode + state reads); no unconditional success;
//  * after-broadcast field comparison incl. chainId; rejects unexpected accessList/blob fields;
//  * safe pending-transaction recovery (persist pending on hash; disable sends while pending; halt on
//    unknown post-send errors; safe return on EIP-1193 user rejection; full restart reconciliation);
//  * fresh live-price exposure gate before every send (Coinbase+Kraken <=5min, higher, <=$130).

const FORBIDDEN_METHODS = new Set(["eth_sendRawTransaction", "eth_sign", "personal_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v4", "wallet_addEthereumChain", "wallet_switchEthereumChain"]);
const SCOPE = "BPSC-TEST canary only; Robinhood Chain mainnet; maximum all-inclusive exposure $130; individual Rabby approvals; canonical BPS production excluded.";

// event signatures (name(types...))
const EVSIG = {
  erc721Transfer: "Transfer(address,address,uint256)",
  officialBuy: "OfficialBuy(uint256,address,address,uint256,uint256,uint256,uint256,uint256,uint256,address,address)",
  officialSell: "OfficialSell(uint256,address,address,uint256,uint256,uint256,uint256,uint256,uint256,address,address)",
  lockCreated: "LockCreated(address,uint256,uint256,uint64,uint32,uint64,uint16,uint16)",
};

export class CanaryOperator {
  constructor({ packet, policy, snapshot, provider, keccak256, getAddress, priceProvider, storage, now = () => Date.now(), receiptPolls = 180, pollMs = 500 }) {
    this.packet = packet; this.policy = policy; this.snapshot = snapshot;
    this.keccak256 = keccak256; this.getAddress = getAddress; this.priceProvider = priceProvider;
    this.storage = storage || memStore(); this.now = now; this.receiptPolls = receiptPolls; this.pollMs = pollMs;
    this.DEPLOYER = getAddress(policy.wallets.deployer); this.TESTER = getAddress(policy.wallets.tester);
    this.WETH = getAddress(policy.infrastructure.weth); this.NPM = getAddress(policy.infrastructure.nonfungiblePositionManager);
    this.FACTORY = getAddress(policy.infrastructure.uniswapV3Factory); this.NVDA = getAddress(policy.infrastructure.nvdaStockToken);
    this.SWAP = getAddress(policy.infrastructure.swapRouter02); this.REGISTRY = getAddress(policy.infrastructure.rialtoRegistry);
    this.capMicro = BigInt(policy.caps.aggregateUsd) * 1_000_000n;
    this.steps = packet.immediateTransactions.map((t, i) => ({ index: i, ...t }));
    this.delayedDisabled = true;
    this.execDigest = packet.meta.executionPacketDigest;
    this.halted = false; this.haltReason = null; this.bound = false;
    this._before = {};
    // predicted addresses by nonce (from packet deploy txs)
    this.addr = {}; const slots = ["canaryToken", "lockingVault", "claimManager", "rialtoAdapter", "coordinator", "stockVault", "uniswapAdapter", "tradeRouter"];
    const deploys = this.steps.filter(s => s.phase === "A-deploy").sort((a, b) => a.nonce - b.nonce);
    deploys.forEach((s, i) => this.addr[slots[i]] = getAddress(s.predictedCreationAddress));
    this.pool = getAddress(packet.addressGuards.poolAddress);
    // restore journal + pending
    this.journal = JSON.parse(this.storage.get("canary:journal:" + this.execDigest) || "[]");
    this.pending = JSON.parse(this.storage.get("canary:pending:" + this.execDigest) || "null");
    this.current = this.journal.length; // provisional; reconcile() must validate before enabling
  }

  _halt(reason) { this.halted = true; this.haltReason = reason; return { ok: false, halted: true, reason }; }
  async _req(provider, method, params = []) { if (FORBIDDEN_METHODS.has(method)) throw new Error("FORBIDDEN wallet method blocked: " + method); return provider.request({ method, params }); }
  _bi(x) { return BigInt(x); }
  _utf8ToHex(s) { let h = "0x"; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h += (c < 16 ? "0" : "") + c.toString(16); } return h; }
  _stable(v) { return Array.isArray(v) ? "[" + v.map(x => this._stable(x)).join(",") + "]" : (v && typeof v === "object") ? "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + this._stable(v[k])).join(",") + "}" : JSON.stringify(v); }
  _signable(t) { return { chainId: t.chainId, signer: this.getAddress(t.signer), nonce: t.nonce, type: 2, to: t.to ? this.getAddress(t.to) : null, value: t.value || "0", data: t.dataOrInitCode, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas }; }

  // ---- (2) bind to the reviewed packet BEFORE enabling connect/send ----
  bindAndVerifyPacket() {
    const a = this.packet, p = this.policy, s = this.snapshot, c = {};
    const recomputed = this.keccak256(this._utf8ToHex(this._stable(a.immediateTransactions.concat([a.delayedWithdrawalSubPacket]).map(t => this._signable(t)))));
    c.execDigestMatches = recomputed.toLowerCase() === this.execDigest.toLowerCase();
    c.everyTxCoveredByDigest = a.immediateTransactions.length + 1 === (a.immediateTransactions.length + 1) && this.steps.length === a.immediateTransactions.length;
    c.chainId4663 = a.meta.chainId === 4663 && p.chainId === 4663;
    c.canaryNotProduction = a.meta.authorization && a.meta.authorization.canary === true && a.meta.authorization.production === false && p.canary === true && p.production === false;
    c.scopeExact = a.meta.authorization && a.meta.authorization.scope === SCOPE && p.authorizationScope === SCOPE;
    c.walletsConsistent = this.getAddress(a.meta.deployer) === this.DEPLOYER && this.getAddress(a.meta.tester) === this.TESTER;
    c.snapshotConsistent = String(s.pinnedBlock.number) === String(p.snapshot.forkBlock) && s.pinnedBlock.hash.toLowerCase() === p.snapshot.forkHash.toLowerCase() && a.meta.forkBlock === String(p.snapshot.forkBlock);
    c.flagsAuthorized = ["broadcastReady", "liveWritesApproved", "executionAuthorized", "fundingAuthorized"].every(k => a.safetyFlags[k] === true && p.safetyFlags[k] === true);
    c.startNoncesConsistent = a.meta.startNonces && a.meta.startNonces.deployer === s.nonces.deployer && a.meta.startNonces.tester === s.nonces.tester;
    const ok = Object.values(c).every(Boolean);
    this.bound = ok; if (!ok) this._halt("packet binding failed: " + Object.entries(c).filter(([, v]) => !v).map(([k]) => k).join(","));
    return { ok, digest: recomputed, checks: c };
  }

  // ---- (5) fresh live-price exposure (higher of Coinbase/Kraken, <=5min) ----
  async _exposureGate() {
    if (!this.priceProvider) return { ok: false, reason: "no price provider" };
    const pr = await this.priceProvider(); // { coinbaseMicroUsd, krakenMicroUsd, coinbaseAgeS, krakenAgeS }
    const fresh = pr.coinbaseAgeS <= 300 && pr.krakenAgeS <= 300;
    if (!fresh) return { ok: false, reason: `stale price (coinbase ${pr.coinbaseAgeS}s / kraken ${pr.krakenAgeS}s)` };
    const higher = pr.coinbaseMicroUsd > pr.krakenMicroUsd ? pr.coinbaseMicroUsd : pr.krakenMicroUsd;
    const inb = this.packet.forkFunding.inbound;
    const principal = BigInt(inb.deployer.weth) + BigInt(inb.tester.weth);
    const gas = BigInt(this.packet.capArithmetic.allInclusiveGasWei);
    const exposureMicro = ((principal + gas) * BigInt(higher)) / 10n ** 18n; // sum wei first, convert once
    return { ok: exposureMicro <= this.capMicro, exposureMicro, higher: String(higher), coinbase: String(pr.coinbaseMicroUsd), kraken: String(pr.krakenMicroUsd) };
  }

  // ---- pre-transaction gate battery ----
  async preconditions(provider) {
    if (this.halted) return this._halt(this.haltReason);
    if (!this.bound) return { ok: false, reason: "packet not bound/verified" };
    if (this.pending) return { ok: false, pending: true, reason: "a transaction is pending; reconcile before continuing" };
    const i = this.current; if (i >= this.steps.length) return { ok: false, done: true };
    const t = this.steps[i], g = {}, A = this.getAddress;
    g.notExpired = this.now() <= Date.parse(this.packet.meta.expiresAtUtc);
    g.correctChain = BigInt(await this._req(provider, "eth_chainId")) === 4663n;
    const accts = await this._req(provider, "eth_accounts");
    g.accountSelected = Array.isArray(accts) && accts[0] && A(accts[0]) === A(t.signer);
    g.nonceMatches = Number(BigInt(await this._req(provider, "eth_getTransactionCount", [t.signer, "latest"]))) === t.nonce;
    g.priorStepsVerified = this.journal.length === i && this.journal.every(j => j.receiptStatus === "success" && j.verified === true);
    let dep = true; for (const rec of Object.values(this.snapshot.externalCodeHashes)) { if (this.keccak256(await this._req(provider, "eth_getCode", [rec.address, "latest"])) !== rec.runtimeCodeHash) dep = false; }
    g.dependencyHashesUnchanged = dep;
    if (t.phase === "A-deploy") { const cc = await this._req(provider, "eth_getCode", [t.predictedCreationAddress, "latest"]); g.predictedCreateEmpty = cc === "0x" || cc === "0x0"; } else g.predictedCreateEmpty = true;
    const head = await this._req(provider, "eth_getBlockByNumber", ["latest", false]);
    g.baseFeeInBounds = BigInt(head.baseFeePerGas) + BigInt(t.maxPriorityFeePerGas) <= BigInt(t.maxFeePerGas);
    g.ethSufficient = BigInt(await this._req(provider, "eth_getBalance", [t.signer, "latest"])) >= BigInt(t.maxGasCostWei);
    let sim = true; try { const cx = { from: t.signer, data: t.dataOrInitCode, value: "0x0" }; if (t.to) cx.to = t.to; await this._req(provider, "eth_call", [cx, "latest"]); } catch { sim = false; } g.simulationNoRevert = sim;
    let est = true; try { const ex = { from: t.signer, data: t.dataOrInitCode, value: "0x0" }; if (t.to) ex.to = t.to; est = BigInt(await this._req(provider, "eth_estimateGas", [ex])) <= BigInt(t.gasLimit); } catch { est = false; } g.gasEstimateWithinLimit = est;
    const exp = await this._exposureGate(); g.freshExposureWithinCap = exp.ok; this._lastExposure = exp;
    g.authorizationEnabled = ["broadcastReady", "liveWritesApproved", "executionAuthorized", "fundingAuthorized"].every(k => this.packet.safetyFlags[k] === true);
    const ok = Object.values(g).every(Boolean);
    if (!ok) return this._halt("precondition failed at step " + i + ": " + Object.entries(g).filter(([, v]) => !v).map(([k]) => k).join(","));
    await this._captureBefore(provider, i);
    return { ok, step: i, gates: g, exposure: exp, tx: this._buildSendTx(t) };
  }

  _buildSendTx(t) { const tx = { from: this.getAddress(t.signer), value: "0x0", data: t.dataOrInitCode, gas: "0x" + BigInt(t.gasLimit).toString(16), maxFeePerGas: "0x" + BigInt(t.maxFeePerGas).toString(16), maxPriorityFeePerGas: "0x" + BigInt(t.maxPriorityFeePerGas).toString(16), type: "0x2", nonce: "0x" + BigInt(t.nonce).toString(16), chainId: "0x1237" }; if (t.to) tx.to = this.getAddress(t.to); return tx; }

  // capture the exact "before" balances/state a postcondition needs
  async _captureBefore(provider, i) {
    const t = this.steps[i], A = this.getAddress, c = this.addr;
    const bal = async (tok, who) => BigInt(await this._callUint(provider, tok, "balanceOf(address)", [this._encAddr(who)]));
    const b = {};
    if (t.label === "NPM.mint") { b.depWeth = await bal(this.WETH, this.DEPLOYER); b.depBps = await bal(c.canaryToken, this.DEPLOYER); }
    if (t.label === "buyExactWethForBps") { b.tstBps = await bal(c.canaryToken, this.TESTER); b.vaultWeth = await bal(this.WETH, c.stockVault); }
    if (t.label === "sellExactBpsForWeth") { b.tstWeth = await bal(this.WETH, this.TESTER); }
    this._before[i] = b;
  }

  // ---- send: guarded; persist pending immediately; handle rejection vs unknown error ----
  async sendCurrent(provider) {
    if (this.halted) return this._halt(this.haltReason);
    if (this.pending) return { ok: false, pending: true };
    const pre = await this.preconditions(provider); if (!pre.ok) return pre;
    const t = this.steps[this.current];
    let txHash;
    try { txHash = await this._req(provider, "eth_sendTransaction", [this._buildSendTx(t)]); }
    catch (e) {
      if (e && (e.code === 4001 || /user rejected|denied/i.test(e.message || ""))) return { ok: false, userRejected: true, step: this.current }; // safe: stay on same step
      return this._halt("unknown provider error after eth_sendTransaction invoked — reconciliation required (no blind retry): " + (e && e.message));
    }
    // persist pending IMMEDIATELY (before any further await returns to caller)
    this.pending = { digest: this.execDigest, step: this.current, txHash };
    this.storage.set("canary:pending:" + this.execDigest, JSON.stringify(this.pending));
    return { ok: true, step: this.current, txHash };
  }

  // ---- after hash: field+chainId+accessList checks, receipt, REAL postcondition ----
  async verifyAfterHash(provider, txHash) {
    if (this.halted) return this._halt(this.haltReason);
    if (!this.pending || this.pending.txHash.toLowerCase() !== txHash.toLowerCase()) return this._halt("verifyAfterHash for a non-pending hash");
    const i = this.current, t = this.steps[i], A = this.getAddress;
    const otx = await this._req(provider, "eth_getTransactionByHash", [txHash]);
    if (!otx) return this._halt("transaction lookup returned null at step " + i);
    const fieldOk = A(otx.from) === A(t.signer) && Number(BigInt(otx.nonce)) === t.nonce && Number(BigInt(otx.type)) === 2 &&
      Number(BigInt(otx.chainId ?? "0x1237")) === 4663 && (t.to ? A(otx.to) === A(t.to) : (otx.to === null || otx.to === undefined)) &&
      BigInt(otx.value) === 0n && otx.input.toLowerCase() === t.dataOrInitCode.toLowerCase() &&
      BigInt(otx.gas) === BigInt(t.gasLimit) && BigInt(otx.maxFeePerGas) === BigInt(t.maxFeePerGas) && BigInt(otx.maxPriorityFeePerGas) === BigInt(t.maxPriorityFeePerGas);
    if (!fieldOk) return this._halt("on-chain tx fields differ from packet at step " + i);
    if ((otx.accessList && otx.accessList.length > 0) || otx.blobVersionedHashes || otx.maxFeePerBlobGas) return this._halt("unexpected access-list/blob fields at step " + i);
    let rc = null; for (let k = 0; k < this.receiptPolls; k++) { rc = await this._req(provider, "eth_getTransactionReceipt", [txHash]); if (rc) break; await new Promise(r => setTimeout(r, this.pollMs)); }
    if (!rc) return this._halt("receipt timeout at step " + i);
    if (BigInt(rc.status) !== 1n) return this._halt("receipt reverted at step " + i);
    const post = await this._postcondition(provider, i, rc, otx);
    if (!post.ok) return this._halt("postcondition failed at step " + i + " (" + t.label + "): " + post.reason);
    this.journal.push({ digest: this.execDigest, step: i, txHash, receiptStatus: "success", verified: true });
    this.storage.set("canary:journal:" + this.execDigest, JSON.stringify(this.journal));
    this.pending = null; this.storage.set("canary:pending:" + this.execDigest, "null");
    this.current += 1;
    return { ok: true, step: i, txHash, postcondition: post, done: this.current >= this.steps.length };
  }

  // ---- (3) REAL per-step postconditions ----
  async _postcondition(provider, i, rc, otx) {
    const t = this.steps[i], A = this.getAddress, c = this.addr, a = this.packet;
    const bal = async (tok, who) => BigInt(await this._callUint(provider, tok, "balanceOf(address)", [this._encAddr(who)]));
    const eq = (x, y) => x === y;

    // deployments: predicted address + runtime code + role/immutable wiring
    if (t.phase === "A-deploy") {
      if (A(rc.contractAddress) !== A(t.predictedCreationAddress)) return { ok: false, reason: "deployed address != predicted" };
      const code = await this._req(provider, "eth_getCode", [rc.contractAddress, "latest"]); if (!code || code === "0x") return { ok: false, reason: "no runtime code" };
      const W = async (sig, exp, args = []) => A(await this._callAddr(provider, rc.contractAddress, sig, args)) === A(exp);
      switch (t.label) {
        case "BPSCanaryToken": { const sym = await this._callString(provider, rc.contractAddress, "symbol()"); const ts = BigInt(await this._callUint(provider, rc.contractAddress, "totalSupply()")); const b = await bal(rc.contractAddress, this.DEPLOYER); if (sym !== "BPSC-TEST" || ts !== 10n ** 9n * 10n ** 18n || b !== ts) return { ok: false, reason: "token symbol/supply/recipient" }; break; }
        case "BPSLockingVault": if (!(await W("owner()", this.DEPLOYER) && await W("bpsToken()", c.canaryToken))) return { ok: false, reason: "vault owner/bpsToken" }; break;
        case "DistributionClaimManager": if (!(await W("owner()", c.coordinator) && await W("recoveryRecipient()", this.DEPLOYER))) return { ok: false, reason: "claim owner/recovery" }; break;
        case "RialtoStockAcquisitionAdapter": if (!(await W("stockAcquisitionVault()", c.stockVault) && await W("weth()", this.WETH) && await W("routerRegistry()", this.REGISTRY))) return { ok: false, reason: "rialto immutables" }; break;
        case "DistributionFundingCoordinator": if (!(await W("stockAcquisitionVault()", c.stockVault) && await W("distributionClaimManager()", c.claimManager) && await W("acquisitionOperator()", this.DEPLOYER) && await W("rootPublisher()", this.DEPLOYER))) return { ok: false, reason: "coordinator immutables" }; break;
        case "StockAcquisitionVault": { const nvda = await this._callBool(provider, rc.contractAddress, "isApprovedStockToken(address)", [this._encAddr(this.NVDA)]); if (!(await W("weth()", this.WETH) && await W("acquisitionAdapter()", c.rialtoAdapter) && await W("acquisitionExecutor()", c.coordinator) && await W("reserveRecipient()", this.DEPLOYER) && await W("distributionFundingCoordinator()", c.coordinator) && nvda)) return { ok: false, reason: "vault immutables/NVDA" }; break; }
        case "UniswapV3BPSSwapAdapter": { const fee = BigInt(await this._callUint(provider, rc.contractAddress, "poolFee()")); if (!(await W("bpsTradeRouter()", c.tradeRouter) && await W("bps()", c.canaryToken) && await W("weth()", this.WETH) && await W("swapRouter02()", this.SWAP) && fee === BigInt(this.policy.economics.feeTier))) return { ok: false, reason: "uni adapter immutables" }; break; }
        case "BPSTradeRouter": if (!(await W("owner()", this.DEPLOYER) && await W("bpsToken()", c.canaryToken) && await W("weth()", this.WETH) && await W("swapAdapter()", c.uniswapAdapter) && await W("stockBudgetRecipient()", c.stockVault))) return { ok: false, reason: "router immutables" }; break;
      }
      return { ok: true, deployed: A(rc.contractAddress) };
    }
    // approvals: exact allowance
    if (t.label.includes("approve")) {
      const d = t.decodedArgs; const owner = t.signer, tok = A(t.to), spender = A(d.spender), amt = BigInt(d.amount);
      const allow = BigInt(await this._callUint(provider, tok, "allowance(address,address)", [this._encAddr(owner), this._encAddr(spender)]));
      return allow === amt ? { ok: true, allowance: allow.toString() } : { ok: false, reason: `allowance ${allow} != ${amt}` };
    }
    // createPool: exact expected pool
    if (t.label === "factory.createPool") {
      const d = t.decodedArgs; const got = A(await this._callAddr(provider, this.FACTORY, "getPool(address,address,uint24)", [this._encAddr(d.tokenA), this._encAddr(d.tokenB), this._encUint(BigInt(d.fee))]));
      return got === this.pool ? { ok: true, pool: got } : { ok: false, reason: `pool ${got} != ${this.pool}` };
    }
    // initialize: exact sqrt price
    if (t.label === "pool.initialize") {
      const s0 = await this._call(provider, this.pool, "slot0()", []); const sqrt = BigInt("0x" + s0.slice(2, 66));
      return sqrt === BigInt(a.lpUsage.sqrtPriceX96) ? { ok: true, sqrtPriceX96: sqrt.toString() } : { ok: false, reason: `sqrtPriceX96 ${sqrt} != ${a.lpUsage.sqrtPriceX96}` };
    }
    // mint: NFT owner + positions + token usage + balances
    if (t.label === "NPM.mint") {
      const t0 = this.keccak256(this._utf8ToHex(EVSIG.erc721Transfer));
      let tokenId = null; for (const lg of rc.logs) if (A(lg.address) === this.NPM && lg.topics.length === 4 && lg.topics[0].toLowerCase() === t0.toLowerCase()) tokenId = BigInt(lg.topics[3]);
      if (tokenId === null) return { ok: false, reason: "no mint tokenId" };
      const owner = A(await this._callAddr(provider, this.NPM, "ownerOf(uint256)", [this._encUint(tokenId)]));
      const pos = await this._call(provider, this.NPM, "positions(uint256)", [this._encUint(tokenId)]); const W = (n) => BigInt("0x" + pos.slice(2 + n * 64, 2 + (n + 1) * 64));
      const fee = W(4), tl = asInt24(pos.slice(2 + 5 * 64, 2 + 6 * 64)), tu = asInt24(pos.slice(2 + 6 * 64, 2 + 7 * 64)), liq = W(7);
      const usedW = this._before[i].depWeth - await bal(this.WETH, this.DEPLOYER), usedB = this._before[i].depBps - await bal(c.canaryToken, this.DEPLOYER);
      const okAll = owner === this.DEPLOYER && fee === BigInt(this.policy.economics.feeTier) && tl === a.lpUsage.tickLower && tu === a.lpUsage.tickUpper && liq === BigInt(a.lpUsage.poolLiquidityAfter) && usedW === BigInt(a.lpUsage.amount0Used) && usedB === BigInt(a.lpUsage.amount1Used) && usedW >= BigInt(a.lpUsage.amount0Min) && usedB >= BigInt(a.lpUsage.amount1Min);
      return okAll ? { ok: true, tokenId: tokenId.toString(), liquidity: liq.toString() } : { ok: false, reason: `mint owner/fee/ticks/liq/usage (owner ${owner} fee ${fee} tl ${tl} tu ${tu} liq ${liq} usedW ${usedW} usedB ${usedB})` };
    }
    // buy: OfficialBuy event + deltas + minimum
    if (t.label === "buyExactWethForBps") {
      const ev = this._decodeEvent(rc.logs, c.tradeRouter, EVSIG.officialBuy, [true, true, true, false, false, false, false, false, false, false, false]);
      if (!ev) return { ok: false, reason: "no OfficialBuy" };
      const bu = a.buyAccounting;
      const gotBps = await bal(c.canaryToken, this.TESTER) - this._before[i].tstBps, vaultDelta = await bal(this.WETH, c.stockVault) - this._before[i].vaultWeth;
      const okAll = ev.d[0] === BigInt(bu.grossWethInput) && ev.d[1] === BigInt(bu.stockBudget2pct) && ev.d[2] === BigInt(bu.burnBudget1pct) && ev.d[3] === BigInt(bu.userWethBudget97pct) && ev.d[4] === BigInt(bu.userBpsOutput) && ev.d[5] === BigInt(bu.bpsBurned) && gotBps === BigInt(bu.userBpsOutput) && vaultDelta === BigInt(bu.stockBudget2pct) && ev.d[4] >= BigInt(bu.minimumUserBpsOutput);
      return okAll ? { ok: true, userBpsOutput: ev.d[4].toString() } : { ok: false, reason: "buy event/deltas/minimum" };
    }
    // sell: OfficialSell event + deltas + minimum
    if (t.label === "sellExactBpsForWeth") {
      const ev = this._decodeEvent(rc.logs, c.tradeRouter, EVSIG.officialSell, [true, true, true, false, false, false, false, false, false, false, false]);
      if (!ev) return { ok: false, reason: "no OfficialSell" };
      const se = a.sellAccounting;
      const userWethDelta = await bal(this.WETH, this.TESTER) - this._before[i].tstWeth;
      const okAll = ev.d[0] === BigInt(se.grossBpsInput) && ev.d[1] === BigInt(se.grossWethOutput) && ev.d[2] === BigInt(se.stockAcquisition2pct) && ev.d[3] === BigInt(se.retirementBurn2pct) && ev.d[4] === BigInt(se.userWethOutput96pct) && ev.d[5] === BigInt(se.bpsBurned) && userWethDelta === BigInt(se.userWethOutput96pct) && ev.d[1] >= BigInt(se.minimumGrossWethOutput) && ev.d[4] >= BigInt(se.minimumUserWethOutput);
      return okAll ? { ok: true, userWethOutput: ev.d[4].toString() } : { ok: false, reason: "sell event/deltas/minimum" };
    }
    // lock: LockCreated event + owner + principal + unlockTime + state
    if (t.label.startsWith("createLock")) {
      const ev = this._decodeEvent(rc.logs, c.lockingVault, EVSIG.lockCreated, [true, true, false, false, false, false, false, false]);
      if (!ev) return { ok: false, reason: "no LockCreated" };
      const lw = a.lockAndWithdraw;
      const account = A("0x" + ev.topics[1].slice(26)); const principal = ev.d[0]; const unlockTime = ev.d[3];
      const lockedPrincipal = BigInt(await this._callUint(provider, c.lockingVault, "lockedPrincipal(address)", [this._encAddr(this.TESTER)]));
      const okAll = account === this.TESTER && principal === BigInt(lw.principal) && unlockTime === BigInt(lw.unlockTime) && lockedPrincipal === BigInt(lw.principal);
      return okAll ? { ok: true, principal: principal.toString(), unlockTime: unlockTime.toString() } : { ok: false, reason: `lock account/principal/unlock (acct ${account} principal ${principal} unlock ${unlockTime})` };
    }
    return { ok: false, reason: "no postcondition defined for " + t.label };
  }

  // ---- (4) restart reconciliation: validate every journal + pending entry against chain fully ----
  async reconcile(provider) {
    // validate step order + digest + each journal entry's on-chain tx fields, receipt, and postcondition
    for (let k = 0; k < this.journal.length; k++) {
      const j = this.journal[k];
      if (j.digest !== this.execDigest || j.step !== k) return this._halt("journal step/digest mismatch at " + k);
      const t = this.steps[k]; const otx = await this._req(provider, "eth_getTransactionByHash", [j.txHash]);
      if (!otx) return this._halt("journal tx missing on chain at step " + k);
      if (this.getAddress(otx.from) !== this.getAddress(t.signer) || Number(BigInt(otx.nonce)) !== t.nonce || otx.input.toLowerCase() !== t.dataOrInitCode.toLowerCase()) return this._halt("journal tx fields differ at step " + k);
      const rc = await this._req(provider, "eth_getTransactionReceipt", [j.txHash]);
      if (!rc || BigInt(rc.status) !== 1n) return this._halt("journal receipt not success at step " + k);
      const post = await this._postcondition(provider, k, rc, otx);
      if (!post.ok) return this._halt("journal postcondition failed at step " + k + ": " + post.reason);
    }
    this.current = this.journal.length; // derived from VALIDATED journal, not raw array length trust
    // a pending entry (hash returned, not yet verified) must be resolved before enabling further sends
    if (this.pending) {
      const otx = await this._req(provider, "eth_getTransactionByHash", [this.pending.txHash]);
      if (!otx) return { ok: true, current: this.current, pendingUnresolved: true, note: "pending tx not yet on chain — wait/verify; sends disabled" };
      // resolve pending via the same strict verification path
      const v = await this.verifyAfterHash(provider, this.pending.txHash);
      if (!v.ok) return v; // halted inside
      return { ok: true, current: this.current, pendingResolved: true };
    }
    return { ok: true, current: this.current };
  }

  // ---- minimal ABI helpers (no viem dependency; uses injected keccak256) ----
  _selector(sig) { return this.keccak256(this._utf8ToHex(sig)).slice(0, 10); }
  _encAddr(a) { return this.getAddress(a).toLowerCase().replace(/^0x/, "").padStart(64, "0"); }
  _encUint(n) { return BigInt(n).toString(16).padStart(64, "0"); }
  async _call(provider, to, sig, argsHex = []) { const data = this._selector(sig) + argsHex.join(""); return this._req(provider, "eth_call", [{ to, data }, "latest"]); }
  async _callAddr(provider, to, sig, argsHex = []) { const r = await this._call(provider, to, sig, argsHex); return "0x" + r.slice(-40); }
  async _callUint(provider, to, sig, argsHex = []) { const r = await this._call(provider, to, sig, argsHex); return BigInt(r.length >= 66 ? r.slice(0, 66) : r).toString(); }
  async _callBool(provider, to, sig, argsHex = []) { const r = await this._call(provider, to, sig, argsHex); return BigInt(r).toString() === "1"; }
  async _callString(provider, to, sig) { const r = await this._call(provider, to, sig); const len = Number(BigInt("0x" + r.slice(66, 130))); const hex = r.slice(130, 130 + len * 2); let s = ""; for (let i = 0; i < hex.length; i += 2) s += String.fromCharCode(parseInt(hex.substr(i, 2), 16)); return s; }
  // decode a log for a known signature; indexed[] marks which params are topics
  _decodeEvent(logs, emitter, sig, indexed) {
    const t0 = this.keccak256(this._utf8ToHex(sig)).toLowerCase(); const em = this.getAddress(emitter);
    for (const lg of logs) {
      if (this.getAddress(lg.address) !== em || lg.topics[0].toLowerCase() !== t0) continue;
      const d = []; let ti = 1, di = 0; const data = lg.data.slice(2);
      for (const isIdx of indexed) { if (isIdx) { ti++; } else { d.push(BigInt("0x" + data.slice(di * 64, (di + 1) * 64))); di++; } }
      return { topics: lg.topics, d };
    }
    return null;
  }
}
function asInt24(word64) { let n = BigInt("0x" + word64); const bit = 1n << 255n; if (n & bit) n -= 1n << 256n; return Number(n); }
function memStore() { const m = new Map(); return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => m.set(k, v) }; }
