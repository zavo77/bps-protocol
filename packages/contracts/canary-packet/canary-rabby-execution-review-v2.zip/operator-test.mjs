// TASK 10D-1 — operator engine tests: SUCCESS path on a clean fork with a mock provider (real
// per-step postconditions), PLUS fault-injection / recovery / adversarial tests. Never Rabby, never mainnet.
import { readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { createPublicClient, http, keccak256, getAddress, encodeAbiParameters, toHex } from "viem";
import { CanaryOperator } from "./operator/operator-core.mjs";

const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const packet = rj("canary-unsigned-packet.json"), policy = rj("review-policy.json"), snapshot = rj("block-snapshot.json");
const PORT = Number(process.env.OPTEST_PORT || 8548);
const FORK = `http://127.0.0.1:${PORT}`;
const LIVE = process.env[policy.liveRpcEnvVar];
const R = []; const ok = (n, c, d = "") => R.push({ n, pass: !!c, d });
const B = (x) => BigInt(x);
const DEPLOYER = getAddress(policy.wallets.deployer), TESTER = getAddress(policy.wallets.tester), WETH = getAddress(policy.infrastructure.weth);

// fresh-price provider mock (both observations fresh, at the packet cap price)
const capMicro = BigInt(packet.capArithmetic.capPriceMicroUsd);
const freshPrices = async () => ({ coinbaseMicroUsd: capMicro, krakenMicroUsd: capMicro - 100000n, coinbaseAgeS: 3, krakenAgeS: 4 });
const memStore = () => { const m = new Map(); return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => m.set(k, v), _m: m }; };

let anvil;
const forkPub = createPublicClient({ transport: http(FORK) });
const forkReq = (m, p = []) => forkPub.request({ method: m, params: p });
async function waitAnvil() { for (let i = 0; i < 60; i++) { try { if (await forkReq("eth_blockNumber")) return; } catch { } await new Promise(r => setTimeout(r, 500)); } throw new Error("anvil did not start"); }

// mock injected provider over the fork; overrides account selection; records calls; blocks forbidden
const FORBIDDEN = ["eth_sendRawTransaction", "eth_sign", "personal_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v4", "wallet_addEthereumChain", "wallet_switchEthereumChain"];

async function main() {
  if (!LIVE) throw new Error("provider RPC env var not set");
  const AL = policy.anvilLaunch;
  anvil = spawn(AL.binary, ["--fork-url", LIVE, "--fork-block-number", String(AL.forkBlockNumber), "--chain-id", "4663", "--block-base-fee-per-gas", String(AL.blockBaseFeePerGas), "--port", String(PORT), "--silent"], { stdio: "ignore" });
  await waitAnvil();
  await forkReq("anvil_setBlockTimestampInterval", [1]);
  // provision: generous ETH seed + EXACT WETH via discovered slot
  await forkReq("anvil_setBalance", [DEPLOYER, toHex(10n ** 18n)]); await forkReq("anvil_setBalance", [TESTER, toHex(10n ** 18n)]);
  await forkReq("anvil_impersonateAccount", [DEPLOYER]); await forkReq("anvil_impersonateAccount", [TESTER]);
  const knownBal = B(snapshot.balances.weth.deployer); let slotIdx = null;
  for (let i = 0; i < 300; i++) { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [DEPLOYER, BigInt(i)])); if (B(await forkReq("eth_getStorageAt", [WETH, slot, "latest"])) === knownBal) { slotIdx = BigInt(i); break; } }
  const setW = async (who, amt) => { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [who, slotIdx])); await forkReq("anvil_setStorageAt", [WETH, slot, toHex(amt, { size: 32 })]); };
  await setW(DEPLOYER, B(packet.forkFunding.inbound.deployer.weth)); await setW(TESTER, B(packet.forkFunding.inbound.tester.weth));
  let snapId = await forkReq("evm_snapshot", []); // clean provisioned state
  const resetFork = async () => { await forkReq("evm_revert", [snapId]); snapId = await forkReq("evm_snapshot", []); };

  const calls = []; let sendCount = 0, forbiddenSeen = 0, selectedAccount = DEPLOYER;
  const mock = { isRabby: false, async request({ method, params = [] }) { calls.push(method); if (FORBIDDEN.includes(method)) { forbiddenSeen++; throw new Error("forbidden: " + method); } if (method === "eth_accounts") return [selectedAccount]; if (method === "eth_sendTransaction") { sendCount++; if (Array.isArray(params[0])) throw new Error("batch"); return forkReq("eth_sendTransaction", [params[0]]); } return forkReq(method, params); } };

  // ===== A) SUCCESS PATH with real postconditions =====
  const op = new CanaryOperator({ packet, policy, snapshot, provider: mock, keccak256, getAddress, priceProvider: freshPrices, storage: memStore() });
  const bind = op.bindAndVerifyPacket();
  ok("bind: executionPacketDigest recomputed and matches", bind.checks.execDigestMatches && bind.digest.toLowerCase() === packet.meta.executionPacketDigest.toLowerCase());
  ok("bind: packet/policy/snapshot consistent (chain/canary/production/scope/wallets/flags/nonces)", bind.ok && bind.checks.chainId4663 && bind.checks.canaryNotProduction && bind.checks.scopeExact && bind.checks.walletsConsistent && bind.checks.flagsAuthorized && bind.checks.snapshotConsistent && bind.checks.startNoncesConsistent);
  ok("delayed tester-nonce-8 withdrawal is NOT an operator step", op.steps.every(s => !(getAddress(s.signer) === TESTER && s.nonce === 8)) && op.delayedDisabled);
  ok("loaded exactly 19 immediate steps", op.steps.length === 19);

  let allOk = true, autoAdvance = false; const posts = [];
  for (let i = 0; i < op.steps.length; i++) {
    selectedAccount = getAddress(op.steps[i].signer);
    const pre = await op.preconditions(mock); if (!pre.ok) { allOk = false; ok(`step ${i} preconditions`, false, pre.reason); break; }
    const before = op.current; const s = await op.sendCurrent(mock); if (!s.ok) { allOk = false; ok(`step ${i} send`, false, s.reason); break; }
    if (op.current !== before) autoAdvance = true;
    ok(`step ${i} pending persisted on hash`, !!op.pending && op.pending.txHash === s.txHash && op.pending.step === i);
    const v = await op.verifyAfterHash(mock, s.txHash); if (!v.ok) { allOk = false; ok(`step ${i} verify (${op.steps[i].label})`, false, v.reason); break; }
    posts.push(v.postcondition); if (op.pending !== null) { allOk = false; ok(`step ${i} pending cleared`, false); break; }
  }
  ok("all 19 steps executed with REAL postconditions verified", allOk && op.current === 19 && !op.halted);
  ok("send never auto-advanced (explicit per-tx)", autoAdvance === false);
  ok("exactly 19 single eth_sendTransaction calls (no batch)", sendCount === 19);
  ok("no forbidden wallet/signing method reached the provider", forbiddenSeen === 0);
  ok("methods restricted to allowed read set + eth_sendTransaction", [...new Set(calls)].every(m => ["eth_chainId", "eth_accounts", "eth_getTransactionCount", "eth_getCode", "eth_getBalance", "eth_getBlockByNumber", "eth_call", "eth_estimateGas", "eth_sendTransaction", "eth_getTransactionByHash", "eth_getTransactionReceipt"].includes(m)), [...new Set(calls)].join(","));
  // postcondition depth spot-checks
  ok("postcondition: mint verified NFT owner + liquidity", posts.some(p => p && p.tokenId && p.liquidity === packet.lpUsage.poolLiquidityAfter));
  ok("postcondition: lock verified principal + unlockTime", posts.some(p => p && p.principal === packet.lockAndWithdraw.principal && p.unlockTime === packet.lockAndWithdraw.unlockTime));

  // ===== B) FAULT-INJECTION / RECOVERY / ADVERSARIAL =====
  // helper: a fresh bound operator whose current is set to a given step, pending set for a hash
  const primed = (curr) => { const o = new CanaryOperator({ packet, policy, snapshot, provider: mock, keccak256, getAddress, priceProvider: freshPrices, storage: memStore(), receiptPolls: 3, pollMs: 5 }); o.bindAndVerifyPacket(); o.current = curr; return o; };
  const t0 = op.steps[0];
  const goodTx = { from: t0.signer, nonce: "0x3", type: "0x2", chainId: "0x1237", to: null, value: "0x0", input: t0.dataOrInitCode, gas: "0x" + B(t0.gasLimit).toString(16), maxFeePerGas: "0x" + B(t0.maxFeePerGas).toString(16), maxPriorityFeePerGas: "0x" + B(t0.maxPriorityFeePerGas).toString(16) };
  const cannedProvider = (h) => ({ request: async ({ method }) => { if (method === "eth_getTransactionByHash") return h.tx; if (method === "eth_getTransactionReceipt") return h.rc; return null; } });

  // B1 null transaction lookup after broadcast -> halt
  { const o = primed(0); o.pending = { digest: o.execDigest, step: 0, txHash: "0xaa" }; const v = await o.verifyAfterHash(cannedProvider({ tx: null, rc: null }), "0xaa"); ok("fault: null tx lookup after broadcast halts", o.halted && /null/.test(v.reason || o.haltReason)); }
  // B2 timeout-after-broadcast (tx exists, receipt never) -> halt
  { const o = primed(0); o.pending = { digest: o.execDigest, step: 0, txHash: "0xbb" }; const v = await o.verifyAfterHash(cannedProvider({ tx: { ...goodTx }, rc: null }), "0xbb"); ok("fault: timeout-after-broadcast (no receipt) halts", o.halted && /timeout/.test(o.haltReason)); }
  // B3 reverted receipt -> halt
  { const o = primed(0); o.pending = { digest: o.execDigest, step: 0, txHash: "0xcc" }; await o.verifyAfterHash(cannedProvider({ tx: { ...goodTx }, rc: { status: "0x0" } }), "0xcc"); ok("fault: reverted receipt halts", o.halted && /reverted/.test(o.haltReason)); }
  // B4 wrong fields (nonce) -> halt
  { const o = primed(0); o.pending = { digest: o.execDigest, step: 0, txHash: "0xdd" }; await o.verifyAfterHash(cannedProvider({ tx: { ...goodTx, nonce: "0x9" }, rc: { status: "0x1" } }), "0xdd"); ok("fault: wrong tx fields (nonce) halts", o.halted && /fields differ/.test(o.haltReason)); }
  // B5 wrong chainId -> halt
  { const o = primed(0); o.pending = { digest: o.execDigest, step: 0, txHash: "0xee" }; await o.verifyAfterHash(cannedProvider({ tx: { ...goodTx, chainId: "0x1" }, rc: { status: "0x1" } }), "0xee"); ok("fault: wrong chainId halts", o.halted && /fields differ/.test(o.haltReason)); }
  // B6 unexpected access-list -> halt
  { const o = primed(0); o.pending = { digest: o.execDigest, step: 0, txHash: "0xff" }; await o.verifyAfterHash(cannedProvider({ tx: { ...goodTx, accessList: [{ address: "0x00", storageKeys: [] }] }, rc: { status: "0x1" } }), "0xff"); ok("fault: unexpected access-list/blob fields halt", o.halted && /access-list|blob/.test(o.haltReason)); }
  // B7 EIP-1193 user rejection BEFORE broadcast -> safe, stay on same step (fork: preconditions pass, send rejects)
  { await resetFork(); const o = new CanaryOperator({ packet, policy, snapshot, provider: mock, keccak256, getAddress, priceProvider: freshPrices, storage: memStore() }); o.bindAndVerifyPacket(); selectedAccount = getAddress(o.steps[0].signer);
    const rejWrap = { request: async ({ method, params }) => { if (method === "eth_sendTransaction") { const e = new Error("user rejected the request"); e.code = 4001; throw e; } return mock.request({ method, params }); } };
    const r = await o.sendCurrent(rejWrap); ok("fault: EIP-1193 user rejection before broadcast returns safely (no halt, same step)", r.userRejected === true && !o.halted && o.current === 0 && o.pending === null); }
  // B8 unknown post-send error -> halt (no blind retry)
  { await resetFork(); const o = new CanaryOperator({ packet, policy, snapshot, provider: mock, keccak256, getAddress, priceProvider: freshPrices, storage: memStore() }); o.bindAndVerifyPacket(); selectedAccount = getAddress(o.steps[0].signer);
    const errWrap = { request: async ({ method, params }) => { if (method === "eth_sendTransaction") throw new Error("network glitch"); return mock.request({ method, params }); } };
    await o.sendCurrent(errWrap); ok("fault: unknown post-send error halts (reconciliation required, no blind retry)", o.halted && /reconciliation required/.test(o.haltReason)); }
  // B9 altered localStorage journal -> reconcile halts (never trusts array length)
  { const st = memStore(); st.set("canary:journal:" + packet.meta.executionPacketDigest, JSON.stringify([{ digest: packet.meta.executionPacketDigest, step: 0, txHash: "0x123", receiptStatus: "success", verified: true }])); const o = new CanaryOperator({ packet, policy, snapshot, provider: mock, keccak256, getAddress, priceProvider: freshPrices, storage: st }); o.bindAndVerifyPacket(); await o.reconcile(cannedProvider({ tx: null, rc: null })); ok("fault: altered localStorage journal fails reconciliation (tx missing on chain)", o.halted && /journal tx missing/.test(o.haltReason)); }
  // B10 stale price -> exposure gate fails -> precondition halts (fork: only the price gate fails)
  { await resetFork(); const o = new CanaryOperator({ packet, policy, snapshot, provider: mock, keccak256, getAddress, priceProvider: async () => ({ coinbaseMicroUsd: capMicro, krakenMicroUsd: capMicro, coinbaseAgeS: 400, krakenAgeS: 10 }), storage: memStore() }); o.bindAndVerifyPacket(); selectedAccount = getAddress(o.steps[0].signer); await o.preconditions(mock); ok("fault: stale (>5min) price halts via exposure gate", o.halted && /freshExposureWithinCap/.test(o.haltReason)); }
  // B11 postcondition failure (wrong allowance via overridden eth_call) -> halt. Fresh fork; run to step 8.
  { await resetFork(); const o = new CanaryOperator({ packet, policy, snapshot, provider: mock, keccak256, getAddress, priceProvider: freshPrices, storage: memStore() }); o.bindAndVerifyPacket();
    for (let i = 0; i < 8; i++) { selectedAccount = getAddress(o.steps[i].signer); await o.preconditions(mock); const s = await o.sendCurrent(mock); await o.verifyAfterHash(mock, s.txHash); }
    selectedAccount = getAddress(o.steps[8].signer); const s = await o.sendCurrent(mock);
    const allowSel = o._selector("allowance(address,address)");
    const tamper = { request: async ({ method, params }) => { if (method === "eth_call" && params[0].data && params[0].data.toLowerCase().startsWith(allowSel.toLowerCase())) return "0x" + "0".repeat(64); return mock.request({ method, params }); } };
    await o.verifyAfterHash(tamper, s.txHash);
    ok("fault: postcondition failure (tampered allowance) halts permanently", o.halted && /postcondition failed/.test(o.haltReason)); }

  console.log("[operator-test] histogram:", Object.entries(calls.reduce((a, m) => (a[m] = (a[m] || 0) + 1, a), {})).map(([k, v]) => `${k}:${v}`).join(" "));
  for (const r of R) console.log(` [${r.pass ? "PASS" : "FAIL"}] ${r.n}${r.d ? "  (" + r.d + ")" : ""}`);
  const passed = R.filter(r => r.pass).length;
  console.log(`\n[operator-test] ${passed}/${R.length} checks passed`);
  return R.every(r => r.pass);
}

let code = 1;
try { code = (await main()) ? 0 : 1; } catch (e) { console.error("[operator-test] ERROR:", e.message, e.stack?.split("\n")[1] || ""); code = 1; }
finally { if (anvil) try { anvil.kill("SIGKILL"); } catch { } }
process.exit(code);
