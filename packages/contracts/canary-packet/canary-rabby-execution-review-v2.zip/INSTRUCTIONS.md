# Canary Rabby Execution Operator — BPSC-TEST (Task 10D)

**BPSC-TEST — CANARY — NOT PRODUCTION.** Robinhood Chain mainnet, chainId **4663 (0x1237)**.
Authorization scope: *BPSC-TEST canary only; Robinhood Chain mainnet; maximum all-inclusive exposure $130;
individual Rabby approvals; canonical BPS production excluded.*

This bundle contains an **execution-enabled** unsigned packet and a **localhost-only** operator that lets you
approve each transaction, one at a time, in your **Rabby** extension. The operator **never** sees a key, seed,
or keystore, **never** builds a signer, and **never** broadcasts on its own — it hands one `eth_sendTransaction`
to Rabby only after you click, and Rabby does the signing.

## Requirements
- Node.js ≥ 20; `anvil` (Foundry) for the verification/replay steps.
- `node_modules` is **excluded** from this ZIP. Reinstall the pinned dependencies (`dependency-lock.json`,
  `package.json`) before running any `.mjs` script: `npm install`.
- Provider RPC supplied **only** via the environment variable (never printed/stored):
  `export ROBINHOOD_CHAIN_RPC_URL="<your provider HTTPS endpoint>"`
- A browser with the **Rabby** extension installed and your deployer/tester accounts imported (by you, in Rabby).

## Recommended order

1. **Re-verify the bundle** (compile, offline, mutation, clean-fork replay, operator fork-test, static scan):
   ```bash
   npm install
   node run-verification.mjs        # compile 7/7, offline 55/55, replay 19/19
   node operator-test.mjs           # 9/9 — engine drives all 19 txs on a fork via a mock provider
   node static-scan.mjs             # 5/5 — no key/raw-broadcast/batch/auto-send; no credential
   ```
2. **Immediately before execution, run the 8-gate mainnet preflight** (read-only):
   ```bash
   node preflight-check.mjs
   ```
   If any gate fails — expiry, nonce drift off deployer 3 / tester 2, insufficient balances, changed
   dependency code, an occupied predicted address, base fee out of bounds, exposure > $130 — **STOP** and
   regenerate. Do not execute a stale packet.
3. **Start the localhost operator** (bound to 127.0.0.1 only) and open it in the Rabby browser:
   ```bash
   node operator/serve.mjs          # http://127.0.0.1:8737/
   ```
4. In the page: **Connect Rabby** (approves a connection only — no signing). Ensure Rabby is on
   **Robinhood Chain 4663 / 0x1237** and the **exact packet signer** is selected — the operator will not add or
   switch networks for you; switch manually and fail closed if wrong.
5. For **each** transaction, in packet order:
   - Click **(1) Run pre-transaction checks** — the operator re-verifies chain, account, live nonce, prior
     receipts, dependency hashes, next predicted CREATE address empty, base fee, balances, a no-revert
     simulation, gas estimate ≤ packet limit, cumulative exposure ≤ $130, and non-expiry.
   - Click **(2) Confirm this transaction**, then **(3) Open Rabby approval** — Rabby prompts you to sign **one**
     transaction. Approve it in Rabby.
   - The operator fetches the tx + receipt, compares every field to the packet, verifies the postcondition
     (deployed address/code, events, balances, roles, LP NFT as applicable), journals the step, and advances.
   - Any mismatch/revert/timeout **halts permanently** — no automatic retry. Regenerate + re-review to proceed.

## What is NOT executable here
The **delayed tester withdrawal (nonce 8)** is intentionally **disabled** in this operator. It requires a
separately regenerated packet and a fresh preflight after the lock's unlock time.

## Safety properties (verified in this bundle)
- Signing occurs only in Rabby, per transaction, after your explicit click. No key/seed/keystore is ever
  requested or handled. No `eth_sendRawTransaction`, no local signer, no session keys / AA, no batching, no
  automatic sends, no automatic retries (all enforced structurally and checked by `static-scan.mjs`).
- The operator only issues a fixed read set plus one `eth_sendTransaction` per step (proven by
  `operator-test.mjs`, which drives all 19 txs on a fork with a mock provider and never touches Rabby or
  mainnet).
- The provider RPC URL is read from the environment only and never printed, serialized, or stored.
