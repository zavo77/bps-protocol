// TASK 10D-6 — read-only v7 RECOVERY preflight against the live provider RPC (env only). Gates:
//  1 packet not expired AND live block timestamp strictly before expiry/deadlines; 2 deployer 5/5 + tester 2/2;
//  3 balances; 4 dependency hashes+sizes; 5 BOTH completed contracts code exact + remaining 6 predicted empty;
//  6 base fee within envelope; 7 exposure (actual steps 1+2 gas + remaining) <= $130 at fresh prices;
//  8 authorization flags + BOTH anchors still canonical on chain (tx/receipt/created address/code).
import { readFileSync } from "node:fs";
import { createPublicClient, http, keccak256, getAddress } from "viem";

const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const a = rj("recovery-packet.json"), policy = rj("recovery-policy.json"), auth = rj("operator/recovery-authorization.json");
const ENV = policy.liveRpcEnvVar || "ROBINHOOD_CHAIN_RPC_URL";
const RPC = process.env[ENV];
if (!RPC) { console.error(`FAIL: ${ENV} not set`); process.exit(1); }
const c = createPublicClient({ transport: http(RPC) });
const rpc = (m, p = []) => c.request({ method: m, params: p });
const B = (x) => BigInt(x); const A = getAddress;
const R = []; const gate = (n, cond, d = "") => R.push({ n, pass: !!cond, d });

const DEPLOYER = A(auth.wallets.deployer), TESTER = A(auth.wallets.tester);
const hexUtf8 = (s) => { let h = "0x"; for (let i = 0; i < s.length; i++) { const cc = s.charCodeAt(i); h += (cc < 16 ? "0" : "") + cc.toString(16); } return h; };

async function main() {
  const chainId = Number(B(await rpc("eth_chainId")));
  const now = new Date();
  gate("0. provider chain is 4663", chainId === 4663, "chainId=" + chainId);
  const headBlk0 = await rpc("eth_getBlockByNumber", ["latest", false]);
  const expEpoch = Math.floor(Date.parse(a.meta.expiresAtUtc) / 1000);
  gate("1. packet not expired AND live block timestamp strictly before expiry (== refreshed deadlines)", now <= new Date(a.meta.expiresAtUtc) && Number(B(headBlk0.timestamp)) < expEpoch && Number(auth.deadlineRefresh.newDeadline) === expEpoch, `now=${now.toISOString()} chainTs=${Number(B(headBlk0.timestamp))} expires=${a.meta.expiresAtUtc}`);
  const dl = Number(B(await rpc("eth_getTransactionCount", [DEPLOYER, "latest"]))), dp = Number(B(await rpc("eth_getTransactionCount", [DEPLOYER, "pending"])));
  const tl = Number(B(await rpc("eth_getTransactionCount", [TESTER, "latest"]))), tp = Number(B(await rpc("eth_getTransactionCount", [TESTER, "pending"])));
  gate("2. deployer latest=pending=5 and tester latest=pending=2", dl === 5 && dp === 5 && tl === 2 && tp === 2, `deployer ${dl}/${dp} tester ${tl}/${tp}`);
  const dEth = B(await rpc("eth_getBalance", [DEPLOYER, "latest"])), tEth = B(await rpc("eth_getBalance", [TESTER, "latest"]));
  const balOf = async (who) => B(await rpc("eth_call", [{ to: auth.infrastructure.weth, data: keccak256(hexUtf8("balanceOf(address)")).slice(0, 10) + who.slice(2).toLowerCase().padStart(64, "0") }, "latest"]));
  const dW = await balOf(DEPLOYER), tW = await balOf(TESTER);
  gate("3. balances sufficient (>= snapshot)", dEth >= B(auth.snapshotBalances.deployerEth) && tEth >= B(auth.snapshotBalances.testerEth) && dW >= B(auth.snapshotBalances.deployerWeth) && tW >= B(auth.snapshotBalances.testerWeth), `ETH d/t ${dEth}/${tEth} WETH d/t ${dW}/${tW}`);
  let depOk = true, depBad = [];
  for (const [k, d] of Object.entries(auth.dependencies)) { const code = await rpc("eth_getCode", [d.address, "latest"]); if (keccak256(code).toLowerCase() !== d.runtimeCodeHash.toLowerCase() || (code.length - 2) / 2 !== d.codeBytes) { depOk = false; depBad.push(k); } }
  gate("4. six dependency code hashes + sizes unchanged", depOk, depBad.join(","));
  const tokCode = await rpc("eth_getCode", [auth.completedContracts.canaryToken.address, "latest"]);
  const vltCode = await rpc("eth_getCode", [auth.completedContracts.lockingVault.address, "latest"]);
  let emptyOk = true, occupied = [];
  for (const [slot, d] of Object.entries(auth.deployments)) { const cc = await rpc("eth_getCode", [d.predictedAddress, "latest"]); if (!(cc === "0x" || cc === "0x0")) { emptyOk = false; occupied.push(slot); } }
  gate("5. BOTH completed contracts code exact + remaining 6 predicted addresses empty", keccak256(tokCode).toLowerCase() === auth.completedContracts.canaryToken.runtimeCodeHash.toLowerCase() && keccak256(vltCode).toLowerCase() === auth.completedContracts.lockingVault.runtimeCodeHash.toLowerCase() && emptyOk, occupied.join(","));
  const head = await rpc("eth_getBlockByNumber", ["latest", false]);
  const maxPrio = B(a.meta.feeBounds.maxPriorityFeePerGasWei), maxFee = B(a.meta.feeBounds.maxFeePerGasWei);
  gate("6. current base fee fits the fee envelope", B(head.baseFeePerGas) + maxPrio <= maxFee, `baseFee=${B(head.baseFeePerGas)} + prio=${maxPrio} <= max=${maxFee}`);
  // fresh two-source price, cache-disabled, select higher
  const [cb, kr] = await Promise.all([
    fetch("https://api.coinbase.com/v2/prices/ETH-USD/spot", { cache: "no-store" }).then(r => r.json()),
    fetch("https://api.kraken.com/0/public/Ticker?pair=ETHUSD", { cache: "no-store" }).then(r => r.json()),
  ]);
  const toMicro = (dec) => { const [i, f = ""] = String(dec).split("."); return BigInt(i) * 1_000_000n + BigInt((f + "000000").slice(0, 6)); };
  const cbP = toMicro(cb.data.amount), krP = toMicro(Object.values(kr.result)[0].c[0]);
  const higher = cbP > krP ? cbP : krP;
  const agg = B(auth.exposure.actualStep1GasCostWei) + B(auth.exposure.actualStep2GasCostWei) + B(auth.exposure.remainingPrincipalWei) + B(auth.exposure.remainingMaxGasWei);
  const micro = (agg * higher) / 10n ** 18n;
  gate("7. recovery exposure (actual steps 1+2 gas + remaining principal + remaining max gas at 1.25x) <= $130 at fresh higher price", micro <= 130_000_000n, `${(Number(micro) / 1e6).toFixed(6)} (coinbase ${cb.data.amount} / kraken ${Object.values(kr.result)[0].c[0]})`);
  // BOTH anchors still canonical
  let anchorOk = true;
  for (const [anc, expNonce, code] of [[auth.completedStep1, 3, tokCode], [auth.completedStep2, 4, vltCode]]) {
    const tx = await rpc("eth_getTransactionByHash", [anc.txHash]);
    const rc = await rpc("eth_getTransactionReceipt", [anc.txHash]);
    if (!(tx && rc && B(rc.status) === 1n && A(tx.from) === DEPLOYER && Number(B(tx.nonce)) === expNonce && A(rc.contractAddress) === A(anc.createdAddress) && keccak256(code).toLowerCase() === anc.deployedRuntimeCodeHash.toLowerCase())) anchorOk = false;
  }
  const flagsOk = ["broadcastReady", "liveWritesApproved", "executionAuthorized", "fundingAuthorized"].every(k => a.safetyFlags[k] === true && auth.flags[k] === true);
  gate("8. authorization flags true + BOTH completed anchors canonical on chain", anchorOk && flagsOk);

  console.log("RECOVERY PREFLIGHT");
  for (const r of R) console.log(` [${r.pass ? "PASS" : "FAIL"}] ${r.n}${r.d ? "  (" + r.d + ")" : ""}`);
  const pass = R.every(r => r.pass);
  console.log(pass ? "RECOVERY PREFLIGHT: PASS — recovery execution authorized for the remaining 17 transactions; signing occurs only via per-tx Rabby approval." : "RECOVERY PREFLIGHT: FAIL — do not execute; regenerate.");
  process.exit(pass ? 0 : 1);
}
main().catch(e => { console.error("RECOVERY PREFLIGHT ERROR:", e.message); process.exit(1); });
