// TASK 10D-6 — v7 RECOVERY operator engine. Original steps 1 AND 2 are VERIFIED completed anchors
// (non-actionable; no precheck/confirm/dispatch/send/retry/rebroadcast route — they are not in the signable
// set at all, and no code path can send deployer nonce 3 or 4). Only the remaining 17 transactions
// (original steps 3-19) are signable. Reuses the accepted event/receipt postconditions, cumulative
// checkpoints, durable storage state machine and bounded-gas verifier from CanaryOperator. The bounded
// verifier enforces the AUTHORIZED v7 gas policy via the digest-bound per-step ceilings:
// gasLimit <= 2x reviewed; maxFee <= reviewed; priority <= 50,000,000 wei; priority <= maxFee;
// gasLimit*maxFee <= exactly 1.25x reviewed maxGasCostWei; security-critical fields EXACT.
import { CanaryOperator } from "./operator-core.mjs";
import { buildRecoveryCanonical, validateRecoveryStrict, V7_REMAINING_SLOTS, PRIORITY_CEILING_WEI } from "./recovery-canonical.mjs";
import { digestOf, rawDuplicateKeys } from "./canonical.mjs";

const V5_ZIP_SHA = "5a6246ca51bd3237e6d925153439d9040b1c3674c0e026e9d8f187e7a5e64b3b";
const V5_REVIEWED_AUTH_DIGEST = "0x4fdfd36b99d6090fef67f21bd3b2027e8dc7e339861ae94eb0f292da2b6ee248";
const V6_ZIP_SHA = "fd57f5c1bcc4d296250bfb04cab096a4f56299b0deb2edefbf4824f9414fb356";
const V6_RECOVERY_AUTH_DIGEST = "0xdca841943bc32b76df5a04310d30b70a4a9244dcc4d9445d8d42500fe01ecf57";

export class RecoveryOperator extends CanaryOperator {
  constructor({ recoveryPacket, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw, provider, keccak256, getAddress, priceProvider, storage, now, receiptPolls, pollMs }) {
    // DISTINCT "canaryv7" namespace keyed by the v7 recovery digest — v5 ("canary") and v6 ("canaryv6")
    // records are never read, mutated, cleared or migrated.
    super({ packet: null, policy: null, snapshot: null, reviewedAuthorization: null, provider, keccak256, getAddress, priceProvider, storage, now, receiptPolls, pollMs, keyPrefix: "canaryv7", keyDigest: recoveryPacket && recoveryPacket.meta ? recoveryPacket.meta.recoveryAuthorizationDigest : null });
    this.recoveryPacket = recoveryPacket; this.recoveryPolicy = recoveryPolicy; this.recoverySnapshot = recoverySnapshot;
    this.recoveryAuthorization = recoveryAuthorization || null;
    this.recoveryAuthorizationRaw = recoveryAuthorizationRaw || (recoveryAuthorization ? JSON.stringify(recoveryAuthorization) : null);
    this.execDigest = recoveryPacket && recoveryPacket.meta ? recoveryPacket.meta.recoveryAuthorizationDigest : null;
    this.completedStep1 = null; this.completedStep2 = null; this.isRecovery = true;
  }

  bindAndVerifyPacket() {
    const a = this.recoveryPacket, p = this.recoveryPolicy, s = this.recoverySnapshot, c = {}, A = this.getAddress;
    const recon = buildRecoveryCanonical({ packet: a, policy: p, snapshot: s, getAddress: A });
    c.canonicalReconstructs = recon.errors.length === 0;
    const digestR = recon.object ? digestOf(recon.object, this.keccak256) : null;
    const pkg = this.recoveryAuthorization, raw = this.recoveryAuthorizationRaw || (pkg ? JSON.stringify(pkg) : "");
    const strictErr = pkg ? validateRecoveryStrict(pkg, raw, A) : ["packaged recovery-authorization missing"];
    const dupKeys = pkg ? rawDuplicateKeys(raw) : ["<missing>"];
    c.packagedValid = strictErr.length === 0; c.packagedNoDuplicateKeys = dupKeys.length === 0;
    const digestP = pkg ? digestOf(pkg, this.keccak256) : null;
    const eq = (x, y) => !!x && !!y && String(x).toLowerCase() === String(y).toLowerCase();
    c.anchorsAgree = eq(digestR, digestP) && eq(digestR, a.meta && a.meta.recoveryAuthorizationDigest) && eq(digestR, p.recoveryAuthorizationDigest);
    c.reconMatchesPackaged = !!recon.object && !!pkg && this._stable(recon.object) === this._stable(pkg);
    const recomputed = pkg ? this.keccak256(this._utf8ToHex(this._stable(pkg.transactions.immediate.map(t => ({ originalIndex: t.originalIndex, chainId: 4663, signer: A(t.signer), nonce: t.nonce, type: 2, to: t.to ? A(t.to) : null, value: t.value, data: t.data, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas }))))) : null;
    c.remainingExecDigestMatches = !!pkg && eq(recomputed, a.meta.remainingExecutionDigest) && eq(recomputed, pkg.digests.remainingExecutionDigest);
    c.v5v6AnchorsBound = !!pkg && pkg.v5.zipSha256 === V5_ZIP_SHA && eq(pkg.v5.reviewedAuthorizationDigest, V5_REVIEWED_AUTH_DIGEST) && pkg.v6.zipSha256 === V6_ZIP_SHA && eq(pkg.v6.recoveryAuthorizationDigest, V6_RECOVERY_AUTH_DIGEST);
    c.originalPlanBound = !!pkg && pkg.originalPlan.stepCount === 19;
    c.seventeenSignables = !!pkg && pkg.transactions.count === 17 && pkg.transactions.immediate.length === 17 && pkg.transactions.immediate.every((t, i) => t.originalIndex === i + 3) && !pkg.transactions.immediate.some(t => t.originalIndex === 1 || t.originalIndex === 2);
    c.nonceExpectations = !!pkg && pkg.remaining.deployerExpectedNonce === 5 && pkg.remaining.testerExpectedNonce === 2;
    c.completedAnchors = !!pkg && pkg.completedStep1 && pkg.completedStep1.nonce === 3 && pkg.completedStep2 && pkg.completedStep2.nonce === 4 && eq(pkg.completedStep1.createdAddress, pkg.completedContracts.canaryToken.address) && eq(pkg.completedStep2.createdAddress, pkg.completedContracts.lockingVault.address);
    c.gasPolicyBound = !!pkg && pkg.gasPolicy.maxPriorityCeilingWei === PRIORITY_CEILING_WEI && pkg.gasPolicy.maxFeeCeilingUnchanged === true && pkg.gasPolicy.gasLimitCeilingUnchanged === true;
    // (10D-6) deadline refresh: bound calldata of steps 13/15/17 hashes to the recorded newDataKeccak, the
    // embedded deadline word equals the bound new deadline, and the new deadline equals the packet expiry.
    c.deadlineRefreshBound = !!pkg && (() => {
      const dr = pkg.deadlineRefresh; if (!dr || dr.steps.length !== 3) return false;
      if (Number(dr.newDeadline) !== Math.floor(Date.parse(pkg.expiresAtUtc) / 1000)) return false;
      for (const x of dr.steps) {
        const tx = pkg.transactions.immediate.find(t => t.originalIndex === x.originalIndex); if (!tx) return false;
        if (this.keccak256(tx.data).toLowerCase() !== x.newDataKeccak.toLowerCase()) return false;
        const word = BigInt("0x" + tx.data.slice(2 + x.wordOffsetBytes * 2, 2 + x.wordOffsetBytes * 2 + 64));
        if (word.toString() !== dr.newDeadline) return false;
      }
      return true;
    })();
    c.chainId4663 = !!pkg && pkg.chainId === 4663;
    c.capIs130 = !!pkg && pkg.maxAllInclusiveExposureUsd === 130;
    const ok = Object.values(c).every(Boolean);
    this.bound = ok;
    if (!ok) { this._halt("recovery binding failed: " + Object.entries(c).filter(([, v]) => !v).map(([k]) => k).join(",")); return { ok, recoveryAuthorizationDigest: digestR, checks: c }; }

    // ===== SINGLE BOUND RUNTIME DATA SOURCE (v7) =====
    const cc = pkg; this.canon = cc; this.completedStep1 = cc.completedStep1; this.completedStep2 = cc.completedStep2;
    this.capMicro = BigInt(cc.maxAllInclusiveExposureUsd) * 1_000_000n;
    this.DEPLOYER = A(cc.wallets.deployer); this.TESTER = A(cc.wallets.tester);
    this.WETH = A(cc.infrastructure.weth); this.FACTORY = A(cc.infrastructure.uniswapV3Factory); this.NPM = A(cc.infrastructure.nonfungiblePositionManager);
    this.SWAP = A(cc.infrastructure.swapRouter02); this.REGISTRY = A(cc.infrastructure.rialtoRegistry); this.NVDA = A(cc.infrastructure.nvdaStockToken);
    this.pool = A(cc.pool);
    this.addr = { canaryToken: A(cc.completedContracts.canaryToken.address), lockingVault: A(cc.completedContracts.lockingVault.address) };
    for (const slot of V7_REMAINING_SLOTS) this.addr[slot] = A(cc.deployments[slot].predictedAddress);
    this.steps = cc.transactions.immediate.map(t => {
      const st = { index: t.remainingIndex, originalIndex: t.originalIndex, remainingIndex: t.remainingIndex, phase: t.phase, label: t.label, postconditionType: t.postconditionType, chainId: 4663, signer: A(t.signer), nonce: t.nonce, to: t.to ? A(t.to) : null, value: t.value, dataOrInitCode: t.data, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas, gasCeilings: t.gasCeilings };
      st.maxGasCostWei = (BigInt(t.gasLimit) * BigInt(t.maxFeePerGas)).toString();
      return st;
    });
    const remDeploys = this.steps.filter(x => x.phase === "A-deploy").sort((x, y) => x.nonce - y.nonce);
    remDeploys.forEach((st, i) => { const slot = V7_REMAINING_SLOTS[i]; st.slot = slot; st.predictedCreationAddress = A(cc.deployments[slot].predictedAddress); st.expectedRuntimeHash = cc.deployments[slot].runtimeCodeHash; });
    this._expiresAtUtc = cc.expiresAtUtc;
    // recovery exposure = remaining principal + (remaining max gas + BOTH actual completed gas costs)
    this._exposurePrincipalWei = cc.exposure.remainingPrincipalWei;
    this._exposureGasWei = (BigInt(cc.exposure.remainingMaxGasWei) + BigInt(cc.exposure.actualStep1GasCostWei) + BigInt(cc.exposure.actualStep2GasCostWei)).toString();
    this._authFlags = cc.flags;
    this.recoveryPacket = null; this.recoveryPolicy = null; this.recoverySnapshot = null;
    return { ok, recoveryAuthorizationDigest: digestR, checks: c };
  }

  // NO dispatch route exists for completed steps: they are not in this.steps; no deployer nonce-3 or
  // nonce-4 transaction can be built or sent. Explicit assertion for callers/tests.
  completedStepIsActionable() { return this.steps.some(s => (this.getAddress(s.signer) === this.DEPLOYER && (s.nonce === 3 || s.nonce === 4)) || s.originalIndex === 1 || s.originalIndex === 2); }
  step1IsActionable() { return this.completedStepIsActionable(); } // v6-compatible alias

  // re-verify BOTH completed on-chain anchors as the reconciliation authority.
  async _verifyCompletedAnchors(provider) {
    if (!(await this._assertChain(provider))) return { ok: false, reason: "provider chain != 4663 at anchor verify" };
    const A = this.getAddress;
    for (const [label, anc, expNonce] of [["step1", this.completedStep1, 3], ["step2", this.completedStep2, 4]]) {
      const tx = await this._req(provider, "eth_getTransactionByHash", [anc.txHash]);
      const rc = await this._req(provider, "eth_getTransactionReceipt", [anc.txHash]);
      if (!tx || !rc) return { ok: false, reason: label + " anchor tx/receipt not found on chain" };
      if (tx.chainId !== undefined && tx.chainId !== null && Number(BigInt(tx.chainId)) !== 4663) return { ok: false, reason: label + " tx-response chainId present and != 4663" };
      if (BigInt(rc.status) !== 1n) return { ok: false, reason: label + " receipt not success" };
      if (rc.transactionHash.toLowerCase() !== anc.txHash.toLowerCase()) return { ok: false, reason: label + " receipt hash mismatch" };
      if (A(tx.from) !== A(anc.from) || Number(BigInt(tx.nonce)) !== expNonce || !(tx.to === null || tx.to === undefined) || BigInt(tx.value) !== 0n) return { ok: false, reason: label + " tx fields differ from anchor" };
      if (anc.inputKeccak && this.keccak256(tx.input).toLowerCase() !== anc.inputKeccak.toLowerCase()) return { ok: false, reason: label + " input keccak differs from anchor" };
      if (A(rc.contractAddress) !== A(anc.createdAddress)) return { ok: false, reason: label + " created address differs from anchor" };
      const code = await this._req(provider, "eth_getCode", [anc.createdAddress, "latest"]);
      if (this.keccak256(code).toLowerCase() !== anc.deployedRuntimeCodeHash.toLowerCase()) return { ok: false, reason: label + " deployed runtime hash differs from anchor" };
    }
    return { ok: true };
  }

  async reconcile(provider) {
    if (!this.bound) return { ok: false, reason: "not bound" };
    if (!this.connected) return { ok: false, reason: "not connected" };
    if (this.halted && !this.uncertainSend) return { ok: false, halted: true, reason: this.haltReason };
    const anc = await this._verifyCompletedAnchors(provider); if (!anc.ok) return this._halt("recovery reconciliation: " + anc.reason);
    return super.reconcile(provider);
  }

  // (10D-6 req 7) runtime deadline gates on top of the shared preconditions:
  //  - the PROVIDER block timestamp must be strictly before the packet expiry;
  //  - for a deadline-bearing step, the deadline decoded from the BOUND calldata must equal the bound
  //    packet expiry exactly (no runtime/browser-side substitution is possible: the calldata itself is
  //    digest-bound and _buildSendTx/_verifyTxAndReceipt use/require those exact bytes).
  async preconditions(provider) {
    const pre = await super.preconditions(provider);
    if (!pre.ok) return pre;
    const head = await this._req(provider, "eth_getBlockByNumber", ["latest", false]);
    const expiryEpoch = Math.floor(Date.parse(this.canon.expiresAtUtc) / 1000);
    if (!(Number(BigInt(head.timestamp)) < expiryEpoch)) return this._halt("provider block timestamp is not strictly before the packet expiry");
    const t = this.steps[pre.step];
    const dr = this.canon.deadlineRefresh;
    const step = dr && dr.steps.find(x => x.originalIndex === t.originalIndex);
    if (step) {
      const word = BigInt("0x" + t.dataOrInitCode.slice(2 + step.wordOffsetBytes * 2, 2 + step.wordOffsetBytes * 2 + 64));
      if (word.toString() !== dr.newDeadline) return this._halt("bound calldata deadline != bound packet expiry at original step " + t.originalIndex);
      if (!(Number(BigInt(head.timestamp)) < Number(dr.newDeadline))) return this._halt("provider block timestamp has passed the bound transaction deadline");
    }
    return pre;
  }
}
