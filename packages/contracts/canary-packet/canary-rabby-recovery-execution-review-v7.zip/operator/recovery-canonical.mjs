// TASK 10D-6 — canonical v7 RECOVERY authorization. Original steps 1 AND 2 are verified completed on-chain
// anchors (non-actionable); only the remaining 17 transactions (original steps 3-19) are signable.
// AUTHORIZED GAS-POLICY CHANGE (explicit, superseding the earlier prohibition): for original steps 3-19
// ONLY, each per-step maximum gas-cost ceiling = exactly 1.25x its accepted v6 reviewed maxGasCostWei.
// maxFeePerGas ceiling unchanged; maxPriorityFeePerGas ceiling = exactly 50,000,000 wei (0.05 gwei);
// gasLimit ceiling unchanged (2x reviewed); $130 all-inclusive recovery cap unchanged.
// recoveryAuthorizationDigest = keccak256(canonicalStable(object)); every security-relevant value is a leaf.
import { isDec, isHex, postconditionType, DEP_NAMES, SLOT_CONTRACT } from "./canonical.mjs";

export const RECOVERY_SCHEMA = "canary-recovery-authorization";
export const RECOVERY_VERSION = "10D-6";
export const RECOVERY_SCOPE = "BPSC-TEST canary RECOVERY v7 (original steps 1 and 2 completed on chain); Robinhood Chain mainnet; remaining 17 transactions only (original steps 3-19); per-step gas-cost ceiling exactly 1.25x reviewed (explicitly authorized); maximum all-inclusive exposure $130; individual Rabby approvals; canonical BPS production excluded.";
export const V7_REMAINING_SLOTS = ["claimManager", "rialtoAdapter", "coordinator", "stockVault", "uniswapAdapter", "tradeRouter"];
export const PRIORITY_CEILING_WEI = "50000000"; // exactly 0.05 gwei — explicitly authorized

const anchorShape = (c, label, expNonce, { A, N, I, HH, BT, STR, err }) => ({
  txHash: HH(c.txHash, label + ".hash"), from: A(c.from, label + ".from"), nonce: I(c.nonce, label + ".nonce") === expNonce ? expNonce : (err.push(label + ".nonce!=" + expNonce), 0),
  type: 2, value: N(c.value || "0", label + ".value"),
  createdAddress: A(c.createdAddress, label + ".addr"), blockNumber: N(c.blockNumber, label + ".bn"), blockHash: HH(c.blockHash, label + ".bh"),
  gasLimit: N(c.gasLimit, label + ".gl"), maxFeePerGas: N(c.maxFeePerGas, label + ".mf"), maxPriorityFeePerGas: N(c.maxPriorityFeePerGas, label + ".mp"),
  gasUsed: N(c.gasUsed, label + ".gu"), effectiveGasPriceWei: N(c.effectiveGasPriceWei, label + ".egp"), actualGasCostWei: N(c.actualGasCostWei, label + ".cost"),
  deployedRuntimeCodeHash: HH(c.deployedRuntimeCodeHash, label + ".rh"), deployedCodeSize: I(c.deployedCodeSize, label + ".sz"), inputKeccak: HH(c.inputKeccak, label + ".ik"),
});

export function buildRecoveryCanonical({ packet: a, policy: p, snapshot: s, getAddress }) {
  const err = [];
  const A = (x, w) => { if (!isHex(x, 20)) { err.push("non-address " + w); return "0x0000000000000000000000000000000000000000"; } return getAddress(x); };
  const N = (x, w) => { const v = typeof x === "number" ? String(x) : x; if (!isDec(v)) { err.push("non-canonical-number " + w + "(" + x + ")"); return "0"; } return v; };
  const I = (x, w) => { if (typeof x !== "number" || !Number.isInteger(x) || x < 0) { err.push("non-integer " + w); return 0; } return x; };
  const SI = (x, w) => { if (typeof x !== "number" || !Number.isInteger(x)) { err.push("non-int " + w); return 0; } return x; };
  const HH = (x, w) => { if (!isHex(x, 32)) { err.push("bad-hash " + w); return "0x" + "0".repeat(64); } return x.toLowerCase(); };
  const BT = (x, w) => { if (x !== true) { err.push("expected-true " + w); return false; } return true; };
  const BF = (x, w) => { if (x !== false) { err.push("expected-false " + w); return false; } return false; };
  const STR = (x, w, want) => { if (typeof x !== "string" || (want !== undefined && x !== want)) { err.push("bad-string " + w); return want ?? ""; } return x; };
  const H = { A, N, I, HH, BT, STR, err };
  const req = (c, w) => { if (!c) err.push("missing " + w); };
  req(a && a.meta && a.meta.authorization, "meta");
  req(a && a.completedStep1 && a.completedStep2, "completed anchors");
  req(a && a.immediateTransactions && a.immediateTransactions.length === 17, "17 immediate");
  req(a && a.capArithmetic, "capArithmetic");
  req(a && a.lpUsage && a.buyAccounting && a.sellAccounting && a.lockAndWithdraw, "expectations");
  req(a && a.provenance && a.provenance.contracts, "provenance");
  req(a && a.deployedRuntimeCodeHashes && a.addressGuards && a.addressGuards.remainingPredicted, "guards");
  req(s && s.pinnedBlock && s.nonces && s.balances && s.externalCodeHashes && s.expectedNonces && s.completedContracts, "snapshot");
  req(p && p.wallets && p.infrastructure && p.economics && p.gas, "policy");
  if (err.length) return { errors: err, object: null };

  const au = a.meta.authorization, lu = a.lpUsage, bu = a.buyAccounting, se = a.sellAccounting, lk = a.lockAndWithdraw, ca = a.capArithmetic;
  const sigStep = (t) => {
    const g = t.gasCeilings || {};
    const pc = postconditionType(t); if (pc === "unknown") err.push("pc unknown " + t.label);
    const reviewedCost = BigInt(N(t.gasLimit, "x")) * BigInt(N(t.maxFeePerGas, "x"));
    // AUTHORIZED POLICY ARITHMETIC — enforced as identities inside the digest-bound object:
    if (BigInt(N(g.reviewedMaxGasCostWei, "gc.rev")) !== reviewedCost) err.push("gc.reviewed != gasLimit*maxFee @ " + t.label);
    if (BigInt(N(g.maxGasCostCeilingWei, "gc.cost")) * 4n !== reviewedCost * 5n) err.push("gc.cost != exactly 1.25x reviewed @ " + t.label);
    if (N(g.maxFeeCeilingWei, "gc.mf") !== N(t.maxFeePerGas, "x")) err.push("gc.maxFee ceiling changed @ " + t.label);
    if (N(g.maxPriorityCeilingWei, "gc.mp") !== PRIORITY_CEILING_WEI) err.push("gc.priority != exactly 50000000 @ " + t.label);
    if (BigInt(N(g.gasLimitCeiling, "gc.gl")) !== BigInt(N(t.gasLimit, "x")) * 2n) err.push("gc.gasLimit ceiling != 2x reviewed @ " + t.label);
    return {
      originalIndex: I(t.originalIndex, "tx.orig"), remainingIndex: I(t.remainingIndex, "tx.rem"),
      phase: STR(t.phase, "tx.phase"), label: STR(t.label, "tx.label"), postconditionType: pc,
      chainId: I(t.chainId, "tx.chain"), signer: A(t.signer, "tx.signer"), nonce: I(t.nonce, "tx.nonce"), type: 2,
      to: t.to ? A(t.to, "tx.to") : null, value: N(t.value || "0", "tx.value"),
      data: (isHex(t.dataOrInitCode) ? t.dataOrInitCode.toLowerCase() : (err.push("tx.data"), "0x")),
      gasLimit: N(t.gasLimit, "tx.gas"), maxFeePerGas: N(t.maxFeePerGas, "tx.maxFee"), maxPriorityFeePerGas: N(t.maxPriorityFeePerGas, "tx.maxPrio"),
      gasCeilings: { gasLimitCeiling: N(g.gasLimitCeiling, "gc.gl"), maxFeeCeilingWei: N(g.maxFeeCeilingWei, "gc.mf"), maxPriorityCeilingWei: N(g.maxPriorityCeilingWei, "gc.mp"), reviewedMaxGasCostWei: N(g.reviewedMaxGasCostWei, "gc.rev"), maxGasCostCeilingWei: N(g.maxGasCostCeilingWei, "gc.cost") },
    };
  };
  const deployments = {};
  for (const slot of V7_REMAINING_SLOTS) { const drh = a.deployedRuntimeCodeHashes[slot], rp = a.addressGuards.remainingPredicted[slot]; deployments[slot] = { predictedAddress: A(rp, "dep." + slot), runtimeCodeHash: HH(drh, "dep.hash." + slot) }; }
  const dependencies = {};
  for (const name of DEP_NAMES) { const d = s.externalCodeHashes[name]; if (!d) { err.push("dep " + name); continue; } dependencies[name] = { address: A(d.address, "dep." + name), runtimeCodeHash: HH(d.runtimeCodeHash, "deph." + name), codeBytes: I(d.codeBytes, "depb." + name) }; }

  // ===== (10D-6 authorized) deadline refresh — identity-checked inside the digest-bound object =====
  const dr = a.meta.deadlineRefresh || {};
  const expEpoch = Math.floor(Date.parse(a.meta.expiresAtUtc) / 1000);
  const newDl = N(dr.newDeadline, "dr.new"), oldDl = N(dr.oldDeadline, "dr.old");
  if (oldDl !== "1784916327") err.push("dr.oldDeadline != 1784916327");
  if (BigInt(newDl) !== BigInt(String(s.pinnedBlock.timestamp)) + 21600n) err.push("dr.newDeadline != pinned ts + 21600");
  if (Number(newDl) !== expEpoch) err.push("dr.newDeadline != packet expiry epoch");
  const drSteps = Array.isArray(dr.steps) ? dr.steps : [];
  if (drSteps.map(x => x.originalIndex).join(",") !== "13,15,17") err.push("dr.steps != [13,15,17]");
  const drCanon = drSteps.map(x => {
    const tx = a.immediateTransactions.find(t => t.originalIndex === x.originalIndex);
    if (!tx) { err.push("dr step tx missing " + x.originalIndex); return null; }
    const off = I(x.wordOffsetBytes, "dr.off");
    const word = BigInt("0x" + tx.dataOrInitCode.slice(2 + off * 2, 2 + off * 2 + 64));
    if (word.toString() !== newDl) err.push("dr: bound calldata word at offset " + off + " != new deadline @ step " + x.originalIndex);
    return { originalIndex: I(x.originalIndex, "dr.oi"), label: STR(x.label, "dr.lbl"), wordOffsetBytes: off, oldDataKeccak: HH(x.oldDataKeccak, "dr.okk"), newDataKeccak: HH(x.newDataKeccak, "dr.nkk") };
  }).filter(Boolean);

  const step1Cost = N(ca.actualStep1GasCostWei, "exp.s1"), step2Cost = N(ca.actualStep2GasCostWei, "exp.s2");
  const remainingPrincipalWei = N(ca.remainingPrincipalWei, "exp.principal"), remainingMaxGasWei = N(ca.remainingMaxGasWei, "exp.maxgas"), aggregateWei = N(ca.aggregateWei, "exp.agg");
  if (BigInt(step1Cost) + BigInt(step2Cost) + BigInt(remainingPrincipalWei) + BigInt(remainingMaxGasWei) !== BigInt(aggregateWei)) err.push("recovery exposure identity: s1+s2+principal+maxgas != aggregate");

  const object = {
    schema: STR(RECOVERY_SCHEMA, "schema", RECOVERY_SCHEMA), version: STR(RECOVERY_VERSION, "version", RECOVERY_VERSION),
    canary: BT(au.canary, "canary") && BT(p.canary, "pcanary"),
    production: (BF(au.production, "prod") === false && BF(p.production, "pprod") === false) ? false : (err.push("prod"), true),
    chainId: I(a.meta.chainId, "chain") === 4663 && p.chainId === 4663 ? 4663 : (err.push("chain"), 0),
    scope: STR(au.scope, "scope", RECOVERY_SCOPE) === RECOVERY_SCOPE ? RECOVERY_SCOPE : (err.push("scope"), ""),
    flags: { broadcastReady: BT(a.safetyFlags.broadcastReady, "f.b") && BT(p.safetyFlags.broadcastReady, "pf.b"), liveWritesApproved: BT(a.safetyFlags.liveWritesApproved, "f.l") && BT(p.safetyFlags.liveWritesApproved, "pf.l"), executionAuthorized: BT(a.safetyFlags.executionAuthorized, "f.e") && BT(p.safetyFlags.executionAuthorized, "pf.e"), fundingAuthorized: BT(a.safetyFlags.fundingAuthorized, "f.f") && BT(p.safetyFlags.fundingAuthorized, "pf.f") },
    executable: BT(a.meta.executable, "exec"),
    maxAllInclusiveExposureUsd: Number(au.maxAllInclusiveExposureUsd) === 130 ? 130 : (err.push("cap"), 0),
    generatedAtUtc: STR(a.meta.generatedAtUtc, "gen"), expiresAtUtc: STR(a.meta.expiresAtUtc, "exp"),
    validityWindowSeconds: I(a.meta.validityWindowSeconds, "vw"),
    wallets: { deployer: A(a.meta.deployer, "dep") === A(p.wallets.deployer, "pdep") ? A(a.meta.deployer, "dep") : (err.push("deployer"), ""), tester: A(a.meta.tester, "test") === A(p.wallets.tester, "ptest") ? A(a.meta.tester, "test") : (err.push("tester"), "") },
    v5: { zipSha256: STR(a.meta.v5ZipSha256, "v5zip"), reviewedAuthorizationDigest: HH(a.meta.v5ReviewedAuthorizationDigest, "v5rad") },
    v6: { zipSha256: STR(a.meta.v6ZipSha256, "v6zip"), recoveryAuthorizationDigest: HH(a.meta.v6RecoveryAuthorizationDigest, "v6rad") },
    // AUTHORIZED gas-policy change recorded explicitly in the digest-bound authorization:
    gasPolicy: {
      perStepCostMultiplier: STR(a.meta.gasPolicy.perStepCostMultiplier, "gp.mult", "1.25x reviewed maxGasCostWei (exact, steps 3-19 only)"),
      maxPriorityCeilingWei: N(a.meta.gasPolicy.maxPriorityCeilingWei, "gp.prio") === PRIORITY_CEILING_WEI ? PRIORITY_CEILING_WEI : (err.push("gp.prio!=50000000"), "0"),
      maxFeeCeilingUnchanged: BT(a.meta.gasPolicy.maxFeeCeilingUnchanged, "gp.mf"),
      gasLimitCeilingUnchanged: BT(a.meta.gasPolicy.gasLimitCeilingUnchanged, "gp.gl"),
      authorization: STR(a.meta.gasPolicy.authorization, "gp.auth"),
    },
    deadlineRefresh: { oldDeadline: oldDl, newDeadline: newDl, newDeadlineEqualsPacketExpiry: BT(dr.newDeadlineEqualsPacketExpiry, "dr.eq"), authorization: STR(dr.authorization, "dr.auth"), steps: drCanon },
    originalPlan: { stepCount: I(a.meta.originalStepCount, "osc") === 19 ? 19 : (err.push("osc"), 0), deployerStepRange: STR("2-13", "dsr", "2-13"), testerStepRange: STR("14-19", "tsr", "14-19") },
    completedStep1: { ...anchorShape(a.completedStep1, "c1", 3, H), token: { name: STR(a.completedStep1.token.name, "c1.name"), symbol: STR(a.completedStep1.token.symbol, "c1.sym", "BPSC-TEST"), decimals: I(a.completedStep1.token.decimals, "c1.dec") === 18 ? 18 : (err.push("dec"), 0), totalSupply: N(a.completedStep1.token.totalSupply, "c1.ts"), isCanary: BT(a.completedStep1.token.isCanary, "c1.canary"), maxSupply: N(a.completedStep1.token.maxSupply, "c1.max") } },
    completedStep2: { ...anchorShape(a.completedStep2, "c2", 4, H), vault: { owner: A(a.completedStep2.vault.owner, "c2.owner"), bpsToken: A(a.completedStep2.vault.bpsToken, "c2.bps") } },
    remaining: { count: I(a.remaining.count, "rc") === 17 ? 17 : (err.push("rc"), 0), deployerExpectedNonce: I(s.expectedNonces.deployer, "rdn") === 5 ? 5 : (err.push("rdn"), 0), testerExpectedNonce: I(s.expectedNonces.tester, "rtn") === 2 ? 2 : (err.push("rtn"), 0), testerSwitchAfterOriginalStep: I(a.remaining.testerSwitchAfterOriginalStep, "tsw") === 13 ? 13 : (err.push("tsw"), 0) },
    block: { number: N(String(s.pinnedBlock.number), "b.n") === a.meta.forkBlock ? String(s.pinnedBlock.number) : (err.push("b.n"), "0"), hash: (isHex(s.pinnedBlock.hash, 32) && s.pinnedBlock.hash.toLowerCase() === a.meta.forkBlockHash.toLowerCase()) ? s.pinnedBlock.hash.toLowerCase() : (err.push("b.h"), "0x"), timestamp: N(String(s.pinnedBlock.timestamp), "b.t") === a.meta.forkTimestamp ? String(s.pinnedBlock.timestamp) : (err.push("b.t"), "0"), baseFeePerGasWei: N(String(s.pinnedBlock.baseFeePerGasWei), "b.bf") === a.meta.forkBaseFeePerGasWei ? String(s.pinnedBlock.baseFeePerGasWei) : (err.push("b.bf"), "0"), chainId: I(a.meta.chainId, "b.c") },
    snapshotBalances: { deployerEth: N(String(s.balances.eth.deployer), "sb.de"), deployerWeth: N(String(s.balances.weth.deployer), "sb.dw"), testerEth: N(String(s.balances.eth.tester), "sb.te"), testerWeth: N(String(s.balances.weth.tester), "sb.tw") },
    completedContracts: { canaryToken: { address: A(s.completedContracts.canaryToken.address, "cc.tok") === A(a.completedStep1.createdAddress, "cc.tok2") ? A(s.completedContracts.canaryToken.address, "cc.tok") : (err.push("cc.token addr"), ""), runtimeCodeHash: HH(s.completedContracts.canaryToken.runtimeCodeHash, "cc.tokh") }, lockingVault: { address: A(s.completedContracts.lockingVault.address, "cc.lv") === A(a.completedStep2.createdAddress, "cc.lv2") ? A(s.completedContracts.lockingVault.address, "cc.lv") : (err.push("cc.vault addr"), ""), runtimeCodeHash: HH(s.completedContracts.lockingVault.runtimeCodeHash, "cc.lvh") } },
    infrastructure: { weth: A(p.infrastructure.weth, "weth"), uniswapV3Factory: A(p.infrastructure.uniswapV3Factory, "fac"), nonfungiblePositionManager: A(p.infrastructure.nonfungiblePositionManager, "npm"), swapRouter02: A(p.infrastructure.swapRouter02, "swap"), rialtoRegistry: A(p.infrastructure.rialtoRegistry, "reg"), nvdaStockToken: A(p.infrastructure.nvdaStockToken, "nvda") },
    dependencies, deployments,
    pool: A(a.addressGuards.poolAddress, "pool"), canaryTokenSymbol: STR("BPSC-TEST", "sym", "BPSC-TEST"),
    lp: { feeTier: I(Number(p.economics.feeTier), "lp.fee"), tickSpacing: I(Number(p.economics.tickSpacing), "lp.ts"), sqrtPriceX96: N(lu.sqrtPriceX96, "lp.sq"), tick: SI(lu.poolTickAfter, "lp.tick"), tickLower: SI(lu.tickLower, "lp.tl"), tickUpper: SI(lu.tickUpper, "lp.tu"), amount0Used: N(lu.amount0Used, "lp.a0"), amount1Used: N(lu.amount1Used, "lp.a1"), amount0Min: N(lu.amount0Min, "lp.a0m"), amount1Min: N(lu.amount1Min, "lp.a1m"), poolLiquidityAfter: N(lu.poolLiquidityAfter, "lp.liq"), token0: A(lu.token0, "lp.t0"), token1: A(lu.token1, "lp.t1"), positionOwner: A(lu.positionOwner, "lp.owner"), positionFee: I(lu.positionFee, "lp.pf") },
    buy: { tradeId: N(bu.tradeId, "b.id"), trader: A(bu.trader, "b.tr"), recipient: A(bu.recipient, "b.rc"), adapter: A(bu.adapter, "b.ad"), stockBudgetRecipient: A(bu.stockBudgetRecipient, "b.sbr"), grossWethInput: N(bu.grossWethInput, "b.g"), stockBudget: N(bu.stockBudget2pct, "b.s"), burnBudget: N(bu.burnBudget1pct, "b.bn"), userWethBudget: N(bu.userWethBudget97pct, "b.u"), userBpsOutput: N(bu.userBpsOutput, "b.ub"), bpsBurned: N(bu.bpsBurned, "b.bb"), minimumUserBpsOutput: N(bu.minimumUserBpsOutput, "b.min") },
    sell: { tradeId: N(se.tradeId, "s.id"), trader: A(se.trader, "s.tr"), recipient: A(se.recipient, "s.rc"), adapter: A(se.adapter, "s.ad"), stockBudgetRecipient: A(se.stockBudgetRecipient, "s.sbr"), grossBpsInput: N(se.grossBpsInput, "s.g"), grossWethOutput: N(se.grossWethOutput, "s.gwo"), stockBudget: N(se.stockAcquisition2pct, "s.s"), burnBudget: N(se.retirementBurn2pct, "s.bn"), userWethOutput: N(se.userWethOutput96pct, "s.u"), bpsBurned: N(se.bpsBurned, "s.bb"), minimumGrossWethOutput: N(se.minimumGrossWethOutput, "s.mg"), minimumUserWethOutput: N(se.minimumUserWethOutput, "s.mu") },
    lock: { account: A(lk.account, "l.ac"), lockId: N(lk.lockId, "l.id"), principal: N(lk.principal, "l.p"), startTime: N(lk.startTime, "l.st"), duration: I(lk.duration, "l.d"), unlockTime: N(lk.unlockTime, "l.ut"), multiplierBps: I(lk.multiplierBps, "l.m"), policyVersion: I(lk.policyVersion, "l.pv") },
    transactions: { count: I(a.immediateTransactions.length, "txc") === 17 ? 17 : (err.push("txc"), 0), immediate: a.immediateTransactions.map(sigStep), delayed: { disabled: BT(true, "del") } },
    exposure: { actualStep1GasCostWei: step1Cost, actualStep2GasCostWei: step2Cost, remainingPrincipalWei, remainingMaxGasWei, aggregateWei, aggregateMicroUsd: N(ca.aggregateMicroUsd, "exp.micro") },
    provenance: { repoHead: STR(a.provenance.repoHead, "ph"), dirtyTrackedTree: a.provenance.dirtyTrackedTree === false ? false : (err.push("dirty"), true) },
    digests: { remainingExecutionDigest: HH(a.meta.remainingExecutionDigest, "red") },
    delayedWithdrawalDisabled: BT(true, "dwd"),
  };
  return { errors: err, object };
}

const RECOVERY_TOP_KEYS = ["schema", "version", "canary", "production", "chainId", "scope", "flags", "executable", "maxAllInclusiveExposureUsd", "generatedAtUtc", "expiresAtUtc", "validityWindowSeconds", "wallets", "v5", "v6", "gasPolicy", "deadlineRefresh", "originalPlan", "completedStep1", "completedStep2", "remaining", "block", "snapshotBalances", "completedContracts", "infrastructure", "dependencies", "deployments", "pool", "canaryTokenSymbol", "lp", "buy", "sell", "lock", "transactions", "exposure", "provenance", "digests", "delayedWithdrawalDisabled"];
export function validateRecoveryStrict(loaded, rawText, getAddress) {
  const err = [];
  if (!loaded || typeof loaded !== "object") return ["not an object"];
  for (const k of Object.keys(loaded)) if (!RECOVERY_TOP_KEYS.includes(k)) err.push("unknown key " + k);
  for (const k of RECOVERY_TOP_KEYS) if (!(k in loaded)) err.push("missing key " + k);
  if (loaded.schema !== RECOVERY_SCHEMA) err.push("schema");
  if (loaded.version !== RECOVERY_VERSION) err.push("version");
  if (loaded.chainId !== 4663) err.push("chainId");
  if (loaded.maxAllInclusiveExposureUsd !== 130) err.push("cap");
  const chkAddr = (x, w) => { if (typeof x !== "string" || !/^0x[0-9a-fA-F]{40}$/.test(x) || getAddress(x) !== x) err.push("non-canonical-address " + w); };
  const chkDec = (x, w) => { if (!isDec(x)) err.push("non-canonical-number " + w); };
  const chkHash = (x, w) => { if (typeof x !== "string" || !/^0x[0-9a-f]{64}$/.test(x)) err.push("non-canonical-hash " + w); };
  ["deployer", "tester"].forEach(k => chkAddr(loaded.wallets && loaded.wallets[k], "wallets." + k));
  if (loaded.infrastructure) for (const [k, v] of Object.entries(loaded.infrastructure)) chkAddr(v, "infra." + k);
  chkAddr(loaded.pool, "pool");
  for (const [lbl, expN] of [["completedStep1", 3], ["completedStep2", 4]]) { const cc = loaded[lbl]; if (!cc) continue; chkHash(cc.txHash, lbl + ".txHash"); chkAddr(cc.createdAddress, lbl + ".created"); chkDec(cc.actualGasCostWei, lbl + ".cost"); if (cc.nonce !== expN) err.push(lbl + ".nonce"); }
  if (loaded.deployments) for (const [k, d] of Object.entries(loaded.deployments)) { chkAddr(d.predictedAddress, "deploy." + k); chkHash(d.runtimeCodeHash, "deploy.hash." + k); }
  if (loaded.exposure) ["actualStep1GasCostWei", "actualStep2GasCostWei", "remainingPrincipalWei", "remainingMaxGasWei", "aggregateWei", "aggregateMicroUsd"].forEach(k => chkDec(loaded.exposure[k], "exposure." + k));
  if (loaded.gasPolicy && loaded.gasPolicy.maxPriorityCeilingWei !== PRIORITY_CEILING_WEI) err.push("gasPolicy.priority");
  // (10D-6) deadline refresh identities in the PACKAGED object
  if (loaded.deadlineRefresh) {
    const dr = loaded.deadlineRefresh;
    if (dr.oldDeadline !== "1784916327") err.push("dr.old");
    const expEpoch = Math.floor(Date.parse(loaded.expiresAtUtc) / 1000);
    if (Number(dr.newDeadline) !== expEpoch) err.push("dr.new != expiry");
    if (!Array.isArray(dr.steps) || dr.steps.map(x => x.originalIndex).join(",") !== "13,15,17") err.push("dr.steps");
    if (loaded.transactions && Array.isArray(dr.steps)) for (const x of dr.steps) {
      const tx = (loaded.transactions.immediate || []).find(t => t.originalIndex === x.originalIndex);
      if (!tx) { err.push("dr tx " + x.originalIndex); continue; }
      const word = BigInt("0x" + tx.data.slice(2 + x.wordOffsetBytes * 2, 2 + x.wordOffsetBytes * 2 + 64));
      if (word.toString() !== dr.newDeadline) err.push("dr word @ " + x.originalIndex);
      chkHash(x.oldDataKeccak, "dr.okk"); chkHash(x.newDataKeccak, "dr.nkk");
    }
  }
  if (loaded.transactions) {
    const im = loaded.transactions.immediate || [];
    if (loaded.transactions.count !== 17 || im.length !== 17) err.push("tx count");
    if (!im.map(t => t.originalIndex).every((v, i) => v === i + 3)) err.push("original indices not 3..19");
    if (im.some(t => t.originalIndex === 1 || t.originalIndex === 2)) err.push("completed step present in signables");
    for (const t of im) {
      chkAddr(t.signer, "tx.signer"); if (t.to !== null) chkAddr(t.to, "tx.to");
      ["value", "gasLimit", "maxFeePerGas", "maxPriorityFeePerGas"].forEach(k => chkDec(t[k], "tx." + k));
      if (t.type !== 2) err.push("tx.type"); if (t.chainId !== 4663) err.push("tx.chainId");
      ["gasLimitCeiling", "maxFeeCeilingWei", "maxPriorityCeilingWei", "reviewedMaxGasCostWei", "maxGasCostCeilingWei"].forEach(k => chkDec(t.gasCeilings[k], "gc." + k));
      // the authorized policy identities must hold in the PACKAGED object too
      if (BigInt(t.gasCeilings.reviewedMaxGasCostWei) !== BigInt(t.gasLimit) * BigInt(t.maxFeePerGas)) err.push("gc.reviewed identity @ " + t.originalIndex);
      if (BigInt(t.gasCeilings.maxGasCostCeilingWei) * 4n !== BigInt(t.gasCeilings.reviewedMaxGasCostWei) * 5n) err.push("gc.1.25x identity @ " + t.originalIndex);
      if (t.gasCeilings.maxFeeCeilingWei !== t.maxFeePerGas) err.push("gc.maxFee unchanged @ " + t.originalIndex);
      if (t.gasCeilings.maxPriorityCeilingWei !== PRIORITY_CEILING_WEI) err.push("gc.priority @ " + t.originalIndex);
      if (BigInt(t.gasCeilings.gasLimitCeiling) !== BigInt(t.gasLimit) * 2n) err.push("gc.gasLimit 2x @ " + t.originalIndex);
    }
  }
  return err;
}
