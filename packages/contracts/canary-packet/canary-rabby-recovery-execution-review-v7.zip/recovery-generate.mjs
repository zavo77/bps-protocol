// TASK 10D-6 — assemble the fresh v7 RECOVERY packet + policy + canonical recovery authorization.
// Original steps 1 and 2 are verified completed anchors; only original steps 3-19 (17 txs) are signable.
// AUTHORIZED GAS POLICY (explicit, narrow): per-step maxGasCost ceiling = exactly 1.25x the accepted v6
// reviewed maxGasCostWei (steps 3-19 only); maxFee ceiling unchanged; priority ceiling = exactly 50,000,000
// wei; gasLimit ceiling unchanged (2x reviewed); $130 all-inclusive cap unchanged. Read-only; no chain write.
import { readFileSync, writeFileSync } from "node:fs";
import { keccak256, getAddress, decodeFunctionData, encodeFunctionData } from "viem";
import { buildRecoveryCanonical, RECOVERY_SCOPE, PRIORITY_CEILING_WEI } from "./operator/recovery-canonical.mjs";
import { digestOf } from "./operator/canonical.mjs";

const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const rehearsal = rj("canary-unsigned-packet.json");
const policy = rj("review-policy.json");
const anchorFile = rj("recovery-anchor.json");
const snap = rj("recovery-snapshot.json");
const price = rj("recovery-price-snapshot.json");
const A = getAddress, B = (x) => BigInt(x);
const stable = (v) => Array.isArray(v) ? "[" + v.map(stable).join(",") + "]" : (v && typeof v === "object") ? "{" + Object.keys(v).sort().map(k => JSON.stringify(k) + ":" + stable(v[k])).join(",") + "}" : JSON.stringify(v);
const toHexUtf8 = (s) => { let h = "0x"; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h += (c < 16 ? "0" : "") + c.toString(16); } return h; };

const c1 = anchorFile.completedStep1, c2 = anchorFile.completedStep2;
const CAP_MICRO = B(price.selected.microUsd);
const WINDOW = 21600;

// ===== (10D-6, explicitly authorized) DEADLINE REFRESH for original steps 13 / 15 / 17 ONLY =====
// The accepted source calldata must contain OLD_DEADLINE; the calldata is DECODED with the accepted ABI,
// only the named `deadline` argument is changed to the canonical v7 packet expiry (pinned ts + 21600),
// and re-encoded (no byte-search replacement). A byte-for-byte proof restricts the change to that single
// 32-byte ABI word. Every other remaining calldata must stay byte-identical to the accepted version.
const OLD_DEADLINE = 1784916327n;
const NEW_DEADLINE = BigInt(snap.pinnedBlock.timestamp) + BigInt(WINDOW);
const NPM_ABI = [{ type: "function", name: "mint", stateMutability: "payable", inputs: [{ components: [{ name: "token0", type: "address" }, { name: "token1", type: "address" }, { name: "fee", type: "uint24" }, { name: "tickLower", type: "int24" }, { name: "tickUpper", type: "int24" }, { name: "amount0Desired", type: "uint256" }, { name: "amount1Desired", type: "uint256" }, { name: "amount0Min", type: "uint256" }, { name: "amount1Min", type: "uint256" }, { name: "recipient", type: "address" }, { name: "deadline", type: "uint256" }], name: "params", type: "tuple" }], outputs: [{ type: "uint256" }, { type: "uint128" }, { type: "uint256" }, { type: "uint256" }] }];
const ROUTER_ABI = JSON.parse(readFileSync(U("artifacts/BPSTradeRouter.json"), "utf8")).abi;
const DEADLINE_STEPS = { "NPM.mint": { abi: NPM_ABI }, "buyExactWethForBps": { abi: ROUTER_ABI }, "sellExactBpsForWeth": { abi: ROUTER_ABI } };

function refreshDeadline(label, oldData) {
  const { abi } = DEADLINE_STEPS[label];
  const dec = decodeFunctionData({ abi, data: oldData });
  let newArgs, oldDl;
  if (label === "NPM.mint") {
    const p0 = dec.args[0]; oldDl = BigInt(p0.deadline);
    newArgs = [{ ...p0, deadline: NEW_DEADLINE }];
  } else {
    oldDl = BigInt(dec.args[dec.args.length - 1]);
    newArgs = [...dec.args.slice(0, -1), NEW_DEADLINE];
  }
  if (oldDl !== OLD_DEADLINE) throw new Error(label + ": accepted calldata deadline " + oldDl + " != required OLD_DEADLINE " + OLD_DEADLINE);
  const newData = encodeFunctionData({ abi, functionName: dec.functionName, args: newArgs });
  // ---- byte-for-byte proof: exactly ONE 32-byte ABI word differs; everything else identical ----
  if (newData.length !== oldData.length) throw new Error(label + ": calldata length changed");
  if (newData.slice(0, 10).toLowerCase() !== oldData.slice(0, 10).toLowerCase()) throw new Error(label + ": selector changed");
  const diffBytes = [];
  for (let i = 2; i < oldData.length; i += 2) if (oldData.slice(i, i + 2).toLowerCase() !== newData.slice(i, i + 2).toLowerCase()) diffBytes.push((i - 2) / 2);
  if (diffBytes.length === 0) throw new Error(label + ": no bytes changed");
  const wordOffsetBytes = 4 + Math.floor((diffBytes[0] - 4) / 32) * 32;    // 32-byte ABI word containing the first diff
  for (const bo of diffBytes) if (bo < wordOffsetBytes || bo >= wordOffsetBytes + 32) throw new Error(label + ": byte " + bo + " outside the single deadline word @" + wordOffsetBytes);
  const word = BigInt("0x" + newData.slice(2 + wordOffsetBytes * 2, 2 + wordOffsetBytes * 2 + 64));
  if (word !== NEW_DEADLINE) throw new Error(label + ": changed word is not the new deadline");
  const oldWord = BigInt("0x" + oldData.slice(2 + wordOffsetBytes * 2, 2 + wordOffsetBytes * 2 + 64));
  if (oldWord !== OLD_DEADLINE) throw new Error(label + ": old word is not the old deadline");
  // decode(new): every argument other than deadline deep-equals the accepted decoding
  const dec2 = decodeFunctionData({ abi, data: newData });
  const norm = (v) => JSON.stringify(v, (k, x) => typeof x === "bigint" ? x.toString() : x);
  if (label === "NPM.mint") { const a0 = { ...dec.args[0], deadline: "0" }, b0 = { ...dec2.args[0], deadline: "0" }; if (norm(a0) !== norm(b0)) throw new Error(label + ": non-deadline tuple field changed"); if (BigInt(dec2.args[0].deadline) !== NEW_DEADLINE) throw new Error(label + ": decoded new deadline wrong"); }
  else { if (norm(dec.args.slice(0, -1)) !== norm(dec2.args.slice(0, -1))) throw new Error(label + ": non-deadline argument changed"); if (BigInt(dec2.args[dec2.args.length - 1]) !== NEW_DEADLINE) throw new Error(label + ": decoded new deadline wrong"); }
  return { newData, wordOffsetBytes, oldDataKeccak: keccak256(oldData), newDataKeccak: keccak256(newData) };
}

// ---- remaining 17 signable transactions = rehearsal immediate steps 3..19 (rehearsal indices 2..18) ----
// gas ceilings per the EXPLICIT option-B authorization; policy identities are re-checked by the canonical
// builder, the strict validator, and the operator's bounded verifier.
const deadlineRefreshSteps = [];
const remainingTxs = rehearsal.immediateTransactions.slice(2).map((t, i) => {
  const gasLimit = B(t.gasLimit), maxFee = B(t.maxFeePerGas), maxPrio = B(t.maxPriorityFeePerGas);
  const reviewedCost = gasLimit * maxFee;
  if ((reviewedCost * 5n) % 4n !== 0n) throw new Error("1.25x not exact for " + t.label); // 5/4 exactness guard
  // deadline refresh applies ONLY to the three authorized steps; all other calldata copied byte-identical
  let data = t.dataOrInitCode, dataKeccak = t.dataKeccak, decodedArgs = t.decodedArgs;
  if (DEADLINE_STEPS[t.label]) {
    const r = refreshDeadline(t.label, t.dataOrInitCode);
    data = r.newData; dataKeccak = r.newDataKeccak;
    decodedArgs = { ...t.decodedArgs, deadline: NEW_DEADLINE.toString() };
    deadlineRefreshSteps.push({ originalIndex: i + 3, label: t.label, wordOffsetBytes: r.wordOffsetBytes, oldDataKeccak: r.oldDataKeccak, newDataKeccak: r.newDataKeccak });
  } else if (keccak256(t.dataOrInitCode).toLowerCase() !== t.dataKeccak.toLowerCase()) throw new Error(t.label + ": accepted calldata hash mismatch");
  return {
    originalIndex: i + 3, remainingIndex: i,
    seq: t.seq, phase: t.phase, label: t.label, signer: A(t.signer), nonce: t.nonce, txType: t.txType,
    to: t.to ? A(t.to) : null, predictedCreationAddress: t.predictedCreationAddress ? A(t.predictedCreationAddress) : null,
    value: t.value || "0", dataOrInitCode: data, dataKeccak, decodedArgs,
    chainId: 4663, gasLimit: gasLimit.toString(), maxFeePerGas: maxFee.toString(), maxPriorityFeePerGas: maxPrio.toString(),
    gasCeilings: {
      gasLimitCeiling: (gasLimit * 2n).toString(),                    // unchanged canonical ceiling (2x reviewed)
      maxFeeCeilingWei: maxFee.toString(),                            // unchanged reviewed maximum
      maxPriorityCeilingWei: PRIORITY_CEILING_WEI,                    // exactly 50,000,000 wei (authorized)
      reviewedMaxGasCostWei: reviewedCost.toString(),                 // accepted v6 reviewed value (recorded)
      maxGasCostCeilingWei: (reviewedCost * 5n / 4n).toString(),      // exactly 1.25x reviewed (authorized)
    },
  };
});
if (remainingTxs.length !== 17) throw new Error("expected 17 remaining txs, got " + remainingTxs.length);
if (!remainingTxs.every((t, i) => t.originalIndex === i + 3)) throw new Error("original index sequencing broken");
if (deadlineRefreshSteps.length !== 3 || deadlineRefreshSteps.map(d => d.originalIndex).join(",") !== "13,15,17") throw new Error("deadline refresh must cover exactly original steps 13, 15, 17");

// ---- recovery exposure: actual step-1 + step-2 gas + remaining principal + remaining MAXIMUM gas ----
// remaining max gas = 1.25x SUM(reviewed immediate cost of steps 3-19) + reviewed delayed + funding max gas
// (the delayed withdrawal + funding schedule ceilings are NOT covered by the authorization and stay at 1x).
const step1ReviewedMax = B(rehearsal.immediateTransactions[0].gasLimit) * B(rehearsal.immediateTransactions[0].maxFeePerGas);
const step2ReviewedMax = B(rehearsal.immediateTransactions[1].gasLimit) * B(rehearsal.immediateTransactions[1].maxFeePerGas);
const immediate3to19Reviewed = remainingTxs.reduce((acc, t) => acc + B(t.gasCeilings.reviewedMaxGasCostWei), 0n);
const nonImmediateReviewed = B(rehearsal.capArithmetic.allInclusiveGasWei) - step1ReviewedMax - step2ReviewedMax - immediate3to19Reviewed; // delayed + funding
if (nonImmediateReviewed < 0n) throw new Error("gas decomposition negative");
const remainingMaxGasWei = immediate3to19Reviewed * 5n / 4n + nonImmediateReviewed;
const actualStep1 = B(c1.actualGasCostWei), actualStep2 = B(c2.actualGasCostWei);
const remainingPrincipalWei = B(rehearsal.forkFunding.inbound.deployer.weth) + B(rehearsal.forkFunding.inbound.tester.weth);
const aggregateWei = actualStep1 + actualStep2 + remainingPrincipalWei + remainingMaxGasWei;
const aggregateMicroUsd = (aggregateWei * CAP_MICRO) / 10n ** 18n;
if (aggregateMicroUsd > 130_000_000n) throw new Error(`recovery exposure $${(Number(aggregateMicroUsd) / 1e6).toFixed(6)} exceeds $130 — NOT generating an executable packet`);

const remainingPredicted = {};
for (const [slot, v] of Object.entries(snap.remainingPredictedDeploymentAddresses)) remainingPredicted[slot] = A(v.address);

const meta = {
  task: "10D-6-recovery-v7", kind: "EXECUTION-ENABLED BPSC-TEST canary RECOVERY v7 packet (original steps 1+2 completed on chain; remaining 17 txs; localhost Rabby operator; per-tx user approval; NO key handling)",
  mode: "recovery", live: true, executable: true, executionAuthorized: true, fundingAuthorized: true,
  chainId: 4663, authorization: { canary: true, production: false, scope: RECOVERY_SCOPE, maxAllInclusiveExposureUsd: 130, signingChannel: "user Rabby extension via per-transaction eth_sendTransaction only", delayedWithdrawalDisabled: "tester nonce 8 withdraw NOT executable from the recovery operator" },
  deployer: A(policy.wallets.deployer), tester: A(policy.wallets.tester),
  forkBlock: String(snap.pinnedBlock.number), forkBlockHash: snap.pinnedBlock.hash, forkTimestamp: String(snap.pinnedBlock.timestamp), forkBaseFeePerGasWei: String(snap.pinnedBlock.baseFeePerGasWei),
  generatedAtUtc: new Date().toISOString(), expiresAtUtc: new Date((Number(snap.pinnedBlock.timestamp) + WINDOW) * 1000).toISOString(), validityWindowSeconds: WINDOW,
  originalStepCount: 19,
  v5ZipSha256: anchorFile.v5ZipSha256, v5ReviewedAuthorizationDigest: anchorFile.v5ReviewedAuthorizationDigest,
  v6ZipSha256: anchorFile.v6ZipSha256, v6RecoveryAuthorizationDigest: anchorFile.v6RecoveryAuthorizationDigest,
  gasPolicy: {
    perStepCostMultiplier: "1.25x reviewed maxGasCostWei (exact, steps 3-19 only)",
    maxPriorityCeilingWei: PRIORITY_CEILING_WEI,
    maxFeeCeilingUnchanged: true, gasLimitCeilingUnchanged: true,
    authorization: "TASK 10D-6 option B: user explicitly authorized raising each per-step maximum gas-cost ceiling for original steps 3-19 to exactly 1.25x its accepted v6 reviewed value, superseding the earlier prohibition; maxFeePerGas ceiling unchanged; maxPriorityFeePerGas ceiling exactly 50000000 wei; gasLimit ceiling unchanged; $130 all-inclusive cap unchanged.",
  },
  deadlineRefresh: {
    authorization: "TASK 10D-6 follow-up: user explicitly authorized refreshing ONLY the ABI-encoded deadline argument of original steps 13 (NPM.mint), 15 (buyExactWethForBps), 17 (sellExactBpsForWeth) from the expired accepted value to the canonical v7 packet expiry (pinned block timestamp + 21600 s), via strict ABI decode/re-encode with a byte-diff proof limited to the single 32-byte deadline word. All other calldata bytes and all other 14 remaining calldatas are byte-identical to the accepted versions.",
    oldDeadline: OLD_DEADLINE.toString(), newDeadline: NEW_DEADLINE.toString(),
    newDeadlineEqualsPacketExpiry: true,
    steps: deadlineRefreshSteps,
  },
  feeBounds: { maxFeePerGasWei: policy.gas.maxFeePerGasWei, maxPriorityFeePerGasWei: PRIORITY_CEILING_WEI, pinnedBaseFeePerGasWei: String(snap.pinnedBlock.baseFeePerGasWei) },
};

const recoveryPacket = {
  meta,
  safetyFlags: { broadcastReady: true, liveWritesApproved: true, executionAuthorized: true, fundingAuthorized: true },
  completedStep1: c1, completedStep2: c2,
  remaining: { count: 17, testerSwitchAfterOriginalStep: 13, note: "original steps 3-13 deployer; 14-19 tester; switch Rabby to tester after original step 13" },
  addressGuards: { poolAddress: A(rehearsal.addressGuards.poolAddress), infrastructure: rehearsal.addressGuards.infrastructure.map(A), completedTokenAddress: A(c1.createdAddress), completedVaultAddress: A(c2.createdAddress), remainingPredicted },
  deployedRuntimeCodeHashes: rehearsal.deployedRuntimeCodeHashes,
  dependencies: snap.externalCodeHashes,
  lpUsage: rehearsal.lpUsage, buyAccounting: rehearsal.buyAccounting, sellAccounting: rehearsal.sellAccounting, lockAndWithdraw: rehearsal.lockAndWithdraw,
  provenance: { repoHead: rehearsal.provenance.repoHead, dirtyTrackedTree: rehearsal.provenance.dirtyTrackedTree, contracts: rehearsal.provenance.contracts },
  capArithmetic: { capPriceMicroUsd: CAP_MICRO.toString(), actualStep1GasCostWei: actualStep1.toString(), actualStep2GasCostWei: actualStep2.toString(), remainingPrincipalWei: remainingPrincipalWei.toString(), remainingMaxGasWei: remainingMaxGasWei.toString(), immediate3to19ReviewedWei: immediate3to19Reviewed.toString(), immediate3to19CeilingWei: (immediate3to19Reviewed * 5n / 4n).toString(), nonImmediateReviewedWei: nonImmediateReviewed.toString(), aggregateWei: aggregateWei.toString(), aggregateMicroUsd: aggregateMicroUsd.toString(), aggregateUsd: (Number(aggregateMicroUsd) / 1e6).toFixed(6) },
  immediateTransactions: remainingTxs,
  delayedWithdrawalSubPacket: rehearsal.delayedWithdrawalSubPacket,
};

const signable = (t) => ({ originalIndex: t.originalIndex, chainId: 4663, signer: A(t.signer), nonce: t.nonce, type: 2, to: t.to ? A(t.to) : null, value: t.value || "0", data: t.dataOrInitCode, gasLimit: t.gasLimit, maxFeePerGas: t.maxFeePerGas, maxPriorityFeePerGas: t.maxPriorityFeePerGas });
recoveryPacket.meta.remainingExecutionDigest = keccak256(toHexUtf8(stable(remainingTxs.map(signable))));

const canon = buildRecoveryCanonical({ packet: recoveryPacket, policy, snapshot: snap, getAddress });
if (canon.errors.length) throw new Error("recovery canonical build failed: " + canon.errors.join("; "));
const recoveryAuthorizationDigest = digestOf(canon.object, keccak256);
recoveryPacket.meta.recoveryAuthorizationDigest = recoveryAuthorizationDigest;

policy.recoveryAuthorizationDigest = recoveryAuthorizationDigest;
policy.recoveryExpectedNonces = { deployer: 5, tester: 2 };
writeFileSync(U("recovery-policy.json"), JSON.stringify(policy, null, 2));
writeFileSync(U("operator/recovery-authorization.json"), JSON.stringify(canon.object, null, 2));
writeFileSync(U("recovery-packet.json"), JSON.stringify(recoveryPacket, null, 2));

console.log("remainingExecutionDigest:", recoveryPacket.meta.remainingExecutionDigest);
console.log("recoveryAuthorizationDigest:", recoveryAuthorizationDigest);
console.log("actualStep1:", actualStep1.toString(), "actualStep2:", actualStep2.toString());
console.log("remainingPrincipalWei:", remainingPrincipalWei.toString(), "remainingMaxGasWei:", remainingMaxGasWei.toString(), "(immediate3-19 reviewed", immediate3to19Reviewed.toString(), "-> ceiling", (immediate3to19Reviewed * 5n / 4n).toString(), "+ nonImmediate", nonImmediateReviewed.toString() + ")");
console.log("aggregateWei:", aggregateWei.toString(), "= $" + (Number(aggregateMicroUsd) / 1e6).toFixed(6), "(cap $130)");
console.log("deadline refresh: old", OLD_DEADLINE.toString(), "(" + new Date(Number(OLD_DEADLINE) * 1000).toISOString() + ") -> new", NEW_DEADLINE.toString(), "(" + new Date(Number(NEW_DEADLINE) * 1000).toISOString() + ")");
for (const d of deadlineRefreshSteps) console.log(`  orig ${d.originalIndex} ${d.label.padEnd(20)} word@byte ${d.wordOffsetBytes}  ${d.oldDataKeccak} -> ${d.newDataKeccak}`);
console.log("per-step ceilings (old reviewed -> new 1.25x):");
for (const t of remainingTxs) console.log(`  orig ${String(t.originalIndex).padStart(2)} ${t.label.padEnd(28)} ${t.gasCeilings.reviewedMaxGasCostWei} -> ${t.gasCeilings.maxGasCostCeilingWei}`);
