// TASK 10D-6 — v7 RECOVERY operator tests + clean-fork recovery replay.
// Forks POST original-steps-1+2 (canary token + locking vault deployed; deployer nonce 5), imports/verifies
// BOTH anchors, and executes the remaining 17 transactions (original steps 3-19) via a mock provider.
// Covers: no-rebroadcast of steps 1/2, the AUTHORIZED 1.25x per-step gas-cost policy (observed step-2
// envelope passes; exactly-1.25x boundary; above fails; priority >50,000,000 fails; maxFee/gasLimit/cost/
// exposure breaches fail), security-critical mutations, chainId + provider-chain boundaries, v7 storage
// isolation from v5/v6, uncertain-send + storage faults, restart at every remaining step, and the
// canonical-leaf + source-input mutation suites.
import { readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { createPublicClient, http, keccak256, getAddress, encodeAbiParameters, toHex } from "viem";
import { RecoveryOperator } from "./operator/recovery-core.mjs";

const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const rt = (p) => readFileSync(U(p), "utf8");
const recoveryPacket = rj("recovery-packet.json"), recoveryPolicy = rj("recovery-policy.json"), recoverySnapshot = rj("recovery-snapshot.json");
const recoveryAuthorizationRaw = rt("operator/recovery-authorization.json"), recoveryAuthorization = JSON.parse(recoveryAuthorizationRaw);
const PORT = Number(process.env.RECTEST_PORT || 8549);
const FORK = `http://127.0.0.1:${PORT}`;
const LIVE = process.env[recoveryPolicy.liveRpcEnvVar];
const R = []; const ok = (n, c, d = "") => R.push({ n, pass: !!c, d });
const B = (x) => BigInt(x);
const DEPLOYER = getAddress(recoveryPolicy.wallets.deployer), TESTER = getAddress(recoveryPolicy.wallets.tester), WETH = getAddress(recoveryPolicy.infrastructure.weth);
const capMicro = B(recoveryPacket.capArithmetic.capPriceMicroUsd);
const freshPrices = async () => ({ coinbaseMicroUsd: capMicro, krakenMicroUsd: capMicro - 100000n, coinbaseAgeS: 3, krakenAgeS: 4 });
const memStore = () => { const m = new Map(); return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => m.set(k, v), _m: m, clone() { const n = new Map(m); return { get: (k) => (n.has(k) ? n.get(k) : null), set: (k, v) => n.set(k, v), _m: n }; } }; };

let anvil;
const forkPub = createPublicClient({ transport: http(FORK) });
const forkReq = (m, p = []) => forkPub.request({ method: m, params: p });
async function waitAnvil() { for (let i = 0; i < 80; i++) { try { if (await forkReq("eth_blockNumber")) return; } catch { } await new Promise(r => setTimeout(r, 500)); } throw new Error("anvil did not start"); }
const FORBIDDEN = ["eth_sendRawTransaction", "eth_sign", "personal_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v4", "wallet_addEthereumChain", "wallet_switchEthereumChain"];

async function main() {
  if (!LIVE) throw new Error("provider RPC env var not set");
  anvil = spawn("anvil", ["--fork-url", LIVE, "--fork-block-number", String(recoverySnapshot.pinnedBlock.number), "--chain-id", "4663", "--block-base-fee-per-gas", String(recoverySnapshot.pinnedBlock.baseFeePerGasWei), "--port", String(PORT), "--silent"], { stdio: "ignore" });
  await waitAnvil();
  await forkReq("anvil_setBlockTimestampInterval", [1]);
  await forkReq("anvil_setBalance", [DEPLOYER, toHex(10n ** 18n)]); await forkReq("anvil_setBalance", [TESTER, toHex(10n ** 18n)]);
  await forkReq("anvil_impersonateAccount", [DEPLOYER]); await forkReq("anvil_impersonateAccount", [TESTER]);
  const knownBal = B(recoverySnapshot.balances.weth.deployer); let slotIdx = null;
  for (let i = 0; i < 300; i++) { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [DEPLOYER, BigInt(i)])); if (B(await forkReq("eth_getStorageAt", [WETH, slot, "latest"])) === knownBal) { slotIdx = BigInt(i); break; } }
  const setW = async (who, amt) => { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [who, slotIdx])); await forkReq("anvil_setStorageAt", [WETH, slot, toHex(amt, { size: 32 })]); };
  const lpWeth = B(recoveryPacket.lpUsage.deployerWethBefore), tradeWeth = B(recoveryPacket.buyAccounting.testerWethBefore);
  const provision = async () => { await setW(DEPLOYER, lpWeth); await setW(TESTER, tradeWeth); };
  await provision();
  let snapId = await forkReq("evm_snapshot", []);
  const resetFork = async () => { await forkReq("evm_revert", [snapId]); await provision(); snapId = await forkReq("evm_snapshot", []); };

  let selectedAccount = DEPLOYER; const calls = []; let sendCount = 0, forbiddenSeen = 0;
  const base = { isRabby: false, async request({ method, params = [] }) { calls.push(method); if (FORBIDDEN.includes(method)) { forbiddenSeen++; throw new Error("forbidden: " + method); } if (method === "eth_accounts") return [selectedAccount]; if (method === "eth_sendTransaction") { sendCount++; if (Array.isArray(params[0])) throw new Error("batch"); return forkReq("eth_sendTransaction", [params[0]]); } return forkReq(method, params); } };
  const newOp = (storage, extra = {}) => new RecoveryOperator({ recoveryPacket, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw, provider: base, keccak256, getAddress, priceProvider: freshPrices, storage, ...extra });

  // ===== A) SUCCESS: import BOTH anchors + execute remaining 17 with per-step restart =====
  await resetFork();
  const store = memStore(); const op = newOp(store);
  ok("v7 bind (canonical anchors + v5/v6 anchors + gas policy + 17 signables + both completed anchors)", op.bindAndVerifyPacket().ok);
  ok("fork resumes at original step 3 with deployer nonce 5", Number(B(await forkReq("eth_getTransactionCount", [DEPLOYER, "latest"]))) === 5 && op.steps[0].originalIndex === 3 && op.steps[0].nonce === 5);
  ok("no rebroadcast route for steps 1/2 (not in signables; no deployer nonce 3 or 4 step)", !op.completedStepIsActionable() && !op.steps.some(s => getAddress(s.signer) === DEPLOYER && (s.nonce === 3 || s.nonce === 4)));
  ok("markConnected (chain 4663)", (await op.markConnected(base)).ok);
  ok("reconcile imports+verifies BOTH completed anchors and sets current=0", (await op.reconcile(base)).ok && op.current === 0 && op.reconciled);

  let allOk = true; const restartCurrents = []; let st0Tx = null, st0Rc = null, st0Ref = null;
  for (let i = 0; i < op.steps.length; i++) {
    selectedAccount = getAddress(op.steps[i].signer);
    const pre = await op.preconditions(base); if (!pre.ok) { allOk = false; ok(`remaining ${i} (orig ${op.steps[i].originalIndex}) pre`, false, pre.reason); break; }
    const s = await op.sendCurrent(base); if (!s.ok) { allOk = false; ok(`remaining ${i} send`, false, s.reason); break; }
    if (i === 0) { st0Ref = op.steps[0]; st0Tx = await forkReq("eth_getTransactionByHash", [s.txHash]); st0Rc = await forkReq("eth_getTransactionReceipt", [s.txHash]); }
    const v = await op.verifyAfterHash(base, s.txHash); if (!v.ok) { allOk = false; ok(`remaining ${i} verify (${op.steps[i].label})`, false, v.reason); break; }
    const ob = newOp(store.clone()); ob.bindAndVerifyPacket(); await ob.markConnected(base); const r = await ob.reconcile(base);
    if (!r.ok || ob.current !== i + 1) { allOk = false; ok(`restart after remaining ${i}`, false, r.reason || `current ${ob.current}`); break; }
    restartCurrents.push(ob.current);
  }
  ok("clean-fork recovery replay: steps 1+2 imported + remaining 17/17 executed & verified", allOk && op.current === 17 && !op.halted);
  ok("successful restart reconciliation after EVERY remaining step (both anchors re-verified each time)", restartCurrents.length === 17 && restartCurrents.every((v, i) => v === i + 1));
  ok("exactly 17 single eth_sendTransaction calls; no forbidden method; no deployer nonce-3/4 send", sendCount === 17 && forbiddenSeen === 0);

  // ===== B) AUTHORIZED GAS POLICY — exact arithmetic regressions =====
  {
    // observed original step-2 Rabby envelope vs step-2's reviewed values UNDER THE v7 POLICY
    const rev = { gasLimit: 1506506n, maxFee: 200000000n };                    // accepted v6 reviewed step-2
    const ceil = { gl: rev.gasLimit * 2n, mf: rev.maxFee, mp: 50000000n, cost: rev.gasLimit * rev.maxFee * 5n / 4n };
    const obs = { gas: 1901820n, maxFee: 186000000n, maxPrio: 50000000n };     // verified on-chain step-2 envelope
    const evalEnv = (e) => e.gas <= ceil.gl && e.maxFee <= ceil.mf && e.maxPrio <= ceil.mp && e.maxPrio <= e.maxFee && e.gas * e.maxFee <= ceil.cost;
    ok("exact observed step-2 envelope (1901820/186000000/50000000) PASSES the 1.25x policy", evalEnv(obs) && obs.gas * obs.maxFee === 353738520000000n && ceil.cost === 376626500000000n);
    ok("1.25x exactly is the maximum: cost == ceiling passes; ceiling+1 wei fails", (() => { const atCeil = { gas: 1n, maxFee: ceil.cost, maxPrio: 0n }; const above = { gas: 1n, maxFee: ceil.cost + 1n, maxPrio: 0n }; return atCeil.gas * atCeil.maxFee <= ceil.cost && !(above.gas * above.maxFee <= ceil.cost); })());
    ok("priority 50,000,000 passes; 50,000,001 FAILS", evalEnv({ ...obs, maxPrio: 50000000n }) && !evalEnv({ ...obs, maxPrio: 50000001n }));
    ok("maxFee above reviewed ceiling FAILS", !evalEnv({ ...obs, maxFee: ceil.mf + 1n, maxPrio: 0n }));
    ok("gasLimit above 2x ceiling FAILS", !evalEnv({ ...obs, gas: ceil.gl + 1n }));
    ok("cost above 1.25x reviewed FAILS (e.g. observed gasLimit at full 200 gwei maxFee)", !evalEnv({ gas: 1901820n, maxFee: 200000000n, maxPrio: 0n }));
  }

  // ===== B2) DEADLINE REFRESH — independent byte-diff proof against the ACCEPTED rehearsal calldata =====
  {
    const rehearsal = rj("canary-unsigned-packet.json");
    const dr = recoveryPacket.meta.deadlineRefresh;
    const expEpoch = Math.floor(Date.parse(recoveryPacket.meta.expiresAtUtc) / 1000);
    ok("new deadline == pinned ts + 21600 == packet expiry; old deadline == 1784916327", dr.oldDeadline === "1784916327" && BigInt(dr.newDeadline) === B(recoverySnapshot.pinnedBlock.timestamp) + 21600n && Number(dr.newDeadline) === expEpoch);
    let diffOk = true, identOk = true, decOk = true; const details = [];
    for (const t of recoveryPacket.immediateTransactions) {
      const src = rehearsal.immediateTransactions.find(r => r.nonce === t.nonce && getAddress(r.signer) === getAddress(t.signer));
      const step = dr.steps.find(x => x.originalIndex === t.originalIndex);
      if (!step) { if (t.dataOrInitCode.toLowerCase() !== src.dataOrInitCode.toLowerCase()) { identOk = false; details.push("changed:" + t.label); } continue; }
      const a = src.dataOrInitCode, b = t.dataOrInitCode;
      if (a.length !== b.length || a.slice(0, 10).toLowerCase() !== b.slice(0, 10).toLowerCase()) { diffOk = false; details.push("len/sel:" + t.label); continue; }
      const diffs = []; for (let i = 2; i < a.length; i += 2) if (a.slice(i, i + 2).toLowerCase() !== b.slice(i, i + 2).toLowerCase()) diffs.push((i - 2) / 2);
      if (!diffs.every(bo => bo >= step.wordOffsetBytes && bo < step.wordOffsetBytes + 32) || diffs.length === 0) { diffOk = false; details.push("outside-word:" + t.label); }
      const oldW = BigInt("0x" + a.slice(2 + step.wordOffsetBytes * 2, 2 + step.wordOffsetBytes * 2 + 64));
      const newW = BigInt("0x" + b.slice(2 + step.wordOffsetBytes * 2, 2 + step.wordOffsetBytes * 2 + 64));
      if (oldW.toString() !== dr.oldDeadline || newW.toString() !== dr.newDeadline) decOk = false;
      if (keccak256(a).toLowerCase() !== step.oldDataKeccak.toLowerCase() || keccak256(b).toLowerCase() !== step.newDataKeccak.toLowerCase()) decOk = false;
    }
    ok("byte-diff proof: only the single 32-byte deadline word differs in steps 13/15/17", diffOk, details.join(","));
    ok("the other 14 remaining calldatas are byte-identical to the accepted versions", identOk, details.join(","));
    ok("old/new deadline words + old/new dataKeccak all match the recorded refresh metadata", decOk);
  }
  // B3) runtime deadline gates: a provider whose block timestamp reaches expiry/deadline must halt precheck
  { await resetFork(); const o = newOp(memStore()); o.bindAndVerifyPacket(); await o.markConnected(base); await o.reconcile(base); selectedAccount = getAddress(o.steps[0].signer);
    const lateTs = toHex(BigInt(Math.floor(Date.parse(recoveryPacket.meta.expiresAtUtc) / 1000)) + 1n);
    const late = { request: async ({ method, params }) => { if (method === "eth_getBlockByNumber") { const h = await base.request({ method, params }); return { ...h, timestamp: lateTs }; } return base.request({ method, params }); } };
    const r = await o.preconditions(late);
    ok("provider block timestamp at/after packet expiry HALTS the pre-check (runtime deadline gate)", !r.ok && o.halted && /strictly before the packet expiry/.test(o.haltReason)); }

  // ===== C) bounded verifier adversarial on the captured real remaining-step-0 tx (orig step 3) =====
  const gop = op, st0 = st0Ref, txHash0 = st0Rc.transactionHash;
  const canned = (txOverride, chainId = "0x1237") => ({ request: async ({ method }) => { if (method === "eth_chainId") return chainId; if (method === "eth_getTransactionByHash") return { ...st0Tx, ...txOverride }; if (method === "eth_getTransactionReceipt") return st0Rc; return null; } });
  const g = st0.gasCeilings;
  const vt = async (over, chainId) => (await gop._verifyTxAndReceipt(canned(over, chainId), st0, txHash0)).ok;
  ok("honest returned tx verifies (orig step 3)", await vt({}));
  ok("verifier: Rabby-adjusted gas WITHIN 1.25x ceiling verifies", await vt({ gas: toHex(B(st0.gasLimit) * 5n / 4n), maxFeePerGas: toHex(B(st0.maxFeePerGas)) }));
  ok("verifier: cost above the 1.25x ceiling FAILS", !(await vt({ gas: toHex(B(g.maxGasCostCeilingWei) / B(st0.maxFeePerGas) + 2n) })));
  ok("verifier: maxFee above reviewed ceiling FAILS", !(await vt({ maxFeePerGas: toHex(B(g.maxFeeCeilingWei) + 1n) })));
  ok("verifier: priority above 50,000,000 FAILS", !(await vt({ maxPriorityFeePerGas: toHex(50000001n) })));
  ok("verifier: priority exactly 50,000,000 passes", await vt({ maxPriorityFeePerGas: toHex(50000000n) }));
  ok("verifier: gasLimit above 2x ceiling FAILS", !(await vt({ gas: toHex(B(g.gasLimitCeiling) + 1n) })));
  ok("critical field: wrong sender FAILS", !(await vt({ from: TESTER })));
  ok("critical field: wrong nonce FAILS", !(await vt({ nonce: "0x63" })));
  ok("critical field: wrong value FAILS", !(await vt({ value: "0x1" })));
  ok("critical field: wrong calldata FAILS", !(await vt({ input: "0xdeadbeef" })));
  ok("critical field: wrong type (legacy) FAILS", !(await vt({ type: "0x0" })));
  ok("critical field: non-empty access list FAILS", !(await vt({ accessList: [{ address: WETH, storageKeys: [] }] })));
  ok("chainId ABSENT in response accepted (eth_chainId==4663 independently)", await (async () => { const p = { request: async ({ method }) => { if (method === "eth_chainId") return "0x1237"; if (method === "eth_getTransactionByHash") { const { chainId, ...noc } = st0Tx; return noc; } if (method === "eth_getTransactionReceipt") return st0Rc; return null; } }; return (await gop._verifyTxAndReceipt(p, st0, txHash0)).ok; })());
  ok("chainId PRESENT and wrong (1) FAILS", !(await vt({ chainId: "0x1" })));
  ok("provider chain != 4663 at verify boundary FAILS", !(await vt({}, "0x1")));

  // ===== D) exposure: actual steps 1+2 + remaining; above-$130 fails closed =====
  {
    const ca = recoveryPacket.capArithmetic;
    const agg = B(ca.actualStep1GasCostWei) + B(ca.actualStep2GasCostWei) + B(ca.remainingPrincipalWei) + B(ca.remainingMaxGasWei);
    const micro = (agg * capMicro) / 10n ** 18n;
    ok("recovery exposure = actual s1+s2 gas + remaining principal + remaining max gas (1.25x immediate) <= $130", agg === B(ca.aggregateWei) && micro <= 130_000_000n);
    // a price high enough to push the aggregate over $130 must fail the fresh-exposure gate
    const oHigh = newOp(memStore(), { priceProvider: async () => ({ coinbaseMicroUsd: 2100000000n, krakenMicroUsd: 2100000000n, coinbaseAgeS: 1, krakenAgeS: 1 }) });
    oHigh.bindAndVerifyPacket();
    const gate = await oHigh._exposureGate();
    ok("aggregate exposure above $130 at fresh prices FAILS the exposure gate", gate.ok === false && (agg * 2100000000n) / 10n ** 18n > 130_000_000n);
  }

  // ===== E) v7 isolation: v5 AND v6 records never read as authority nor mutated =====
  {
    const st = memStore();
    st.set("canary:halt:0xv5digest", JSON.stringify({ reason: "V5 HALT — MUST BE UNTOUCHED" }));
    st.set("canaryv6:halt:" + recoveryPacket.meta.v6RecoveryAuthorizationDigest, JSON.stringify({ reason: "V6 HALT — MUST BE UNTOUCHED" }));
    const o = newOp(st); o.bindAndVerifyPacket();
    ok("v7 uses canaryv7 namespace; v5 + v6 halt records untouched and not authoritative", o._kHalt.startsWith("canaryv7:") && !o.halted && st.get("canary:halt:0xv5digest").includes("MUST BE UNTOUCHED") && st.get("canaryv6:halt:" + recoveryPacket.meta.v6RecoveryAuthorizationDigest).includes("MUST BE UNTOUCHED"));
  }

  // ===== F) uncertain-send + storage faults (fail-closed; no blind retry) =====
  const faultStore = (fail) => { const m = new Map(); return { get: (k) => (m.has(k) ? m.get(k) : null), set: (k, v) => { if (fail(k, v)) throw new Error("storage fault"); m.set(k, v); }, _m: m }; };
  const kJournal = "canaryv7:journal:" + recoveryPacket.meta.recoveryAuthorizationDigest;
  { await resetFork(); const st = faultStore((k) => k === kJournal); const o = newOp(st); o.bindAndVerifyPacket(); await o.markConnected(base); await o.reconcile(base); selectedAccount = getAddress(o.steps[0].signer);
    const errWrap = { request: async ({ method, params }) => { if (method === "eth_sendTransaction") throw new Error("network glitch"); return base.request({ method, params }); } };
    await o.sendCurrent(errWrap);
    const realHash = await base.request({ method: "eth_sendTransaction", params: [{ from: getAddress(o.steps[0].signer), value: "0x0", data: o.steps[0].dataOrInitCode, gas: toHex(B(o.steps[0].gasLimit)), maxFeePerGas: toHex(B(o.steps[0].maxFeePerGas)), maxPriorityFeePerGas: toHex(B(o.steps[0].maxPriorityFeePerGas)), type: "0x2", nonce: toHex(B(o.steps[0].nonce)), chainId: "0x1237" }] });
    const res = await o.resolveUncertainSend(base, realHash);
    ok("resolveUncertainSend with failing journal write stays HALTED (no blind retry)", !res.ok && o.halted && !!o.uncertainSend && o.current === 0);
  }
  { await resetFork(); const s0 = sendCount; const o = newOp(faultStore((k) => k.startsWith("canaryv7:intent:"))); o.bindAndVerifyPacket(); await o.markConnected(base); await o.reconcile(base); selectedAccount = getAddress(o.steps[0].signer);
    const r = await o.sendCurrent(base);
    ok("storage-unavailable-before-send: wallet NOT invoked", !r.ok && /storage unavailable/.test(r.reason) && sendCount === s0);
  }
  { const st = memStore(); st.set("canaryv7:intent:" + recoveryPacket.meta.recoveryAuthorizationDigest, JSON.stringify({ digest: recoveryPacket.meta.recoveryAuthorizationDigest, step: 0, signer: DEPLOYER, nonce: 5, signableTxHash: "0x" + "a".repeat(64) })); const o = newOp(st);
    ok("crash-between-intent-and-response: reload HALTED uncertain (no new send for that nonce)", o.halted && !!o.uncertainSend && o.uncertainSend.step === 0);
  }

  // ===== G) canonical-leaf mutation suite =====
  const { buildRecoveryCanonical } = await import("./operator/recovery-canonical.mjs");
  const { digestOf } = await import("./operator/canonical.mjs");
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const bindWith = (P, PO, S, PKG, RAW) => { try { const o = new RecoveryOperator({ recoveryPacket: P, recoveryPolicy: PO, recoverySnapshot: S, recoveryAuthorization: PKG, recoveryAuthorizationRaw: RAW ?? JSON.stringify(PKG), provider: base, keccak256, getAddress, priceProvider: freshPrices, storage: memStore() }); return { ok: o.bindAndVerifyPacket().ok, o }; } catch { return { ok: false, o: null }; } };
  const leafPaths = [];
  (function walk(o, p) { if (o && typeof o === "object") { for (const k of Object.keys(o)) walk(o[k], p.concat(k)); } else leafPaths.push(p); })(recoveryAuthorization, []);
  const getAt = (o, p) => p.reduce((x, k) => x[k], o);
  const setAt = (o, p, v) => { const par = p.slice(0, -1).reduce((x, k) => x[k], o); par[p[p.length - 1]] = v; };
  const mutVal = (v) => { if (typeof v === "boolean") return !v; if (typeof v === "number") return v + 1; if (typeof v === "string") { if (/^0x[0-9a-fA-F]{40}$/.test(v)) return "0x000000000000000000000000000000000000dEaD"; if (/^0x[0-9a-fA-F]+$/.test(v)) return v.slice(0, -1) + (v.slice(-1) === "0" ? "1" : "0"); if (/^[0-9]+$/.test(v)) return (BigInt(v) + 1n).toString(); return v + "_MUT"; } return "MUT"; };
  let leafFails = [], leafTested = 0;
  for (const p of leafPaths) { const PKG = clone(recoveryAuthorization); setAt(PKG, p, mutVal(getAt(PKG, p))); leafTested++; if (bindWith(recoveryPacket, recoveryPolicy, recoverySnapshot, PKG).ok) leafFails.push(p.join(".")); }
  globalThis.__recoveryLeafCount = leafTested;
  ok(`GENERIC leaf-mutation: all ${leafTested} canonical v7 leaves fail binding when mutated`, leafFails.length === 0, leafFails.slice(0, 8).join(" | "));

  // ===== H) source-input mutation completeness =====
  const baseDigest = digestOf(buildRecoveryCanonical({ packet: recoveryPacket, policy: recoveryPolicy, snapshot: recoverySnapshot, getAddress }).object, keccak256);
  const digestAfter = (P, PO, S) => { try { const r = buildRecoveryCanonical({ packet: P, policy: PO, snapshot: S, getAddress }); return r.errors.length ? "ERR" : digestOf(r.object, keccak256); } catch { return "THROW"; } };
  let srcChanged = 0, srcUnused = 0;
  for (const [name, obj] of [["packet", recoveryPacket], ["policy", recoveryPolicy], ["snapshot", recoverySnapshot]]) {
    const paths = []; (function w(x, p) { if (x && typeof x === "object") { for (const k of Object.keys(x)) w(x[k], p.concat(k)); } else paths.push(p); })(obj, []);
    for (const p of paths) {
      const P = clone(recoveryPacket), PO = clone(recoveryPolicy), S = clone(recoverySnapshot);
      const target = name === "packet" ? P : name === "policy" ? PO : S;
      setAt(target, p, mutVal(getAt(target, p)));
      if (digestAfter(P, PO, S) !== baseDigest) srcChanged++; else srcUnused++;
    }
  }
  { const o = bindWith(recoveryPacket, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw).o;
    ok(`SOURCE-INPUT mutation: ${srcChanged} leaves shift the digest; ${srcUnused} unused (raw inputs null after bind)`, srcChanged > 0 && o.recoveryPacket === null && o.recoveryPolicy === null && o.recoverySnapshot === null); }
  globalThis.__recoverySrcChanged = srcChanged; globalThis.__recoverySrcUnused = srcUnused;

  // key v7 regressions
  const srcFail = (fn) => { const P = clone(recoveryPacket), PO = clone(recoveryPolicy), S = clone(recoverySnapshot); fn(P, PO, S); return !bindWith(P, PO, S, recoveryAuthorization, recoveryAuthorizationRaw).ok; };
  const reg = {
    "anchor1-txHash": srcFail((P) => P.completedStep1.txHash = "0x" + "1".repeat(64)),
    "anchor2-txHash": srcFail((P) => P.completedStep2.txHash = "0x" + "1".repeat(64)),
    "anchor2-createdAddress": srcFail((P) => P.completedStep2.createdAddress = "0x000000000000000000000000000000000000dEaD"),
    "anchor2-actualGasCost": srcFail((P) => { P.completedStep2.actualGasCostWei = "1"; P.capArithmetic.actualStep2GasCostWei = "1"; }),
    "cost-ceiling-above-1.25x": srcFail((P) => P.immediateTransactions[0].gasCeilings.maxGasCostCeilingWei = (B(P.immediateTransactions[0].gasCeilings.maxGasCostCeilingWei) + 1n).toString()),
    "cost-ceiling-below-1.25x": srcFail((P) => P.immediateTransactions[0].gasCeilings.maxGasCostCeilingWei = P.immediateTransactions[0].gasCeilings.reviewedMaxGasCostWei),
    "priority-ceiling-changed": srcFail((P) => { P.immediateTransactions[0].gasCeilings.maxPriorityCeilingWei = "60000000"; }),
    "maxFee-ceiling-raised": srcFail((P) => { P.immediateTransactions[0].gasCeilings.maxFeeCeilingWei = "210000000"; }),
    "v6-anchor-tamper": srcFail((P) => P.meta.v6RecoveryAuthorizationDigest = "0x" + "2".repeat(64)),
    "deployer-nonce-expectation": srcFail((P, PO, S) => S.expectedNonces.deployer = 6),
    "aggregate-exposure": srcFail((P) => P.capArithmetic.aggregateWei = "1"),
    "step1-injected-into-signables": (() => { const P = clone(recoveryPacket); P.immediateTransactions[0].originalIndex = 1; P.immediateTransactions[0].nonce = 3; return !bindWith(P, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw).ok; })(),
    "step2-injected-into-signables": (() => { const P = clone(recoveryPacket); P.immediateTransactions[0].originalIndex = 2; P.immediateTransactions[0].nonce = 4; return !bindWith(P, recoveryPolicy, recoverySnapshot, recoveryAuthorization, recoveryAuthorizationRaw).ok; })(),
  };
  const regBad = Object.entries(reg).filter(([, v]) => !v).map(([k]) => k);
  ok(`v7 regressions: anchors/gas-policy identities/v6-anchor/nonce/exposure/step-injection all FAIL binding (${Object.keys(reg).length} tested)`, regBad.length === 0, regBad.join(","));

  console.log("[recovery-test] canonical v7 leaves mutation-tested:", globalThis.__recoveryLeafCount, "| source-input changed:", srcChanged, "unused:", srcUnused);
  console.log("[recovery-test] histogram:", Object.entries(calls.reduce((a, m) => (a[m] = (a[m] || 0) + 1, a), {})).map(([k, v]) => `${k}:${v}`).join(" "));
  for (const r of R) console.log(` [${r.pass ? "PASS" : "FAIL"}] ${r.n}${r.d ? "  (" + r.d + ")" : ""}`);
  const passed = R.filter(r => r.pass).length;
  console.log(`\n[recovery-test] ${passed}/${R.length} checks passed`);
  return R.every(r => r.pass);
}
let code = 1;
try { code = (await main()) ? 0 : 1; } catch (e) { console.error("[recovery-test] ERROR:", e.message, e.stack?.split("\n").slice(1, 3).join(" | ")); code = 1; }
finally { if (anvil) try { anvil.kill("SIGKILL"); } catch { } }
process.exit(code);
