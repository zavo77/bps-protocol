// TASK 10D-6 — independently verify BOTH completed transactions (original steps 1 and 2) + capture the
// fresh live recovery state for the remaining 17 transactions (original steps 3-19). Read-only; RPC from
// env only (never printed/written). Writes recovery-anchor.json + recovery-snapshot.json. Fails closed.
import { readFileSync, writeFileSync } from "node:fs";
import { createPublicClient, http, keccak256, getContractAddress, getAddress, toHex } from "viem";

const U = (p) => new URL(p, import.meta.url);
const policy = JSON.parse(readFileSync(U("review-policy.json"), "utf8"));
const packet = JSON.parse(readFileSync(U("canary-unsigned-packet.json"), "utf8"));
const ENV = policy.liveRpcEnvVar || "ROBINHOOD_CHAIN_RPC_URL";
const RPC = process.env[ENV];
if (!RPC) { console.error(`FAIL: ${ENV} not set`); process.exit(1); }
const c = createPublicClient({ transport: http(RPC) });
const rpc = (m, p = []) => c.request({ method: m, params: p });
const B = (x) => BigInt(x);
const A = (x) => getAddress(x);

const DEPLOYER = A(policy.wallets.deployer), TESTER = A(policy.wallets.tester);
const IN = policy.infrastructure;
const ANCHOR1 = "0x36acf3e3752e0cfc2688c280680c4a9a100e3fcb2520bf41ae723f1a05612e2c"; // step 1: BPSCanaryToken (nonce 3)
const ANCHOR2 = "0x4569523ae523090ee7b19644380b4cecb33d34d19db1cd2f52c677a724a2d758"; // step 2: BPSLockingVault (nonce 4)
const V5_ZIP_SHA = "5a6246ca51bd3237e6d925153439d9040b1c3674c0e026e9d8f187e7a5e64b3b";
const V5_REVIEWED_AUTH_DIGEST = "0x4fdfd36b99d6090fef67f21bd3b2027e8dc7e339861ae94eb0f292da2b6ee248";
const V6_ZIP_SHA = "fd57f5c1bcc4d296250bfb04cab096a4f56299b0deb2edefbf4824f9414fb356";
const V6_RECOVERY_AUTH_DIGEST = "0xdca841943bc32b76df5a04310d30b70a4a9244dcc4d9445d8d42500fe01ecf57";

const fails = [];
const need = (cond, msg) => { if (!cond) fails.push(msg); return !!cond; };
const hexUtf8 = (s) => { let h = "0x"; for (let i = 0; i < s.length; i++) { const cc = s.charCodeAt(i); h += (cc < 16 ? "0" : "") + cc.toString(16); } return h; };
const view = async (to, sig) => rpc("eth_call", [{ to, data: keccak256(hexUtf8(sig)).slice(0, 10) }, "latest"]);
const decUint = (r) => B(r);
const decBool = (r) => B(r) === 1n;
const decAddr = (r) => A("0x" + r.slice(-40));
const decStr = (r) => { const len = Number(B("0x" + r.slice(66, 130))); const hex = r.slice(130, 130 + len * 2); const bytes = new Uint8Array(len); for (let i = 0; i < len; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16); return new TextDecoder("utf-8").decode(bytes); };

// verify ONE completed contract-creation anchor exactly (shared for steps 1 and 2)
async function verifyAnchor(label, txHash, expNonce, rehearsalStep, expRuntimeHash) {
  const predicted = A(getContractAddress({ from: DEPLOYER, nonce: BigInt(expNonce) }));
  const tx = await rpc("eth_getTransactionByHash", [txHash]);
  const rc = await rpc("eth_getTransactionReceipt", [txHash]);
  need(!!tx && !!rc, label + ": anchor tx/receipt not found");
  if (!tx || !rc) return null;
  need(rc.transactionHash.toLowerCase() === txHash.toLowerCase(), label + ": receipt hash != anchor");
  need(B(rc.status) === 1n, label + ": receipt not success");
  if (tx.chainId !== undefined && tx.chainId !== null) need(Number(B(tx.chainId)) === 4663, label + ": tx-response chainId != 4663");
  need(A(tx.from) === DEPLOYER, label + ": sender != deployer");
  need(Number(B(tx.nonce)) === expNonce, label + ": nonce != " + expNonce);
  need(tx.to === null || tx.to === undefined, label + ": not a contract creation");
  need(B(tx.value) === 0n, label + ": value != 0");
  need(Number(B(tx.type)) === 2, label + ": not EIP-1559 type-2");
  need(tx.input.toLowerCase() === rehearsalStep.dataOrInitCode.toLowerCase(), label + ": input != canonical calldata");
  need(keccak256(tx.input).toLowerCase() === rehearsalStep.dataKeccak.toLowerCase(), label + ": input keccak != canonical");
  need(A(rc.contractAddress) === predicted, label + ": created address != predicted");
  const code = await rpc("eth_getCode", [rc.contractAddress, "latest"]);
  const runtimeHash = keccak256(code), codeSize = (code.length - 2) / 2;
  need(runtimeHash.toLowerCase() === expRuntimeHash.toLowerCase(), label + ": deployed runtime hash != accepted artifact");
  const gasUsed = B(rc.gasUsed), effPrice = B(rc.effectiveGasPrice);
  need(gasUsed > 0n && effPrice > 0n && gasUsed <= B(tx.gas), label + ": receipt gas accounting inconsistent");
  return {
    txHash, from: DEPLOYER, nonce: expNonce, type: 2, to: null, value: "0",
    inputKeccak: rehearsalStep.dataKeccak, createdAddress: A(rc.contractAddress),
    blockNumber: B(rc.blockNumber).toString(), blockHash: rc.blockHash,
    gasLimit: B(tx.gas).toString(), maxFeePerGas: B(tx.maxFeePerGas).toString(), maxPriorityFeePerGas: B(tx.maxPriorityFeePerGas).toString(),
    gasUsed: gasUsed.toString(), effectiveGasPriceWei: effPrice.toString(), actualGasCostWei: (gasUsed * effPrice).toString(),
    deployedRuntimeCodeHash: runtimeHash, deployedCodeSize: codeSize,
    chainIdInResponse: (tx.chainId === undefined || tx.chainId === null) ? "absent" : Number(B(tx.chainId)),
    logs: rc.logs.length,
  };
}

async function main() {
  const chainId = Number(B(await rpc("eth_chainId")));
  need(chainId === 4663, `provider chainId ${chainId} != 4663`);

  // ---- (1) step 1: BPSCanaryToken at deployer nonce 3 ----
  const a1 = await verifyAnchor("step1", ANCHOR1, 3, packet.immediateTransactions[0], packet.deployedRuntimeCodeHashes.canaryToken);
  if (a1) {
    const MAX_SUPPLY = 1000000000n * 10n ** 18n;
    const [name, symbol, decimals, supply, isCanary] = await Promise.all([
      view(a1.createdAddress, "name()").then(decStr), view(a1.createdAddress, "symbol()").then(decStr),
      view(a1.createdAddress, "decimals()").then(decUint), view(a1.createdAddress, "totalSupply()").then(decUint),
      view(a1.createdAddress, "IS_CANARY()").then(decBool),
    ]);
    need(name === "BPS Canary — TEST ONLY" && symbol === "BPSC-TEST" && decimals === 18n && supply === MAX_SUPPLY && isCanary === true, "step1: constructor state (name/symbol/decimals/supply/IS_CANARY)");
    need(a1.logs === 1, "step1: expected exactly one construction log");
    a1.token = { name, symbol, decimals: 18, totalSupply: supply.toString(), isCanary: true, maxSupply: MAX_SUPPLY.toString() };
  }

  // ---- (1) step 2: BPSLockingVault at deployer nonce 4 ----
  const a2 = await verifyAnchor("step2", ANCHOR2, 4, packet.immediateTransactions[1], packet.deployedRuntimeCodeHashes.lockingVault);
  if (a2) {
    const owner = await view(a2.createdAddress, "owner()").then(decAddr);
    const bps = await view(a2.createdAddress, "bpsToken()").then(decAddr);
    need(owner === DEPLOYER, "step2: owner() != deployer");
    need(a1 && bps === a1.createdAddress, "step2: bpsToken() != canary token");
    need(a2.logs === 1, "step2: expected exactly one construction log (OwnershipTransferred)");
    const rc2 = await rpc("eth_getTransactionReceipt", [ANCHOR2]);
    const lg = rc2.logs[0];
    const ovs = keccak256(hexUtf8("OwnershipTransferred(address,address)")).toLowerCase();
    need(lg.topics[0].toLowerCase() === ovs && B(lg.topics[1]) === 0n && A("0x" + lg.topics[2].slice(26)) === DEPLOYER && A(lg.address) === a2.createdAddress, "step2: OwnershipTransferred(0x0 -> deployer) log mismatch");
    a2.vault = { owner: DEPLOYER, bpsToken: a1 ? a1.createdAddress : null };
  }

  // ---- live recovery snapshot for the remaining 17 (original steps 3-19) ----
  const dLatest = Number(B(await rpc("eth_getTransactionCount", [DEPLOYER, "latest"])));
  const dPending = Number(B(await rpc("eth_getTransactionCount", [DEPLOYER, "pending"])));
  const tLatest = Number(B(await rpc("eth_getTransactionCount", [TESTER, "latest"])));
  const tPending = Number(B(await rpc("eth_getTransactionCount", [TESTER, "pending"])));
  need(dLatest === 5 && dPending === 5, `deployer nonce ${dLatest}/${dPending} != 5/5`);
  need(tLatest === 2 && tPending === 2, `tester nonce ${tLatest}/${tPending} != 2/2`);

  const head = B(await rpc("eth_blockNumber"));
  const pinned = head - 3n;
  const blk = await rpc("eth_getBlockByNumber", [toHex(pinned), false]);

  // completed contracts hold exactly the expected code; the remaining SIX predicted (nonces 5..10) are empty
  const completed = {};
  for (const [slot, anc] of [["canaryToken", a1], ["lockingVault", a2]]) { const code = await rpc("eth_getCode", [anc.createdAddress, "latest"]); need(keccak256(code).toLowerCase() === anc.deployedRuntimeCodeHash.toLowerCase(), slot + ": completed code changed"); completed[slot] = { address: anc.createdAddress, runtimeCodeHash: anc.deployedRuntimeCodeHash }; }
  const remainingSlots = ["claimManager", "rialtoAdapter", "coordinator", "stockVault", "uniswapAdapter", "tradeRouter"];
  const remainingEmpty = {};
  remainingSlots.forEach((s, i) => remainingEmpty[s] = { address: A(getContractAddress({ from: DEPLOYER, nonce: BigInt(5 + i) })) });
  for (const [s, v] of Object.entries(remainingEmpty)) { const cc = await rpc("eth_getCode", [v.address, "latest"]); v.empty = cc === "0x" || cc === "0x0"; need(v.empty, `remaining predicted ${s} is not empty`); }

  const deps = {};
  for (const [k, addr] of Object.entries({ weth: IN.weth, uniswapV3Factory: IN.uniswapV3Factory, nonfungiblePositionManager: IN.nonfungiblePositionManager, swapRouter02: IN.swapRouter02, rialtoRegistry: IN.rialtoRegistry, nvdaStockToken: IN.nvdaStockToken })) {
    const code = await rpc("eth_getCode", [addr, "latest"]); deps[k] = { address: A(addr), runtimeCodeHash: keccak256(code), codeBytes: (code.length - 2) / 2 };
  }
  const balSel = (who) => keccak256(hexUtf8("balanceOf(address)")).slice(0, 10) + who.slice(2).toLowerCase().padStart(64, "0");
  const ethBal = { deployer: (await rpc("eth_getBalance", [DEPLOYER, "latest"]).then(B)).toString(), tester: (await rpc("eth_getBalance", [TESTER, "latest"]).then(B)).toString() };
  const wethBal = { deployer: (await rpc("eth_call", [{ to: IN.weth, data: balSel(DEPLOYER) }, "latest"]).then(B)).toString(), tester: (await rpc("eth_call", [{ to: IN.weth, data: balSel(TESTER) }, "latest"]).then(B)).toString() };

  if (fails.length) { console.error("RECOVERY CAPTURE FAILED:\n - " + fails.join("\n - ")); process.exit(1); }

  writeFileSync(U("recovery-anchor.json"), JSON.stringify({ v5ZipSha256: V5_ZIP_SHA, v5ReviewedAuthorizationDigest: V5_REVIEWED_AUTH_DIGEST, v6ZipSha256: V6_ZIP_SHA, v6RecoveryAuthorizationDigest: V6_RECOVERY_AUTH_DIGEST, completedStep1: a1, completedStep2: a2 }, null, 2));
  writeFileSync(U("recovery-snapshot.json"), JSON.stringify({
    kind: "fresh live recovery snapshot (post original steps 1+2); URL read from env, never recorded",
    capturedAtUtc: new Date().toISOString(), chainId: Number(chainId), head: head.toString(),
    pinnedBlock: { number: pinned.toString(), hash: blk.hash, parentHash: blk.parentHash, timestamp: B(blk.timestamp).toString(), baseFeePerGasWei: B(blk.baseFeePerGas).toString(), gasLimit: B(blk.gasLimit).toString() },
    wallets: { deployer: DEPLOYER, tester: TESTER },
    nonces: { deployer: dLatest, tester: tLatest }, pendingNonces: { deployer: dPending, tester: tPending },
    expectedNonces: { deployer: 5, tester: 2 },
    completedContracts: completed,
    remainingPredictedDeploymentAddresses: remainingEmpty, allRemainingPredictedEmpty: Object.values(remainingEmpty).every(x => x.empty),
    externalCodeHashes: deps, balances: { eth: ethBal, weth: wethBal },
  }, null, 2));
  console.log("recovery capture OK (v7 — both anchors verified)");
  console.log("  step1:", ANCHOR1, "block", a1.blockNumber, "created", a1.createdAddress, "actualGas", a1.actualGasCostWei);
  console.log("  step2:", ANCHOR2, "block", a2.blockNumber, "created", a2.createdAddress, "actualGas", a2.actualGasCostWei);
  console.log("  live nonces deployer", dLatest + "/" + dPending, "tester", tLatest + "/" + tPending, "| pinned", pinned.toString(), "baseFee", B(blk.baseFeePerGas).toString());
  console.log("  remaining 6 predicted all empty:", Object.values(remainingEmpty).every(x => x.empty));
}
main().catch(e => { console.error("RECOVERY CAPTURE ERROR:", e.message); process.exit(1); });
