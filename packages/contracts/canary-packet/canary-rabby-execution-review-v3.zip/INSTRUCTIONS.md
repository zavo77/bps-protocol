# Canary Rabby Execution Operator — BPSC-TEST (Task 10D)

**BPSC-TEST — CANARY — NOT PRODUCTION.** Robinhood Chain mainnet, chainId **4663 (0x1237)**.
Authorization scope: *BPSC-TEST canary only; Robinhood Chain mainnet; maximum all-inclusive exposure $130;
individual Rabby approvals; canonical BPS production excluded.*

This bundle contains an **execution-enabled** unsigned packet and a **localhost-only** operator that lets you
approve each transaction, one at a time, in your **Rabby** extension. The operator **never** sees a key, seed,
or keystore, **never** builds a signer, and **never** broadcasts on its own — it hands one `eth_sendTransaction`
to Rabby only after you click, and Rabby does the signing.

## Requirements
- Node.js ≥ 20; `anvil` (Foundry) for the replay/operator steps.
- `node_modules` is **excluded** from this ZIP. Install the exact pinned dependencies from the lockfile:
  `npm ci --ignore-scripts`.
- Provider RPC supplied **only** via the environment variable (never printed/stored):
  `export ROBINHOOD_CHAIN_RPC_URL="<your provider HTTPS endpoint>"`
- A browser with the **Rabby** extension installed and your deployer/tester accounts imported (by you, in Rabby).

## One-command re-verification

This is an **execution-enabled** BPSC-TEST canary packet (not a historical fixture). Re-verify everything
with the documented one command:

```bash
npm ci --ignore-scripts
node verify-all.mjs
```

`verify-all.mjs` runs and requires all of: compilation **7/7**, offline verifier **55/55**, manifest
integrity **5/5**, static safety scan **5/5**, clean-fork replay **19/19**, and the operator engine test
**19/19** — the operator success path (all 19 txs on a fork via a mock provider, with per-step restart
reconciliation) **plus** the fail-closed / durable-halt / forged-storage / uncertain-send / binding-mutation
and gate adversarial tests. It never touches Rabby or mainnet.

## Execution (per-transaction, in your Rabby)

1. **Immediately before execution, run the 8-gate mainnet preflight** (read-only):
   ```bash
   node preflight-check.mjs
   ```
   If any gate fails — expiry, nonce drift off deployer 3 / tester 2, insufficient balances, changed
   dependency code, an occupied predicted address, base fee out of bounds, exposure > $130 — **STOP** and
   regenerate. Do not execute a stale packet.
3. **Start the localhost operator** (bound to 127.0.0.1 only) and open it in the Rabby browser:
   ```bash
   node operator/serve.mjs          # http://127.0.0.1:8737/
   ```
4. In the page: **Connect Rabby** (approves a connection only — no signing). The operator then **reconciles**
   its journal against chain and only THEN enables controls. It stays fully disabled (fail-closed) until the
   `bound → connected → reconciled` states are all true. Ensure Rabby is on **Robinhood Chain 4663 / 0x1237**
   and the **exact packet signer** is selected — the operator will not add or switch networks; switch manually
   and it fails closed if wrong.
5. For **each** transaction, in packet order:
   - Click **(1) Run pre-transaction checks** — re-verifies chain, account, **both latest and pending nonce**,
     prior receipts, dependency hashes, next predicted CREATE address empty, base fee, balances, a no-revert
     simulation, gas estimate ≤ packet limit, a **fresh Coinbase+Kraken (no-cache) exposure** ≤ $130, and non-expiry.
   - Click **(2) Confirm this transaction**, then **(3) Open Rabby approval** — Rabby prompts you to sign **one**
     transaction. Approve it in Rabby.
   - The operator persists a pending record on the returned hash, then a **shared verifier** compares every
     field (incl. chainId with no default, empty access list, no blob fields) and the receipt, verifies a
     receipt-event postcondition and a cumulative current-state checkpoint, journals the step, and advances.
   - Any mismatch/revert/timeout **halts permanently** — no automatic retry. If the wallet errors **after** the
     send was invoked, the operator records a **durable uncertain-send halt** (survives reload); resolve it only
     by supplying the real tx hash for exact reconciliation, or regenerate under review. Restart is always safe:
     on reload the operator re-validates every journalled tx + receipt and a cumulative checkpoint before enabling.

## What is NOT executable here
The **delayed tester withdrawal (nonce 8)** is intentionally **disabled** in this operator. It requires a
separately regenerated packet and a fresh preflight after the lock's unlock time.

## Safety properties (verified in this bundle)
- Signing occurs only in Rabby, per transaction, after your explicit click. No key/seed/keystore is ever
  requested or handled. No `eth_sendRawTransaction`, no local signer, no session keys / AA, no batching, no
  automatic sends, no automatic retries (all enforced structurally and checked by `static-scan.mjs`).
- The operator only issues a fixed read set plus one `eth_sendTransaction` per step (proven by
  `operator-test.mjs`, which drives all 19 txs on a fork with a mock provider and never touches Rabby or
  mainnet).
- The provider RPC URL is read from the environment only and never printed, serialized, or stored.
