// TASK 10D-2 — browser wiring (fail-closed). Signing happens ONLY inside Rabby via per-transaction
// eth_sendTransaction after an explicit click. No key/seed/keystore/raw signature; no eth_sendRawTransaction.
// Controls stay disabled until bound -> connected -> reconciled. Durable halt/uncertain-send survives reload.
import { CanaryOperator } from "./operator-core.mjs";
import { keccak256, getAddress } from "./vendor/eth.js";

const $ = (id) => document.getElementById(id);
const say = (m, cls) => { const el = $("log"); const d = document.createElement("div"); if (cls) d.className = cls; d.textContent = m; el.prepend(d); };
let op = null, provider = null;
const loadJson = async (p) => { const r = await fetch(p, { cache: "no-store" }); if (!r.ok) throw new Error("load " + p); return r.json(); };
const storage = { get: (k) => localStorage.getItem(k), set: (k, v) => localStorage.setItem(k, v) };
const toMicro = (dec) => { const [i, f = ""] = String(dec).split("."); return BigInt(i) * 1_000_000n + BigInt((f + "000000").slice(0, 6)); };

// (6) fresh Coinbase + Kraken with cache disabled; validate + fail closed on timeout/malformed
async function priceProvider() {
  const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error("price timeout")), ms))]);
  const t0 = Date.now();
  const [cb, kr] = await withTimeout(Promise.all([
    fetch("https://api.coinbase.com/v2/prices/ETH-USD/spot", { cache: "no-store" }).then(r => { if (!r.ok) throw new Error("coinbase " + r.status); return r.json(); }),
    fetch("https://api.kraken.com/0/public/Ticker?pair=ETHUSD", { cache: "no-store" }).then(r => { if (!r.ok) throw new Error("kraken " + r.status); return r.json(); }),
  ]), 8000);
  const cbAmt = cb && cb.data && cb.data.amount, krAmt = kr && kr.result && Object.values(kr.result)[0] && Object.values(kr.result)[0].c && Object.values(kr.result)[0].c[0];
  if (!/^\d+(\.\d+)?$/.test(String(cbAmt)) || !/^\d+(\.\d+)?$/.test(String(krAmt))) throw new Error("malformed price data");
  const age = (Date.now() - t0) / 1000;
  return { coinbaseMicroUsd: toMicro(cbAmt), krakenMicroUsd: toMicro(krAmt), coinbaseAgeS: age, krakenAgeS: age };
}

function detectRabby() {
  const eth = window.ethereum; if (!eth) return { ok: false, reason: "No injected EVM provider. Install/enable Rabby." };
  const list = eth.providers && Array.isArray(eth.providers) ? eth.providers : [eth];
  const rabbys = list.filter(p => p && p.isRabby);
  if (rabbys.length === 0) return { ok: false, reason: "Rabby not detected; this operator requires Rabby." };
  if (rabbys.length > 1) return { ok: false, reason: "Ambiguous: multiple Rabby providers. Aborting (fail closed)." };
  return { ok: true, provider: rabbys[0] };
}

async function init() {
  const [packet, policy, snapshot] = await Promise.all([loadJson("./canary-unsigned-packet.json"), loadJson("./review-policy.json"), loadJson("./block-snapshot.json")]);
  op = new CanaryOperator({ packet, policy, snapshot, provider: null, keccak256, getAddress, priceProvider, storage });
  $("scope").textContent = packet.meta.authorization.scope; $("digest").textContent = packet.meta.executionPacketDigest; $("expiry").textContent = packet.meta.expiresAtUtc;
  const bind = op.bindAndVerifyPacket();
  if (!bind.ok) { say("REFUSED: packet binding failed — " + op.haltReason, "fail"); $("connect").disabled = true; return; }
  if (op.halted) { say("DURABLE HALT from a prior session: " + op.haltReason + (op.uncertainSend ? " (uncertain send at step " + op.uncertainSend.step + "; supply the tx hash to resolve or regenerate under review)" : ""), "fail"); $("connect").disabled = true; renderHalted(); return; }
  say("Packet bound: executionPacketDigest recomputed + full policy/snapshot/authorization binding verified.", "ok");
  const det = detectRabby(); if (!det.ok) { say("BLOCKED: " + det.reason, "fail"); $("connect").disabled = true; return; }
  provider = det.provider; op.provider = provider;
  say("Rabby detected. Click Connect, then the operator will reconcile before enabling any transaction.");
}

async function connect() {
  try {
    await provider.request({ method: "eth_requestAccounts" }); // connection only; no signing
    const mc = await op.markConnected(provider);
    if (!mc.ok) { say("Connect blocked: " + mc.reason, "fail"); return; }
    const r = await op.reconcile(provider);
    if (!r.ok) { say("Reconciliation FAILED — " + (r.reason || op.haltReason) + ". Controls remain disabled.", "fail"); renderHalted(); return; }
    if (r.pendingUnresolved) { say("A pending transaction is not yet on chain; sends stay disabled until it confirms + verifies.", "warn"); render(); return; }
    say("Connected + reconciled. Resumed at step " + (op.current + 1) + " of " + op.steps.length + ".", "ok");
    render();
  } catch (e) { say("connect error: " + e.message, "fail"); }
}

function renderHalted() { $("panel").innerHTML = `<div class="fail">HALTED: ${op.haltReason || "reconciliation required"}. No automatic retry. Regenerate + re-review to proceed.</div>`; }

function render() {
  if (!(op.bound && op.connected && op.reconciled) || op.halted) { renderHalted(); return; }
  const i = op.current, done = i >= op.steps.length;
  $("progress").textContent = `Step ${Math.min(i + 1, op.steps.length)} / ${op.steps.length}` + (done ? " — COMPLETE" : "") + (op.pending ? " — PENDING (sends disabled)" : "");
  if (done) { $("panel").innerHTML = `<div class="ok">All ${op.steps.length} immediate steps executed and verified. The delayed tester-nonce-8 withdrawal is NOT executable here.</div>`; return; }
  if (op.pending) { $("panel").innerHTML = `<div class="warn">Transaction pending (${op.pending.txHash}). Verify it before continuing; additional sends disabled.</div><div class="actions"><button id="resume">Verify pending transaction</button></div>`; $("resume").onclick = () => doVerify(op.pending.txHash); return; }
  const t = op.steps[i], hash = keccak256(t.dataOrInitCode);
  $("panel").innerHTML = `
    <table>
      <tr><th>step</th><td>${i + 1} of ${op.steps.length} (${t.phase} — ${t.label})</td></tr>
      <tr><th>signer</th><td>${getAddress(t.signer)}</td></tr>
      <tr><th>nonce</th><td>${t.nonce}</td></tr>
      <tr><th>target</th><td>${t.to ? getAddress(t.to) : "CREATE → " + t.predictedCreationAddress}</td></tr>
      <tr><th>value / type / chainId</th><td>${t.value} wei / 0x2 / 4663</td></tr>
      <tr><th>gas limit</th><td>${t.gasLimit}</td></tr>
      <tr><th>max fee / priority</th><td>${t.maxFeePerGas} / ${t.maxPriorityFeePerGas} wei</td></tr>
      <tr><th>method</th><td>${t.label}</td></tr>
      <tr><th>calldata/init-code keccak</th><td class="mono">${hash}</td></tr>
      <tr><th>expected result</th><td>${t.reconciliation || t.phase}</td></tr>
    </table>
    <div class="actions">
      <button id="precheck">1) Run pre-transaction checks (fresh live-price exposure; latest+pending nonce)</button>
      <button id="confirm" disabled>2) Confirm this transaction</button>
      <button id="send" disabled>3) Open Rabby approval for THIS transaction</button>
    </div>`;
  $("precheck").onclick = doPrecheck;
}

let precheckPassed = false;
async function doPrecheck() {
  precheckPassed = false; $("confirm").disabled = true; $("send").disabled = true;
  const r = await op.preconditions(provider);
  if (!r.ok) { say("PRE-CHECK FAILED: " + (r.reason || op.haltReason) + " — HALTED.", "fail"); renderHalted(); return; }
  say("Pre-checks PASSED: " + Object.keys(r.gates).join(", ") + (r.exposure ? ` | exposure $${(Number(r.exposure.exposureMicro) / 1e6).toFixed(6)} @ higher live price` : ""), "ok");
  precheckPassed = true; const c = $("confirm"); c.disabled = false;
  c.onclick = () => { if (precheckPassed) { $("send").disabled = false; say("Confirmed. Click (3) to open the Rabby approval for THIS single transaction."); } };
}
async function doSend() {
  if (!precheckPassed) return; $("send").disabled = true;
  const r = await op.sendCurrent(provider);
  if (r.userRejected) { say("You rejected the transaction in Rabby. Same step; no state changed.", "warn"); precheckPassed = false; render(); return; }
  if (r.uncertainSend) { say("UNCERTAIN SEND: the wallet errored after the request was invoked. Halted durably; supply the tx hash to resolve or regenerate under review. No blind retry.", "fail"); renderHalted(); return; }
  if (!r.ok) { say("SEND blocked/halted: " + (r.reason || op.haltReason), "fail"); render(); return; }
  say("Rabby returned tx hash " + r.txHash + " (pending persisted) — verifying…"); render(); await doVerify(r.txHash);
}
async function doVerify(txHash) {
  const v = await op.verifyAfterHash(provider, txHash);
  if (!v.ok) { say("POST-VERIFY failed: " + (v.reason || op.haltReason) + " — HALTED.", "fail"); renderHalted(); return; }
  say("Step " + (v.step + 1) + " verified (shared field/receipt verifier + event postcondition + cumulative checkpoint). Journalled.", "ok");
  precheckPassed = false; render();
}
document.addEventListener("click", (e) => { if (e.target && e.target.id === "send") doSend(); });
$("connect").onclick = connect;
init().catch(e => say("init error: " + e.message, "fail"));
