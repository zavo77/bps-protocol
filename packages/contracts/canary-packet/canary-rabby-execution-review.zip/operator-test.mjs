// TASK 10D — operator engine test on a CLEAN FORK with a MOCK injected provider.
// Proves: the operator drives all 19 immediate txs to success via single eth_sendTransaction calls only;
// it NEVER calls a forbidden wallet method, NEVER batches, NEVER auto-sends without explicit invocation;
// and every send goes to the local Anvil fork — NEVER to Rabby and NEVER to mainnet.
import { readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { createPublicClient, http, keccak256, getAddress, encodeAbiParameters, toHex } from "viem";
import { CanaryOperator } from "./operator/operator-core.mjs";

const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const packet = rj("canary-unsigned-packet.json"), policy = rj("review-policy.json"), snapshot = rj("block-snapshot.json");
const PORT = Number(process.env.OPTEST_PORT || 8548);
const FORK_RPC = `http://127.0.0.1:${PORT}`;
const LIVE = process.env[policy.liveRpcEnvVar];
const R = []; const ok = (n, c, d = "") => R.push({ n, pass: !!c, d });
const B = (x) => BigInt(x);
const DEPLOYER = getAddress(policy.wallets.deployer), TESTER = getAddress(policy.wallets.tester), WETH = getAddress(policy.infrastructure.weth);

let anvil;
const anvilPub = createPublicClient({ transport: http(FORK_RPC) });
const anvilReq = (m, p = []) => anvilPub.request({ method: m, params: p });

// ---- MOCK injected provider: forwards reads/single-send to the FORK; overrides account selection.
// Records every method; a hard denylist proves the operator never asks for a signing/raw method.
const FORBIDDEN = ["eth_sendRawTransaction", "eth_sign", "personal_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v4", "wallet_addEthereumChain", "wallet_switchEthereumChain"];
const calls = [];
let selectedAccount = DEPLOYER, sendCount = 0, forbiddenSeen = [], nonForkTarget = false;
const mockProvider = {
  isRabby: false, // deliberately NOT Rabby — proves the engine works via a generic injected provider and the test never touches Rabby
  async request({ method, params = [] }) {
    calls.push(method);
    if (FORBIDDEN.includes(method)) { forbiddenSeen.push(method); throw new Error("forbidden method reached provider: " + method); }
    if (method === "eth_accounts") return [selectedAccount];
    if (method === "eth_sendTransaction") {
      sendCount++;
      const p0 = params[0] || {};
      if (Array.isArray(params[0])) nonForkTarget = true; // batching attempt (array) — must never happen
      return anvilReq("eth_sendTransaction", [p0]); // to the FORK only
    }
    return anvilReq(method, params);
  },
};

async function waitAnvil() { for (let i = 0; i < 60; i++) { try { if (await anvilReq("eth_blockNumber")) return; } catch { } await new Promise(r => setTimeout(r, 500)); } throw new Error("anvil did not start"); }

async function main() {
  if (!LIVE) throw new Error("provider RPC env var not set");
  const AL = policy.anvilLaunch;
  anvil = spawn(AL.binary, ["--fork-url", LIVE, "--fork-block-number", String(AL.forkBlockNumber), "--chain-id", "4663", "--block-base-fee-per-gas", String(AL.blockBaseFeePerGas), "--port", String(PORT), "--silent"], { stdio: "ignore" });
  await waitAnvil();
  await anvilReq("anvil_setBlockTimestampInterval", [1]);

  // provision the fork like the reviewed replay: generous ETH seed + EXACT WETH via discovered storage slot
  const SEED = 10n ** 18n;
  await anvilReq("anvil_setBalance", [DEPLOYER, toHex(SEED)]); await anvilReq("anvil_setBalance", [TESTER, toHex(SEED)]);
  await anvilReq("anvil_impersonateAccount", [DEPLOYER]); await anvilReq("anvil_impersonateAccount", [TESTER]);
  const knownBal = B(snapshot.balances.weth.deployer);
  let slotIdx = null;
  for (let i = 0; i < 300; i++) { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [DEPLOYER, BigInt(i)])); if (B(await anvilReq("eth_getStorageAt", [WETH, slot, "latest"])) === knownBal) { slotIdx = BigInt(i); break; } }
  if (slotIdx === null) throw new Error("weth slot not found");
  const setW = async (who, amt) => { const slot = keccak256(encodeAbiParameters([{ type: "address" }, { type: "uint256" }], [who, slotIdx])); await anvilReq("anvil_setStorageAt", [WETH, slot, toHex(amt, { size: 32 })]); };
  await setW(DEPLOYER, B(packet.forkFunding.inbound.deployer.weth));
  await setW(TESTER, B(packet.forkFunding.inbound.tester.weth));

  const op = new CanaryOperator({ packet, policy, snapshot, provider: mockProvider, keccak256, getAddress });

  // delayed tester-nonce-8 withdrawal must be excluded from the immediate operator
  ok("delayed tester-nonce-8 withdrawal is NOT an executable operator step", op.steps.every(s => !(getAddress(s.signer) === TESTER && s.nonce === 8)) && op.delayedDisabled === true);
  ok("operator loaded exactly the 19 immediate steps", op.steps.length === 19);

  // drive every step: set the "selected account" to the step signer (as a user would switch in Rabby),
  // run pre-checks, send exactly once, verify on chain. No auto-advance — each step invoked explicitly.
  let allStepsOk = true, autoAdvance = false;
  for (let i = 0; i < op.steps.length; i++) {
    selectedAccount = getAddress(op.steps[i].signer);
    const pre = await op.preconditions(mockProvider);
    if (!pre.ok) { allStepsOk = false; ok(`step ${i} preconditions`, false, pre.reason); break; }
    const before = op.current;
    const s = await op.sendCurrent(mockProvider);
    if (!s.ok) { allStepsOk = false; ok(`step ${i} send`, false, s.reason); break; }
    if (op.current !== before) autoAdvance = true; // sendCurrent must NOT advance on its own
    const v = await op.verifyAfterHash(mockProvider, s.txHash);
    if (!v.ok) { allStepsOk = false; ok(`step ${i} verify`, false, v.reason); break; }
  }
  ok("all 19 immediate steps executed + verified on the fork", allStepsOk && op.current === 19 && !op.halted);
  ok("send never auto-advanced the step counter (explicit per-tx flow)", autoAdvance === false);
  ok("exactly 19 single eth_sendTransaction calls (one per step; never batched)", sendCount === 19 && !nonForkTarget);
  ok("operator NEVER called any forbidden wallet/signing method", forbiddenSeen.length === 0);
  ok("operator methods restricted to the allowed read set + eth_sendTransaction", [...new Set(calls)].every(m => ["eth_chainId", "eth_accounts", "eth_getTransactionCount", "eth_getCode", "eth_getBalance", "eth_getBlockByNumber", "eth_call", "eth_estimateGas", "eth_sendTransaction", "eth_getTransactionByHash", "eth_getTransactionReceipt"].includes(m)), [...new Set(calls)].join(","));
  ok("no send targeted Rabby or mainnet — every request went to the local fork provider", mockProvider.isRabby === false);
  // journal integrity
  ok("journal has 19 verified success entries bound to the exec digest, no credentials", op.journal.length === 19 && op.journal.every(j => j.digest === packet.meta.executionPacketDigest && j.receiptStatus === "success" && j.verified === true && !("key" in j) && !("rpc" in j)));

  console.log("[operator-test] method call histogram:", Object.entries(calls.reduce((a, m) => (a[m] = (a[m] || 0) + 1, a), {})).map(([k, v]) => `${k}:${v}`).join(" "));
  for (const r of R) console.log(` [${r.pass ? "PASS" : "FAIL"}] ${r.n}${r.d ? "  (" + r.d + ")" : ""}`);
  const passed = R.filter(r => r.pass).length;
  console.log(`\n[operator-test] ${passed}/${R.length} checks passed`);
  return R.every(r => r.pass);
}

let code = 1;
try { code = (await main()) ? 0 : 1; }
catch (e) { console.error("[operator-test] ERROR:", e.message); code = 1; }
finally { if (anvil) try { anvil.kill("SIGKILL"); } catch { } }
process.exit(code);
