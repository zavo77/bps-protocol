// TASK 10D — browser wiring for the canary EXECUTION operator.
// Signing happens ONLY inside Rabby via per-transaction eth_sendTransaction after an explicit click.
// This file never touches a key/seed/keystore/raw signature and never calls eth_sendRawTransaction.
import { CanaryOperator } from "./operator-core.mjs";
import { keccak256, getAddress } from "./vendor/eth.js";

const $ = (id) => document.getElementById(id);
const say = (m, cls) => { const el = $("log"); const d = document.createElement("div"); if (cls) d.className = cls; d.textContent = m; el.prepend(d); };
let op = null, provider = null;

async function loadJson(p) { const r = await fetch(p); if (!r.ok) throw new Error("load " + p); return r.json(); }

// Rabby detection through the injected EVM provider; fail if unavailable or ambiguous.
function detectRabby() {
  const eth = window.ethereum;
  if (!eth) return { ok: false, reason: "No injected EVM provider found. Install/enable Rabby." };
  const list = eth.providers && Array.isArray(eth.providers) ? eth.providers : [eth];
  const rabbys = list.filter(p => p && p.isRabby);
  if (rabbys.length === 0) return { ok: false, reason: "Rabby not detected. This operator requires Rabby specifically." };
  if (rabbys.length > 1) return { ok: false, reason: "Ambiguous: multiple Rabby providers detected. Aborting (fail closed)." };
  const others = list.filter(p => p && !p.isRabby);
  if (others.length > 0) say("Note: other wallet providers are present; using the Rabby provider only.", "warn");
  return { ok: true, provider: rabbys[0] };
}

async function init() {
  const [packet, policy, snapshot] = await Promise.all([
    loadJson("./canary-unsigned-packet.json"), loadJson("./review-policy.json"), loadJson("./block-snapshot.json"),
  ]);
  // Hard refusal to run against a non-canary / production / non-4663 packet.
  if (!(packet.meta.authorization && packet.meta.authorization.canary === true && packet.meta.authorization.production === false && packet.meta.chainId === 4663)) {
    document.body.innerHTML = "<h1>REFUSED: packet is not a chain-4663 canary/non-production execution packet.</h1>"; return;
  }
  $("scope").textContent = packet.meta.authorization.scope;
  $("digest").textContent = packet.meta.executionPacketDigest;
  $("expiry").textContent = packet.meta.expiresAtUtc;

  const det = detectRabby();
  if (!det.ok) { say("BLOCKED: " + det.reason, "fail"); $("connect").disabled = true; return; }
  provider = det.provider;

  op = new CanaryOperator({ packet, policy, snapshot, provider, keccak256, getAddress });
  // restore journal from localStorage (per exec digest) and reconcile on connect
  try { const saved = JSON.parse(localStorage.getItem("canary-journal:" + op.execDigest) || "[]"); op.journal = saved; } catch { }
  say("Rabby detected. Packet loaded (" + op.steps.length + " immediate steps; delayed nonce-8 withdrawal is DISABLED).");
  render();
}

async function connect() {
  try {
    // request accounts (does NOT sign anything); user approves the connection in Rabby
    await provider.request({ method: "eth_requestAccounts" });
    const chainId = await provider.request({ method: "eth_chainId" });
    if (BigInt(chainId) !== 4663n) {
      say("WRONG NETWORK. Switch Rabby to Robinhood Chain (chainId 4663 / 0x1237) MANUALLY. This operator will not add or switch networks for you.", "fail");
      return;
    }
    if (op.journal.length) { const r = await op.reconcile(provider); say("Reconciled journal: resumed at step " + (r.resumedAt ?? "?")); }
    render();
  } catch (e) { say("connect error: " + e.message, "fail"); }
}

function render() {
  const i = op.current;
  const done = i >= op.steps.length;
  $("progress").textContent = `Step ${Math.min(i + 1, op.steps.length)} / ${op.steps.length}` + (done ? " — COMPLETE" : "");
  if (op.halted) { $("panel").innerHTML = `<div class="fail">HALTED PERMANENTLY: ${op.haltReason}. No automatic retry. Regenerate + re-review to proceed.</div>`; return; }
  if (done) { $("panel").innerHTML = `<div class="ok">All ${op.steps.length} immediate steps executed and verified. The delayed tester-nonce-8 withdrawal is NOT executable here — it needs a freshly regenerated packet + preflight after unlock.</div>`; return; }
  const t = op.steps[i];
  const hash = keccak256(t.dataOrInitCode);
  const exposure = (Number(op._worstCaseExposureMicro(i)) / 1e6).toFixed(6);
  $("panel").innerHTML = `
    <table>
      <tr><th>step</th><td>${i + 1} of ${op.steps.length} (${t.phase} — ${t.label})</td></tr>
      <tr><th>signer</th><td>${getAddress(t.signer)}</td></tr>
      <tr><th>nonce</th><td>${t.nonce}</td></tr>
      <tr><th>target</th><td>${t.to ? getAddress(t.to) : "CREATE → " + t.predictedCreationAddress}</td></tr>
      <tr><th>value</th><td>${t.value} wei</td></tr>
      <tr><th>type</th><td>0x2 (EIP-1559)</td></tr>
      <tr><th>gas limit</th><td>${t.gasLimit}</td></tr>
      <tr><th>max fee / priority</th><td>${t.maxFeePerGas} / ${t.maxPriorityFeePerGas} wei</td></tr>
      <tr><th>method</th><td>${t.label}</td></tr>
      <tr><th>calldata/init-code keccak</th><td class="mono">${hash}</td></tr>
      <tr><th>expected result</th><td>${t.reconciliation || t.phase}</td></tr>
      <tr><th>cumulative max exposure</th><td>$${exposure} (cap $130)</td></tr>
    </table>
    <div class="actions">
      <button id="precheck">1) Run pre-transaction checks</button>
      <button id="confirm" disabled>2) Confirm this transaction</button>
      <button id="send" disabled>3) Open Rabby approval for THIS transaction</button>
    </div>`;
  $("precheck").onclick = doPrecheck;
}

let precheckPassed = false;
async function doPrecheck() {
  precheckPassed = false; $("confirm").disabled = true; $("send").disabled = true;
  const r = await op.preconditions(provider);
  if (!r.ok) { say("PRE-CHECK FAILED: " + (r.reason || "gate failure") + " — HALTED.", "fail"); render(); return; }
  say("Pre-checks PASSED: " + Object.keys(r.gates).join(", "), "ok");
  precheckPassed = true;
  const c = $("confirm"); c.disabled = false;
  c.onclick = () => { if (!precheckPassed) return; $("send").disabled = false; say("Transaction confirmed by operator. Click (3) to open the Rabby approval for THIS single transaction."); };
}

async function doSend() {
  if (!precheckPassed) return;
  $("send").disabled = true;
  try {
    const r = await op.sendCurrent(provider); // single eth_sendTransaction; Rabby prompts the user
    if (!r.ok) { say("SEND blocked/halted: " + (r.reason || ""), "fail"); render(); return; }
    say("Rabby returned tx hash " + r.txHash + " — verifying on chain…");
    const v = await op.verifyAfterHash(provider, r.txHash);
    if (!v.ok) { say("POST-VERIFY failed: " + (v.reason || "") + " — HALTED.", "fail"); render(); return; }
    localStorage.setItem("canary-journal:" + op.execDigest, JSON.stringify(op.journal));
    say("Step " + (v.step + 1) + " verified (receipt success + postcondition). ", "ok");
    render();
  } catch (e) { say("send/verify error: " + e.message, "fail"); render(); }
}

document.addEventListener("click", (e) => { if (e.target && e.target.id === "send") doSend(); });
$("connect").onclick = connect;
init().catch(e => say("init error: " + e.message, "fail"));
