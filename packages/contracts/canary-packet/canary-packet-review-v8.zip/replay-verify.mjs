// TASK 10B-8 independent REPLAY verifier — starts its OWN clean Anvil fork, replays the recorded
// unsigned sequence, and compares observed receipts/events/deployed-code/state/owners/balances
// directly from replay state. Trusts NO packet boolean/accounting/receiptStatus.
import { readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { createPublicClient, http, keccak256, toHex, getAddress, getContractAddress, encodeFunctionData, decodeEventLog } from "viem";
const U = (p) => new URL(p, import.meta.url);
const rj = (p) => JSON.parse(readFileSync(U(p), "utf8"));
const a = rj("canary-unsigned-packet.json"), policy = rj("review-policy.json");
const artOf = (n) => rj(`artifacts/${n}.json`);
const R = []; const ok = (n, c, d = "") => R.push({ n, pass: !!c, d });
const B = (x) => BigInt(x); const lc = (x) => (x || "").toLowerCase();

const AL = policy.anvilLaunch;
const PORT = Number(process.env.REPLAY_PORT || 8547);
const RPC = `http://127.0.0.1:${PORT}`;
const DEPLOYER = policy.wallets.deployer, TESTER = policy.wallets.tester;
const WETH = policy.infrastructure.weth, WHALE = "0xC0Be1cb0f674D9737C72B2A63fC542361185b807";
const imm = a.immediateTransactions, dl = a.delayedWithdrawalSubPacket;
const names = ["BPSCanaryToken", "BPSLockingVault", "DistributionClaimManager", "RialtoStockAcquisitionAdapter", "DistributionFundingCoordinator", "StockAcquisitionVault", "UniswapV3BPSSwapAdapter", "BPSTradeRouter"];
const slots = ["canaryToken", "lockingVault", "claimManager", "rialtoAdapter", "coordinator", "stockVault", "uniswapAdapter", "tradeRouter"];
const P = {}; for (let i = 0; i < 8; i++) P[slots[i]] = getAddress(getContractAddress({ from: DEPLOYER, nonce: BigInt(i) }));

const erc20 = [{ type: "function", name: "balanceOf", stateMutability: "view", inputs: [{ type: "address" }], outputs: [{ type: "uint256" }] }, { type: "function", name: "transfer", stateMutability: "nonpayable", inputs: [{ type: "address" }, { type: "uint256" }], outputs: [{ type: "bool" }] }, { type: "function", name: "symbol", stateMutability: "view", inputs: [], outputs: [{ type: "string" }] }];
let pub, anvil;
const rpc = (m, p = []) => pub.request({ method: m, params: p });
const bal = (t, w) => pub.readContract({ address: t, abi: erc20, functionName: "balanceOf", args: [w] }).then(B);
const ethBal = (w) => rpc("eth_getBalance", [w, "latest"]).then(B);

function maskImmutables(codeHex, immRefs) {
  const bytes = Buffer.from(codeHex.slice(2), "hex");
  for (const id of Object.keys(immRefs || {})) for (const r of immRefs[id]) bytes.fill(0, r.start, r.start + r.length);
  return "0x" + bytes.toString("hex");
}

async function waitAnvil() {
  for (let i = 0; i < 60; i++) { try { const bn = await pub.request({ method: "eth_blockNumber" }); if (bn) return; } catch { } await new Promise(r => setTimeout(r, 500)); }
  throw new Error("anvil did not start");
}

async function main() {
  anvil = spawn(AL.binary, ["--fork-url", AL.forkUrl, "--fork-block-number", String(AL.forkBlockNumber), "--chain-id", String(AL.chainId), "--block-base-fee-per-gas", String(AL.blockBaseFeePerGas), "--port", String(PORT), "--silent"], { stdio: "ignore" });
  pub = createPublicClient({ transport: http(RPC) });
  await waitAnvil();
  const live = createPublicClient({ transport: http(policy.liveRpc) });

  // ---- snapshot validation on the freshly started fork (latest == pinned) ----
  const latest = await rpc("eth_getBlockByNumber", ["latest", false]);
  ok("replay fork LATEST == pinned block/hash/timestamp/baseFee", B(latest.number) === B(policy.snapshot.forkBlock) && lc(latest.hash) === lc(policy.snapshot.forkHash) && B(latest.timestamp) === B(policy.snapshot.forkTimestamp) && B(latest.baseFeePerGas) === B(policy.snapshot.baseFeePerGasWei));
  const liveBlk = await live.request({ method: "eth_getBlockByNumber", params: [toHex(policy.snapshot.forkBlock), false] });
  ok("live-RPC hash of pinned block == fork latest hash", lc(liveBlk.hash) === lc(latest.hash));
  ok("replay fork nonces 0/0 (deployer/tester)", Number(await rpc("eth_getTransactionCount", [DEPLOYER, "latest"])) === 0 && Number(await rpc("eth_getTransactionCount", [TESTER, "latest"])) === 0);
  await rpc("anvil_setBlockTimestampInterval", [1]); // deterministic timestamps (matches generator)

  // ---- provision identically (generous ETH seed, EXACT WETH via whale) ----
  const SEED = 10n ** 18n;
  await rpc("anvil_setBalance", [DEPLOYER, toHex(SEED)]); await rpc("anvil_setBalance", [TESTER, toHex(SEED)]); await rpc("anvil_setBalance", [WHALE, toHex(SEED)]);
  await rpc("anvil_impersonateAccount", [DEPLOYER]); await rpc("anvil_impersonateAccount", [TESTER]); await rpc("anvil_impersonateAccount", [WHALE]);
  const lpWeth = B(a.forkFunding.inbound.deployer.weth), trWeth = B(a.forkFunding.inbound.tester.weth);
  for (const [to, amt] of [[DEPLOYER, lpWeth], [TESTER, trWeth]]) { const h = await rpc("eth_sendTransaction", [{ from: WHALE, to: WETH, data: encodeFunctionData({ abi: erc20, functionName: "transfer", args: [to, amt] }) }]); await pub.waitForTransactionReceipt({ hash: h }); }
  const startEth = { d: await ethBal(DEPLOYER), t: await ethBal(TESTER) };
  ok("replay starting balances match packet (WETH exact, ETH seed)", (await bal(WETH, DEPLOYER)) === lpWeth && (await bal(WETH, TESTER)) === trWeth && startEth.d === B(a.forkFunding.startingBalances.deployer.eth) && startEth.t === B(a.forkFunding.startingBalances.tester.eth));

  // ---- replay every recorded immediate tx by its EXACT calldata; compare observed vs recorded ----
  const canary = P.canaryToken, vault = P.stockVault, router = P.tradeRouter, locking = P.lockingVault;
  const routerAbi = artOf("BPSTradeRouter").abi, lockAbi = artOf("BPSLockingVault").abi;
  let gasOk = true, deployOk = true, codeOk = true; const evByLabel = {}; let postMintPool = null;
  const poolAbi0 = [{ type: "function", name: "slot0", stateMutability: "view", inputs: [], outputs: [{ type: "uint160" }, { type: "int24" }, { type: "uint16" }, { type: "uint16" }, { type: "uint16" }, { type: "uint8" }, { type: "bool" }] }, { type: "function", name: "liquidity", stateMutability: "view", inputs: [], outputs: [{ type: "uint128" }] }];
  const gap = [];
  const PIN = toHex(B(policy.snapshot.baseFeePerGasWei));
  for (const t of imm) {
    await rpc("anvil_setNextBlockBaseFeePerGas", [PIN]); // constant base fee -> deterministic effPrice (matches generator)
    const txReq = { from: t.signer, gas: toHex(B(t.gasLimit)), maxFeePerGas: toHex(B(t.maxFeePerGas)), maxPriorityFeePerGas: toHex(B(t.maxPriorityFeePerGas)) };
    if (t.to) txReq.to = t.to; txReq.data = t.dataOrInitCode; txReq.value = "0x0";
    const hash = await rpc("eth_sendTransaction", [txReq]);
    const rc = await pub.waitForTransactionReceipt({ hash });
    if (rc.status !== "success") { gasOk = false; gap.push(t.label + ":revert"); }
    if (B(rc.gasUsed) !== B(t.gasUsed)) { gasOk = false; gap.push(`${t.label}:gasUsed ${rc.gasUsed}!=${t.gasUsed}`); }
    if (B(rc.effectiveGasPrice) !== B(t.effectiveGasPrice)) { gasOk = false; gap.push(t.label + ":effPrice"); }
    if (t.phase === "A-deploy") {
      if (getAddress(rc.contractAddress) !== getAddress(t.predictedCreationAddress)) deployOk = false;
      const onchain = await pub.getCode({ address: rc.contractAddress });
      const tmpl = artOf(t.label).deployedBytecode;
      if (maskImmutables(onchain, tmpl.immutableReferences) !== maskImmutables(tmpl.object, tmpl.immutableReferences)) { codeOk = false; gap.push(t.label + ":code"); }
    }
    evByLabel[t.label] = rc.logs;
    if (t.label === "NPM.mint") { // capture pool state right AFTER mint (before trades move the price)
      const s0 = await pub.readContract({ address: a.addressGuards.poolAddress, abi: poolAbi0, functionName: "slot0" });
      const lq = await pub.readContract({ address: a.addressGuards.poolAddress, abi: poolAbi0, functionName: "liquidity" });
      postMintPool = { sqrt: B(s0[0]), tick: Number(s0[1]), liq: B(lq) };
    }
  }
  ok("replay: every immediate tx receipt=success & gasUsed & effGasPrice EXACTLY match recorded", gasOk, gap.slice(0, 4).join(" | "));
  ok("replay: all 8 deployed at predicted CREATE addresses", deployOk);
  ok("replay: deployed runtime code matches compiled template (immutables masked)", codeOk);

  // ---- owners/roles read DIRECTLY from replay state ----
  const rOwner = await pub.readContract({ address: router, abi: routerAbi, functionName: "owner" });
  const lOwner = await pub.readContract({ address: locking, abi: lockAbi, functionName: "owner" });
  const cOwner = await pub.readContract({ address: P.claimManager, abi: artOf("DistributionClaimManager").abi, functionName: "owner" });
  ok("replay owners from state: router.owner==deployer, locking.owner==deployer, claim.owner==coordinator", getAddress(rOwner) === getAddress(DEPLOYER) && getAddress(lOwner) === getAddress(DEPLOYER) && getAddress(cOwner) === getAddress(P.coordinator));

  // ---- LP: pool state + consumption from replay ----
  ok("replay pool state right after mint == recorded poolSqrtAfter/poolTickAfter/poolLiquidityAfter", postMintPool && postMintPool.sqrt === B(a.lpUsage.poolSqrtAfter) && postMintPool.tick === a.lpUsage.poolTickAfter && postMintPool.liq === B(a.lpUsage.poolLiquidityAfter));

  // ---- buy/sell events decoded from replay logs, compared to accounting ----
  const findEv = (logs, abi, name) => { for (const l of logs) { try { const d = decodeEventLog({ abi, data: l.data, topics: l.topics }); if (d.eventName === name) return d.args; } catch { } } };
  const buyEv = findEv(evByLabel["buyExactWethForBps"], routerAbi, "OfficialBuy");
  ok("replay OfficialBuy event == recorded buy accounting (gross/stock/burn/user/bought/burned)", buyEv && B(buyEv.grossWethInput) === B(a.buyAccounting.grossWethInput) && B(buyEv.stockBudget) === B(a.buyAccounting.stockBudget2pct) && B(buyEv.burnBudget) === B(a.buyAccounting.burnBudget1pct) && B(buyEv.userBpsOutput) === B(a.buyAccounting.userBpsOutput) && B(buyEv.bpsBurned) === B(a.buyAccounting.bpsBurned));
  const sellEv = findEv(evByLabel["sellExactBpsForWeth"], routerAbi, "OfficialSell");
  ok("replay OfficialSell event == recorded sell accounting (gross/stock/burn/user/burned)", sellEv && B(sellEv.grossWethOutput) === B(a.sellAccounting.grossWethOutput) && B(sellEv.stockBudget) === B(a.sellAccounting.stockAcquisition2pct) && B(sellEv.burnBudget) === B(a.sellAccounting.retirementBurn2pct) && B(sellEv.userWethOutput) === B(a.sellAccounting.userWethOutput96pct) && B(sellEv.bpsBurned) === B(a.sellAccounting.bpsBurned));
  const lockEv = findEv(evByLabel["createLock(amount,7d)"], lockAbi, "LockCreated");
  ok("replay LockCreated event == recorded lock (principal, unlockTime, lockId)", lockEv && B(lockEv.principal) === B(a.lockAndWithdraw.principal) && B(lockEv.unlockTime) === B(a.lockAndWithdraw.unlockTime) && B(lockEv.lockId) === B(a.lockAndWithdraw.lockId));

  // ---- final immediate balances read from replay, compared to packet ----
  const eb = a.forkFunding.endingBalancesImmediate;
  ok("replay ending balances (ETH/WETH/BPSC) match packet endingBalancesImmediate", (await ethBal(DEPLOYER)) === B(eb.deployer.eth) && (await ethBal(TESTER)) === B(eb.tester.eth) && (await bal(WETH, DEPLOYER)) === B(eb.deployer.weth) && (await bal(WETH, TESTER)) === B(eb.tester.weth) && (await bal(canary, DEPLOYER)) === B(eb.deployer.bpsc) && (await bal(canary, TESTER)) === B(eb.tester.bpsc));
  ok("replay canary token symbol == BPSC-TEST", (await pub.readContract({ address: canary, abi: erc20, functionName: "symbol" })) === "BPSC-TEST");

  // ---- delayed withdrawal: warp + replay recorded withdraw calldata ----
  const snap = await rpc("evm_snapshot", []);
  await rpc("evm_setNextBlockTimestamp", [Number(B(a.lockAndWithdraw.unlockTime)) + 1]); await rpc("anvil_setNextBlockBaseFeePerGas", [PIN]); await rpc("evm_mine", []);
  const tBpsBefore = await bal(canary, TESTER);
  await rpc("anvil_setNextBlockBaseFeePerGas", [PIN]);
  const wHash = await rpc("eth_sendTransaction", [{ from: dl.signer, to: dl.to, data: dl.dataOrInitCode, gas: toHex(B(dl.gasLimit)), maxFeePerGas: toHex(B(dl.maxFeePerGas)), maxPriorityFeePerGas: toHex(B(dl.maxPriorityFeePerGas)) }]);
  const wRc = await pub.waitForTransactionReceipt({ hash: wHash });
  const returned = (await bal(canary, TESTER)) - tBpsBefore;
  const wEv = findEv(wRc.logs, lockAbi, "LockWithdrawn");
  ok("replay delayed withdraw: success, returned==principal, gasUsed matches, LockWithdrawn(principal) & not emergency", wRc.status === "success" && returned === B(a.lockAndWithdraw.principal) && B(wRc.gasUsed) === B(dl.gasUsed) && wEv && B(wEv.principal) === B(a.lockAndWithdraw.principal) && wEv.emergency === false);
  await rpc("evm_revert", [snap]);

  console.log("\n[replay] CHECKLIST:");
  for (const r of R) console.log(` [${r.pass ? "PASS" : "FAIL"}] ${r.n}${r.d ? "  (" + r.d + ")" : ""}`);
  const passed = R.filter(r => r.pass).length;
  console.log(`\n[replay] ${passed}/${R.length} checks passed`);
  return R.every(r => r.pass);
}

let code = 1;
try { code = (await main()) ? 0 : 1; }
catch (e) { console.error("[replay] ERROR:", e.message); code = 1; }
finally { if (anvil) try { anvil.kill("SIGKILL"); } catch { } }
if (process.argv.includes("--exit")) process.exit(code);
export default { code };
