# Canary Review Bundle v8 (Task 10B-8) — HISTORICAL FIXTURE, NON-LIVE, NON-EXECUTABLE

This bundle is a **self-contained, independently replayable** review of an isolated **BPSC-TEST**
canary rehearsal against Robinhood Chain mainnet (chainId 4663). It reuses the Task 10B-7 snapshot
(block **17485544**) as a **historical test fixture**. It is **not** canonical BPS, **not** execution-ready,
and **not** funding authorization. All four safety flags are false:
`broadcastReady=false, liveWritesApproved=false, executionAuthorized=false, fundingAuthorized=false`.

## One-command verification

```bash
node run-verification.mjs
```

This runs, in order:

1. **offline verifier** (`verify-packet.mjs`) — recomputes both digests (execution-packet over normalized
   signable fields; full-review over the whole artifact minus itself), a mutation test, build provenance
   from the **bundled** sources/artifacts (source keccak256, creation/runtime bytecode, solc 0.8.26 /
   optimizer runs 200 / cancun), exact init-code reconstruction (`creationBytecode ++ abi.encode(args)`),
   independent decode of every transaction (incl. createPool, initialize, both BPSC approvals, the vault
   approval), integer-ceiling gas checks, canonical-address guards from the bundled manifests, the funding
   plan, all caps ($100 / $20 / $10 / $130), and full ETH/WETH/BPSC reconciliation.
2. **independent clean-fork replay** (`replay-verify.mjs`) — starts its **own** clean Anvil fork at the
   pinned block, validates `latest == pinned` with a live-RPC hash cross-check, replays the exact recorded
   calldata, and compares — from replay state, trusting no packet boolean — receipts, gas used, effective
   gas price, deployed code (immutables masked), pool creation/initialization, LP liquidity/consumption,
   owners/roles, buy/sell allocations, all balances, and the delayed withdrawal.
3. **git provenance** (only when run inside the source repo) — `git rev-parse HEAD == recorded repoHead`
   and a clean tracked tree. In an extracted bundle this step is N/A; provenance is instead established by
   the offline verifier's source/artifact/bytecode hashes.

## Requirements

- Node.js >= 20 (uses the **vendored** `node_modules/viem` — no install needed)
- `anvil` (Foundry) in `PATH`
- Network access to the live RPC **only for forking** (read-only): `https://rpc.mainnet.chain.robinhood.com`

Nothing is funded, signed, broadcast, deployed, approved, or written to any live chain.

## Contents

| Path | Purpose |
|---|---|
| `canary-unsigned-packet.json` | the review packet (historical fixture) |
| `generate-packet.mjs` | generator (snapshot-safe; regenerate a fresh <=5-min snapshot before any execution) |
| `verify-packet.mjs` | offline verifier |
| `replay-verify.mjs` | independent clean-fork replay verifier |
| `run-verification.mjs` | one-command runner |
| `collect-prices.mjs` | price-collection step (two sources, raw responses + sha256) |
| `review-policy.json` | pinned snapshot / caps / gas / safety flags / anvil launch config |
| `price-snapshot.json` | pinned ETH/USD fixed-point price snapshot |
| `manifests/` | canonical canary + dryrun deployment manifests |
| `artifacts/` | the eight exact compiled contract artifacts |
| `sources/` | every Solidity source + imported source |
| `compiler/standard-json-input.json` | solc Standard JSON compiler input |
| `compiler/source-index.json` | metadata-path → bundle-path index |
| `node_modules/` | vendored viem dependency closure |
