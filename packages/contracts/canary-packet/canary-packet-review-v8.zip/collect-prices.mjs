// TASK 10B-8 price-collection step — fetches BOTH sources itself, records raw responses, timestamps,
// and response hashes; selects the higher fixed-point micro-USD value. Writes price-snapshot.json.
// Live mode: require 2 distinct sources, each observation <= 5 minutes old, fail on stale/malformed.
// Historical-fixture mode: timestamps validated relative to the pinned fixture time; marked non-live.
import { writeFileSync } from "node:fs";
import { createHash } from "node:crypto";

const MODE = process.argv.includes("--live") ? "live" : "historical-fixture";
const sha256 = (s) => "0x" + createHash("sha256").update(s).digest("hex");
const nowIso = new Date().toISOString();

async function fetchText(url) { const r = await fetch(url); const t = await r.text(); return { t, status: r.status }; }

const SRC = [
  { name: "coinbase", endpoint: "https://api.coinbase.com/v2/prices/ETH-USD/spot", parse: (j) => j.data.amount },
  { name: "kraken", endpoint: "https://api.kraken.com/0/public/Ticker?pair=ETHUSD", parse: (j) => Object.values(j.result)[0].c[0] },
];

const sources = [];
for (const s of SRC) {
  const { t, status } = await fetchText(s.endpoint);
  if (status !== 200) throw new Error(`${s.name} HTTP ${status}`);
  let priceUsd; try { priceUsd = s.parse(JSON.parse(t)); } catch (e) { throw new Error(`${s.name} malformed: ${e.message}`); }
  if (!/^\d+(\.\d+)?$/.test(String(priceUsd))) throw new Error(`${s.name} malformed price ${priceUsd}`);
  const microUsd = (BigInt(Math.round(Number(priceUsd) * 1e6))).toString();
  sources.push({ name: s.name, endpoint: s.endpoint, priceUsd: String(priceUsd), microUsd, observedAt: nowIso, rawResponse: t, rawResponseSha256: sha256(t) });
}
if (new Set(sources.map(s => s.name)).size < 2) throw new Error("need two distinct sources");
const microMax = sources.reduce((m, s) => BigInt(s.microUsd) > m ? BigInt(s.microUsd) : m, 0n);
const selected = sources.find(s => BigInt(s.microUsd) === microMax);

const snap = {
  asset: "ETH/USD",
  kind: "collected fresh price snapshot (fixed-point micro-USD; raw responses + sha256 recorded)",
  mode: MODE, live: MODE === "live", executable: false,
  capturedAt: nowIso,
  freshnessRuleSeconds: 300,
  sources,
  selectionRule: "higher of the two independent sources",
  selected: { source: selected.name, microUsd: selected.microUsd },
};
writeFileSync(new URL("./price-snapshot.json", import.meta.url), JSON.stringify(snap, null, 2));
console.log("collected:", sources.map(s => `${s.name}=${s.priceUsd}`).join(" "), "-> selected", selected.name, selected.microUsd, "mode", MODE);
